Wirepas Connectivity API Host Library (Python) Optional Gateway Plugins
=======================================================================

Optional plugins for the gateway implemented by the Wirepas Connectivity API
Host Library (Python).

Copyright 2018 Wirepas Ltd. All rights reserved.

<http://www.wirepas.com> `Wirepas Ltd`


