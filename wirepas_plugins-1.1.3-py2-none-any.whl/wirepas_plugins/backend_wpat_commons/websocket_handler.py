# Copyright 2018 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.

from threading import Thread, Event
from Queue import Queue, Empty

import websocket

import debug
import binascii

import time
import json

class ApplicationCommand(object):
    """
    Application commands

    General interface on how to interact with applications

    Attributes:
        cid : class ids

    """

    def __init__(self, source_endpoint, dest_endpoint):
        super(ApplicationCommand, self).__init__()

        self.source_endpoint = source_endpoint
        self.destination_endpoint = dest_endpoint

    # helpers
    def interval_to_hex(self, interval):
        """
        Interval to Hexadecimal

        Converts a decimal interval into hexadecimal

        Args:
            interval (int) : decimal value

        Returns:
            hint (str) : hexadecimal representation

        """

        if interval <= 0xFF:
            hint = '{0:02x}'.format(interval)

        elif interval <= 0xFFFF:
            hint = '{0:04x}'.format(interval)

        else:
            raise NameError('Invalid interval value')

        return hint

    def str_to_bin(self, payload):
        """
        String to Binary

        Converts a string packet to binary

        Args:
            payload (str) : hexadecimal payload

        Returns:
            payload (binary) : binary representation

        Author:
            Peic
        """

        if payload == "":
            payload = None

        if payload is not None:
            if payload[:2] == '0x':
                payload = payload[2:]
            payload = binascii.unhexlify(payload)

        return payload

    def build_cmd(self, header, payload):
        """
        Build command

        Builds a command based on header and payload.
        In short it computes the length and adds the
        terminator.

        Args:
            header (str) : hex str
            payload (str) : hex str

        Returns:
            cmd (str) : full command in hex

        """

        length = '{0:02x}'.format(int(len(payload)/2))

        return header + length + payload + '00'

    def send(self, device, address, payload, echo=False):
        """
        Sends a command through the device

        Interfaces with the device in order to push down
        the payload to the given address

        #TODO put this somewhere else

        Args:
            device (obj) : MeshApi object
            address (int) : node address
            payload (str) : hex str

        Returns:
            cmd (str) : full command in hex

        """
        sent = device.data_tx(data=self.str_to_bin(payload),
                              dest_address=address,
                              src_endpoint=self.source_endpoint,
                              dst_endpoint=self.destination_endpoint)

        if echo:
            debug.info('sending: {0} (sucess: {1})'.format(
                payload, sent['result'] == 0))


class WPATCommand(ApplicationCommand):
    """
    Wirepas Asset Tracking Application commands

    Builds commands to control the
    Asset Tracking application

    Attributes:
        cid : class ids

    """

    def __init__(self, source_endpoint=239, dest_endpoint=238):
        """
        Initialises the Parent class with endpoints and class ids
        """
        super(WPATCommand, self).__init__(
            source_endpoint=239, dest_endpoint=238)

        self.cid = {'tx': 0x01,
                    'scan': 0x02,
                    'offline': 0x03,
                    'headnode': 0x04,
                    'subnode': 0x05,
                    'beacon': 0x06}
        self._name = "asset_tracking_application_commands"

    # commands
    def tx_interval(self, interval):
        """
        Transmission interval

        Creates a command to set the transmission
        interval.

        Args:
            interval (int) : value (app accepts [15, 1800])

        Returns:
            cmd (str) : app command in hex

        """

        header = '{0:02x}'.format(self.cid['tx'])
        payload = self.interval_to_hex(interval)

        return self.build_cmd(header, payload)

    def offline_interval(self, interval):
        """
        Offline interval

        Creates a command to set the offline interval

        #TODO: fill in interval

        Args:
            interval (int) : value (app accepts [??, ??])

        Returns:
            cmd (str) : app command in hex

        """
        header = '{0:02x}'.format(self.cid['offline'])
        payload = self.interval_to_hex(interval)

        return self.build_cmd(header, payload)

    def before_sending(self, scan=True):
        """
        Scan before sending report

        Enables or disables a scan before sending a report

        Args:
            scan (bool) : True for enabling scan

        Returns:
            cmd (str) : app command in hex

        """
        header = '{0:02x}'.format(self.cid['scan'])
        if scan:
            payload = '01'
        else:
            payload = '00'

        return self.build_cmd(header, payload)

    def switch_headnode(self, scan=False):
        """
        Control headnode behavior

        Sets the headnode scan behavior

        Args:
            scan (bool) : True for enabling scan

        Returns:
            cmd (str) : app command in hex

        """
        header = '{0:02x}'.format(self.cid['headnode'])
        if scan:
            payload = '01'
        else:
            payload = '00'

        return self.build_cmd(header, payload)

    def switch_subnode(self, scan=False):
        """
        Control subnode behavior

        Sets the subnode scan behavior

        Args:
            scan (bool) : True for enabling scan

        Returns:
            cmd (str) : app command in hex

        """
        header = '{0:02x}'.format(self.cid['subnode'])
        if scan:
            payload = '01'
        else:
            payload = '00'

        return self.build_cmd(header, payload)

    def eddystone(self, enable=True):
        """
        Eddystone beacon

        Enables or disables the beacon

        Args:
            enable (bool) : True for enabling beacon

        Returns:
            cmd (str) : app command in hex

        """
        header = '{0:02x}'.format(self.cid['beacon'])
        if enable:
            payload = '0101'
        else:
            payload = '0100'

        return self.build_cmd(header, payload)

    def ibeacon(self, enable=True):
        """
        iBeacon beacon

        Enables or disables the beacon

        Args:
            enable (bool) : True for enabling beacon

        Returns:
            cmd (str) : app command in hex

        """
        header = '{0:02x}'.format(self.cid['beacon'])
        if enable:
            payload = '0201'
        else:
            payload = '0200'

        return self.build_cmd(header, payload)

    def quuppa(self, enable=True):
        """
        Quuppa beacon

        Enables or disables the beacon

        Args:
            enable (bool) : True for enabling beacon

        Returns:
            cmd (str) : app command in hex

        """
        header = '{0:02x}'.format(self.cid['beacon'])
        if enable:
            payload = '0301'
        else:
            payload = '0300'

        return self.build_cmd(header, payload)


class Actuactor(Thread):
    """
    Actuactor

    Acts on messages received from the server

    Atrributes:
    host (str) : websocket address
    app (obj) : WPAT command class instance
    device (obj) : MeshApi device instance
    identity (str) : ID to present to server
    ws (obj) : websocket instance

    """

    def __init__(self, host, device, identity):

        Thread.__init__(self)
        self.host = host
        self.app = WPATCommand(source_endpoint=239, dest_endpoint=238)
        self.device = device
        self.identity = identity
        self.ws = None

    def on_message(self, ws, message):
        """
        Handles incoming message based on topic

        Expects:
            {'topic': tx, (...)}

        Args:
            ws (obj) : websocket instance
            message (str) : message in the socket
        """
        debug.info('From wss: {0}'.format(message))
        message = json.loads(message)

        if message:
            try:
                topic = message['topic']
                if topic == 'beacon':
                    self.on_beacon(message)

                elif topic == 'tx':
                    self.on_tx_interval(message)

                elif topic == 'offline':
                    self.on_offline_interval(message)

                elif topic == 'scan':
                    self.on_scan(message)
            except KeyError:
                debug.info('unknown topic')

    def on_tx_interval(self, message):
        """
        Decodes topic:tx

        Payload is sent to the device
        if the decoding is successful

        Expects:
            {'topic': tx,
             'address': <addr>,
             'interval': <15-1800> (in seconds)
            }

        Args:
            message (str) : JSON message

        """
        addr = int(message['address'])
        interval = int(message['interval'])

        debug.info('decoded (addr:{0},interval:{1})'.format(addr, interval))

        cmd = self.app.tx_interval(interval)
        self.app.send(self.device, addr, cmd, echo=True)

    def on_scan(self, message):
        """
        Decodes topic:scan

        Payload is sent to the device
        if the decoding is successful

        Expects:
            {'topic': tx,
             'address': <addr>,
             'scan': <(on | off)>
            }

        Args:
            message (str) : JSON message

        """
        addr = int(message['address'])
        scan = message['scan'] == 'on'

        debug.info('decoded {0}-{1}'.format(addr, scan))

        cmd = self.app.before_sending(scan=scan)
        self.app.send(self.device, addr, cmd, echo=True)

    def on_beacon(self, message):
        """
        Decodes topic:beacon

        Expects:
            {'topic': tx,
             'address': <addr>,
             'scan': <(on | off)>,
             'btype': <(eddystone | ibeacon)>,
            }

        Args:
            message (str) : JSON message

        """

        addr = int(message['address'])
        switch = message['scan'] == 'on'
        btype = message['type']

        debug.info('decoded {0}-{1}-{2}'.format(addr, switch, btype))

        if btype == 'ibeacon':
            cmd = self.app.ibeacon(enable=switch)

        elif btype == 'eddystone':
            cmd = self.app.eddystone(enable=switch)

        elif btype == 'quuppa':
            cmd = self.app.quuppa(enable=switch)

        else:
            debug.info('unknown beacon')
            return

        self.app.send(self.device, addr, cmd, echo=True)

    def on_role(self, message):
        """
        Decodes topic:role

        Expects:
            {'topic': tx,
             'address': <addr>,
             'scan': <(on | off)>,
             'role': <(headnode | subnode)>,
            }

        Args:
            message (str) : JSON message

        """
        addr = int(message['address'])
        role = message['role'] == 'True'

        debug.info('decoded {0}-{1}-{2}'.format(addr, scan))

        if role == 'headnode':
            cmd = self.app.switch_headnode(scan=scan)

        elif role == 'subnode':
            cmd = self.app.switch_subnode(scan=scan)

        else:
            debug.info('unknonw role')
            return

        self.app.send(self.device, addr, cmd, echo=True)

    def on_error(self, ws, error):
        """
        Handles websocket error

        Prints error to stdout when an error occurs
        in the websocket connection

        Args:
            ws (obj) : Websocket instance
            erro (exception) : error message

        """
        self.exit.set()
        self.keep_running = False
        debug.info(str(error))

    def on_close(self, ws):
        """
        Handles websocket close

        Ensures the subthread is closed properly

        Args:
            ws (obj) : Websocket instance
        """
        self.exit.set()
        self.keep_running = False
        debug.info("### wss closed ###")

    def on_open(self, ws):
        """
        Handles websocket opens

        By default send the identity to the server

        #TODO filler code atm

        Args:
            ws (obj) : Websocket instance

        """
        ws.send(self.identity)

    def listen(self, exit_event, echo=False):
        """
        Waits for messages

        Listens for requests in a dedicated subthread
        unitl it receives a signal to terminate
        execution

        Args:
            exit_event (obj) : threading event

        Note:
            For disabling ssl check
            ws.run_forever(sslopt={"check_hostname": False})

        """
        websocket.enableTrace(echo)
        self.exit = exit_event
        self.ws = websocket.WebSocketApp(self.host,
                                         on_message=self.on_message,
                                         on_error=self.on_error,
                                         on_close=self.on_close,
                                         on_open=self.on_open)

        self.ws.keep_running = True
        self.wst = Thread(target=self.ws.run_forever)
        self.wst.daemon = True
        self.wst.start()

        while not self.exit.is_set():
            time.sleep(1)

        self.ws.keep_running = False
        if self.wst.is_alive():
            try:
                self.wst.join(0.1)
            except:
                debug.info('Thread dead? {0}'.format(self.wst.is_alive()))

        debug.info('killed websocket connections...')
