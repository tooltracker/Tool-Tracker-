# Copyright 2018 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.
#

import message_pb2

from meshapicsap import CsapHwMagic, CsapStackProfile
from meshapidsap import DsapNodeDiagnostics

# This module contains mappings from diagnostics  values to protobuf values. It is a separate module so that it needs 
# to be included only when needed

# Map from event to pbevent
hwmagic_to_pbhwmagic_map = {
    CsapHwMagic.HWMagic_NRF51: message_pb2.DiagnosticsData.NRF51,
    CsapHwMagic.HWMagic_EZR32: message_pb2.DiagnosticsData.EZR32,
    CsapHwMagic.HWMagic_NRF52: message_pb2.DiagnosticsData.NRF52,
    CsapHwMagic.HWMagic_CC2650: message_pb2.DiagnosticsData.CC2650,
}

# Stack profiles
stackprofile_to_pbstackprofile_map = {
    CsapStackProfile.profile_24: message_pb2.PROFILE_24,
    CsapStackProfile.profile_868: message_pb2.PROFILE_868,
    CsapStackProfile.profile_915: message_pb2.PROFILE_915,
    CsapStackProfile.profile_870: message_pb2.PROFILE_870,
    CsapStackProfile.profile_917: message_pb2.PROFILE_917,
    CsapStackProfile.profile_ti: message_pb2.PROFILE_TI,
}

# Map from event to pbevent
event_to_pbevent_map = {
    DsapNodeDiagnostics.EVENT_ROLE_CHANGE_TO_SUBNODE: message_pb2.DiagnosticsData.ROLE_CHANGE_TO_SUBNODE,
    DsapNodeDiagnostics.EVENT_ROLE_CHANGE_TO_HEADNODE: message_pb2.DiagnosticsData.ROLE_CHANGE_TO_HEADNODE,
    DsapNodeDiagnostics.EVENT_ROUTE_CHANGE: message_pb2.DiagnosticsData.ROUTE_CHANGE,
    DsapNodeDiagnostics.EVENT_SCANNING_NO_CHANNEL_SELECTED: message_pb2.DiagnosticsData.SCANNING_NO_CHANNEL_SELECTED,
    DsapNodeDiagnostics.EVENT_SCANNING_FTDMA_CONF_WITH_NEIGHBOR: message_pb2.DiagnosticsData.SCANNING_FTDMA_CONF_WITH_NEIGHBOR,
    DsapNodeDiagnostics.EVENT_SCANNING_FTDMA_CONF_WITH_NB_NEIGHBOR: message_pb2.DiagnosticsData.SCANNING_FTDMA_CONF_WITH_NB_NEIGHBOR,
    DsapNodeDiagnostics.EVENT_SCANNING_TIMING_CONF_WITH_NEIGHBOR: message_pb2.DiagnosticsData.SCANNING_TIMING_CONF_WITH_NEIGHBOR,
    DsapNodeDiagnostics.EVENT_SCANNING_TIMING_CONF_WITH_MULTIPLE_NEIGHBORS: message_pb2.DiagnosticsData.SCANNING_TIMING_CONF_WITH_MULTIPLE_NEIGHBORS,
    DsapNodeDiagnostics.EVENT_SCANNING_NEED_MORE_NEIGHBORS: message_pb2.DiagnosticsData.SCANNING_NEED_MORE_NEIGHBORS,
    DsapNodeDiagnostics.EVENT_SCANNING_PERIODIC: message_pb2.DiagnosticsData.SCANNING_PERIODIC,
    DsapNodeDiagnostics.EVENT_SCANNING_ROLE_CHANGE: message_pb2.DiagnosticsData.SCANNING_ROLE_CHANGE,
    DsapNodeDiagnostics.EVENT_BOOT_POWERON: message_pb2.DiagnosticsData.BOOT_POWERON,
    DsapNodeDiagnostics.EVENT_BOOT_INTENTIONAL: message_pb2.DiagnosticsData.BOOT_INTENTIONAL,
    DsapNodeDiagnostics.EVENT_BOOT_SW_FAILURE: message_pb2.DiagnosticsData.BOOT_SW_FAILURE,
    DsapNodeDiagnostics.EVENT_BOOT_PROCESSOR_FAILURE: message_pb2.DiagnosticsData.BOOT_PROCESSOR_FAILURE,
    DsapNodeDiagnostics.EVENT_BOOT_WATCHDOG_EXPIRE: message_pb2.DiagnosticsData.BOOT_WATCHDOG_EXPIRE,
    DsapNodeDiagnostics.EVENT_BOOT_UNINDENTIFIED_REASON: message_pb2.DiagnosticsData.BOOT_UNINDENTIFIED_REASON,
    DsapNodeDiagnostics.EVENT_SYNCLOST_ALTERNATIVE_ROUTE: message_pb2.DiagnosticsData.SYNCLOST_ALTERNATIVE_ROUTE,
    DsapNodeDiagnostics.EVENT_SYNCLOST_PRIMARY_ROUTE: message_pb2.DiagnosticsData.SYNCLOST_PRIMARY_ROUTE,
    DsapNodeDiagnostics.EVENT_FTDMA_ADJ_MINOR_BOUNDARY: message_pb2.DiagnosticsData.FTDMA_ADJ_MINOR_BOUNDARY,
    DsapNodeDiagnostics.EVENT_FTDMA_ADJ_NOT_IN_SLOT_BOUNDARY: message_pb2.DiagnosticsData.FTDMA_ADJ_NOT_IN_SLOT_BOUNDARY,
    DsapNodeDiagnostics.EVENT_FTDMA_ADJ_CONFLICT_WITH_PRIMARY_ROUTE: message_pb2.DiagnosticsData.FTDMA_ADJ_CONFLICT_WITH_PRIMARY_ROUTE,
    DsapNodeDiagnostics.EVENT_FTDMA_ADJ_CONFLICT_WITH_ALTERNATIVE_ROUTE: message_pb2.DiagnosticsData.FTDMA_ADJ_CONFLICT_WITH_ALTERNATIVE_ROUTE,
    DsapNodeDiagnostics.EVENT_FTDMA_ADJ_CONFLICT_WITH_NEIGHBOR: message_pb2.DiagnosticsData.FTDMA_ADJ_CONFLICT_WITH_NEIGHBOR,
    DsapNodeDiagnostics.EVENT_FTDMA_ADJ_NO_CHANNEL_SELECTED: message_pb2.DiagnosticsData.FTDMA_ADJ_NO_CHANNEL_SELECTED,
    DsapNodeDiagnostics.EVENT_FTDMA_ADJ_CHANNEL_BLACKLISTED: message_pb2.DiagnosticsData.FTDMA_ADJ_CHANNEL_BLACKLISTED,
    DsapNodeDiagnostics.EVENT_FTDMA_ADJ_OTHER_REASON: message_pb2.DiagnosticsData.FTDMA_ADJ_OTHER_REASON,
    DsapNodeDiagnostics.EVENT_SINK_CHANGED: message_pb2.DiagnosticsData.SINK_CHANGED,
    DsapNodeDiagnostics.EVENT_ROUTING_LOOP: message_pb2.DiagnosticsData.ROUTING_LOOP,
    DsapNodeDiagnostics.EVENT_DENSE_REMOVE_SUBNODE: message_pb2.DiagnosticsData.DENSE_REMOVE_SUBNODE,
}


