# Copyright 2018 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.
#

from meshapidsap import DsapDataRx

import debug

import meshapidsap
import struct
import binascii


def chunker( seq, size):
    """
        Splits a sequence in multiple parts

        Args:
            seq ([]) : an array
            size (int) : length of each array part

        Returns:
            array ([]) : a chunk of SEQ with given SIZE
    """
    return (seq[pos:pos + size] for pos in range(0, len(seq), size))

def packer(neighbors, indication, apdu, s_neighbor):
    """
        Splits a sequence in multiple parts

        Args:
            neighbors ({}) : where to pack each packet
            indication ({}) : ordered dictionary with
                              network indication contents
            apdu ([]) : application payload
            s_neighbor (obj) : bitwise definition of neighbor packet
    """

    for chunk in chunker(apdu, s_neighbor.size):
        values = s_neighbor.unpack(chunk)

        try:
            last_update = values[4]
        except:
            last_update = None

        d = {
            'source': indication['source_address'][0],
            'sink': indication['destination_address'][0],
            'address': values[0],
            'norm_rssi': values[1],
            'tx_power': values[2],  # check naming
            'rx_power': values[3],  # check naming
            'last_update': last_update,
            'travel_time': indication['travel_time_s'][0]
            }
        neighbors.append(d)


class DatapacketNeighborScanV1(DsapDataRx):
    """
    (DEPRECATED - DO NOT USE)

    DatapacketNeighborScan V1

    7 bytes structure without scan last update
    """
    def __init__(self, source_endpoint=238, dest_endpoint=239):
        super(DatapacketNeighborScanV1, self).__init__(
                                            source_endpoint=source_endpoint,
                                            dest_endpoint=dest_endpoint)
        self.neighbors = list()

    @classmethod
    def get_name(cls):
        return "neighborscan-v1"

    def parse_indication(self,
                         primitive_id,
                         frame_id,
                         payload_length,
                         payload,
                         compare = False):

        [a, b] = super(DatapacketNeighborScanV1, self).parse_indication(
                        primitive_id,
                        frame_id,
                        payload_length,
                        payload,
                        compare)
        if a:
            s_neighbor = struct.Struct('<I B B B')
            apdu = self.indication['apdu'][0]
            apdu_len = len(self.indication['apdu'][0])

            debug.info('WPAT APDU {0}:{1}:{2}'.format(binascii.hexlify(apdu),
                                                    apdu_len,
                                                    apdu_len/s_neighbor.size))


            packer(self.neighbors, self.indication, apdu, s_neighbor)

        return a, b




class DatapacketNeighborScanV2(DsapDataRx):
    """
    DatapacketNeighborScan handles the decoding of neighbour scans

    Meant to decode neighborscan packets, with the following content

    Attributes:
        neighbors (list): list of unpacked neighbors

    """
    def __init__(self, source_endpoint=238, dest_endpoint=239):
        super(DatapacketNeighborScanV2, self).__init__(
                                            source_endpoint=source_endpoint,
                                            dest_endpoint=dest_endpoint)
        self.neighbors = list()

    @classmethod
    def get_name(cls):
        return "neighborscan-v2"

    def parse_indication(self,
                         primitive_id,
                         frame_id,
                         payload_length,
                         payload,
                         compare = False):

        [a, b] = super(DatapacketNeighborScanV2, self).parse_indication(
                        primitive_id,
                        frame_id,
                        payload_length,
                        payload,
                        compare)
        if a:
            s_neighbor = struct.Struct('<I B B B H')
            apdu = self.indication['apdu'][0]
            apdu_len = len(self.indication['apdu'][0])

            debug.info('WPAT APDU {0}:{1}:{2}'.format(
                                            binascii.hexlify(apdu),
                                            apdu_len,
                                            apdu_len/s_neighbor.size))

            packer(self.neighbors, self.indication, apdu, s_neighbor)

        return a, b

