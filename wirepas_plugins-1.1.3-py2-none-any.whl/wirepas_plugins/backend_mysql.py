# Copyright 2018 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.
#

from Queue import Queue, Empty
import MySQLdb
import struct
import datetime
import time
import os
import pickle
import tempfile

from gatewaybackend import GatewayBackend
from meshapimsap import MsapRemoteStatusIndication
from meshapidsap import DsapDataRx
from datapacket_trafficdiagnostics import DatapacketTrafficDiagnostics
from datapacket_neighbordiagnostics import DatapacketNeighborDiagnostics
from datapacket_bootdiagnostics import DatapacketBootDiagnostics
from datapacket_nodediagnostics import DatapacketNodeDiagnostics

excluded_datapackets = []

try:
    from datapacket_commadapter import DatapacketCommAdapter
except ImportError:
    excluded_datapackets.append('commadapter')

try:
    from datapacket_testnw import DatapacketTestNW
except ImportError:
    excluded_datapackets.append('testnw')

try:
    from datapacket_haltian import DatapacketHaltian
except ImportError:
    excluded_datapackets.append('haltian')

try:
    from datapacket_raw32 import DatapacketRaw32
except ImportError:
    excluded_datapackets.append('raw32')

try:
    from datapacket_rawbinary import DatapacketRawBinary
except ImportError:
    excluded_datapackets.append('rawbinary')

try:
    from datapacket_neighborscan import DatapacketNeighborScanV1
except ImportError:
    excluded_datapackets.append('neighborscanv1')

try:
    from datapacket_neighborscan import DatapacketNeighborScanV2
except ImportError:
    excluded_datapackets.append('neighborscanv2')

from otapimage import *

import warnings
warnings.filterwarnings('ignore', category = MySQLdb.Warning)

class BackendMysql(GatewayBackend):
    name = 'mysql-v1'

    command_check_time = 5

    def __init__(self, configuration, device, gw_thread = None):
        super(BackendMysql, self).__init__(configuration, device, gw_thread)

        # This is how the device can be commanded:
        self.address = self.device.get_address()
        self.network_id = self.device.get_network_address()

        print "MySQL backend connection started for sink in address "+\
            str(self.address)+\
            " for network "+str(self.network_id)

        # Get the endpoints that are specifically collected by
        # the datapacket plugins.
        self.consumed_endpoints = set()
        datapacket_names = []

        for datapacket_name in configuration['datapackets']:
            self.consumed_endpoints.\
                add(configuration['datapackets'][datapacket_name])
            datapacket_names.append(datapacket_name)

        print "..Receiving data from plugins: "+str(datapacket_names)

        # Remove the None endpoint.
        try:
            self.consumed_endpoints.remove(None)
        except KeyError:
            pass

        # Register remote status indication
        device.register_indication_callback(MsapRemoteStatusIndication(),
                                        remote_status_callback_generator(self))

        # Connect to the database server.
        self._connect_to_database()

        self.create_mysql_tables()

        self.debug_insert_queue = Queue()

        self.running = True
        self.start()

    def run(self):
        command_start_time = 0

        while self.running:
            # Check first the debug print queue
            while True:
                try:
                    query = self.debug_insert_queue.get(timeout=0)
                    try:
                        self.cursor.execute(query)
                    except Exception as e:
                        self.msg('Debug print insert caused an exception ' \
                                 + str(e))

                    self.database.commit()
                except Empty:
                    break

            try:
                # Check if commands in the sink_commands table
                if (time.time() - command_start_time) > self.command_check_time:
                    self._check_command()
                    command_start_time = time.time()

                # Handle incoming data (if any)
                self._handle_rx_queue()

            except Exception as e:
                self.msg("MySQL plug-in caused an exception: " + str(e))
                self.msg("Disconnecting..")
                self._kill_connection()
                self.msg("Reconnecting..")
                self._connect_to_database()

        # Kill the connections on quit.
        self.msg("MySQL plug-in killed. Closing connection..")
        self._kill_connection()

    def _connect_to_database(self):
        '''Creates the connection to the MySQL database.
        '''

        # Try to reconnect until success.
        while True:
            try:
                self.database = MySQLdb.connect(host=self.configuration['ip'],
                                        user=self.configuration['username'],
                                        passwd=self.configuration['password'],
                                        db=self.configuration['database'],
                                        port=self.configuration['port'])

                print "..MySQL connection opened"
                self.cursor = self.database.cursor()
                break
            except Exception as e:
                self.msg("MySQL plug-in failed to connect: " + str(e))
                self.msg("Waiting for 10s..")
                time.sleep(10)
                self.msg("Trying again..")

    def _kill_connection(self):
        '''Kill the current connection to the database server.
        '''

        try:
            self.cursor.close()
        except:
            self.msg("ERROR: Could not close the cursor..")
        try:
            self.database.close()
        except:
            self.msg("ERROR: Could not close the connection..")
        self.msg("Connection closed")

    def _handle_rx_queue(self):
        '''
        Helper function to handle data from RX queue
        '''

        # Check the frame rx queue
        try:
            frame = self.rx_queue.get(timeout=1)

            # Check if traffic diagnostics
            if isinstance(frame, DatapacketTrafficDiagnostics):
                self.put_traffic_diagnostics(frame)

            # Check if neighbor diagnostics
            elif isinstance(frame, DatapacketNeighborDiagnostics):
                self.put_neighbor_diagnostics(frame)

            # Check if boot diagnostics
            elif isinstance(frame, DatapacketBootDiagnostics):
                self.put_boot_diagnostics(frame)

            # Check if boot diagnostics
            elif isinstance(frame, DatapacketNodeDiagnostics):
                self.put_node_diagnostics(frame)

            # Check if OTAP remote status indication
            elif isinstance(frame, MsapRemoteStatusIndication):
                print "Got a remote status from " + \
                    str(frame.indication['source_address'][0])
                self._push_remote_status_to_database(frame)

            self._handle_application_packets(frame)

            # If this not was handled by anything else then just put to
            # received_packets
            try:
                if isinstance(frame, DsapDataRx):
                    if frame.indication['destination_endpoint'][0] \
                       not in self.consumed_endpoints:
                        self.put_to_received_packets(frame)
            except Exception as e:
                self.msg("Failed frame: " + str(frame))
                self.msg("Exception: " + str(e))

        except Empty:
            pass

    def _handle_application_packets(self, frame):
        '''
        Handle the different datapacket types from applications.

        Args:

        - frame: The MeshApiIndication frame

        '''

        # Check if commadapter measurements
        if 'commadapter' not in excluded_datapackets and \
        isinstance(frame,  DatapacketCommAdapter):
            self.put_commadapter_measurements(frame)

        # Check if testnw measurement
        elif 'testnw' not in excluded_datapackets and \
        isinstance(frame, DatapacketTestNW):
            self.put_testnw_measurements(frame)

        # Check if haltian measurement
        elif 'haltian' not in excluded_datapackets and \
        isinstance(frame, DatapacketHaltian):
            self.put_haltian_measurements(frame)

        # Check if raw32 measurement
        elif 'raw32' not in excluded_datapackets and \
        isinstance(frame, DatapacketRaw32):
            self.put_raw32_measurements(frame)

        # Check if rawbinary measurement
        elif 'rawbinary' not in excluded_datapackets and \
        isinstance(frame, DatapacketRawBinary):
            self._put_rawbinary_measurements(frame)

        # Check if neighbor_scan-v1 measurement
        elif 'neighborscanv1' not in excluded_datapackets and \
        isinstance(frame, DatapacketNeighborScanV1):
            self.put_neighbor_scan_measurements(frame)

        # Check if neighbor_scan-v2 measurement
        elif 'neighborscanv2' not in excluded_datapackets and \
        isinstance(frame, DatapacketNeighborScanV2):
            self.put_neighbor_scan_measurements(frame)

    def kill(self):
        self.running = False

    def put_to_received_packets(self, frame):
        # Insert received packet to the database
        query = 'INSERT INTO received_packets (logged_time, launch_time, path_delay_ms, network_address, sink_address, source_address, '\
        'dest_address, source_endpoint, dest_endpoint, qos, num_bytes) '\
        'VALUES (from_unixtime({}), from_unixtime({}), {}, {}, {}, {}, {}, {}, {}, {}, {});'\
        .format(frame.indication['rx_unixtime'][0],
                frame.indication['rx_unixtime'][0] - frame.indication['travel_time_s'][0],
                frame.indication['travel_time_s'][0] * 1000,
                self.network_id,
                frame.indication['destination_address'][0],
                frame.indication['source_address'][0],
                frame.indication['destination_address'][0],
                frame.indication['source_endpoint'][0],
                frame.indication['destination_endpoint'][0],
                frame.indication['qos'][0],
                frame.indication['pdu_length'][0]
                )

        self.cursor.execute(query)
        self.database.commit()

    def put_traffic_diagnostics(self, frame):
        # Put first to received packets to get the received packet id
        self.put_to_received_packets(frame)

        query = "INSERT INTO diagnostic_traffic "\
            "(received_packet, access_cycles, cluster_channel, "\
            "channel_reliability, rx_count, tx_count, aloha_rxs, resv_rx_ok, "\
            "data_rxs, dup_rxs, cca_ratio, bcast_ratio, tx_unicast_fail, "\
            "resv_usage_max, resv_usage_avg, aloha_usage_max)"\
            "VALUES (LAST_INSERT_ID(),{},{},{},{},{},{},{},{},{},{},{},{},{},{},{});".\
            format(frame.indication['access_cycles'][0],
                   frame.indication['cluster_channel'][0],
                   frame.indication['channel_reliability'][0],
                   frame.indication['rx_amount'][0],
                   frame.indication['tx_amount'][0],
                   frame.indication['aloha_rx_ratio'][0],
                   frame.indication['reserved_rx_success_ratio'][0],
                   frame.indication['data_rx_ratio'][0],
                   frame.indication['rx_duplicate_ratio'][0],
                   frame.indication['cca_success_ratio'][0],
                   frame.indication['broadcast_ratio'][0],
                   frame.indication['failed_unicast_ratio'][0],
                   frame.indication['max_reserved_slot_usage'][0],
                   frame.indication['average_reserved_slot_usage'][0],
                   frame.indication['max_aloha_slot_usage'][0],
                   )

        self.cursor.execute(query)
        self.database.commit()

    def put_neighbor_scan_measurements(self, frame):
        # Puts asset tracking application data to table
        neighbors = frame.neighbors
        for neighbor in neighbors:
            query = "INSERT INTO wpat_neighbors"\
                    "(launch_time, path_delay_ms, network_address,"\
                    "sink_address, node_address, neighbor_address, norm_rssi,"\
                    "dbm_rss, tx_power, rx_power)"\
                    "VALUES ({},{},{},{},{},{},{},{},{},{});".\
                    format( frame.indication['rx_unixtime'][0] - frame.indication['travel_time_s'][0],
                            frame.indication['travel_time_s'][0] * 1000,
                            self.network_id,
                            neighbor['sink'],
                            neighbor['source'],
                            neighbor['address'],
                            neighbor['norm_rssi'],
                            (128 * neighbor['norm_rssi']) / 255.0 -128,
                            neighbor['tx_power'],
                            neighbor['rx_power'])
            self.cursor.execute(query)
        self.database.commit()

    def put_neighbor_diagnostics(self, frame):
        # Put first to received packets to get the received packet id
        self.put_to_received_packets(frame)

        # See if any neighbors, do not do insert
        if frame.indication['address_0'][0] == 0:
            return

        # Insert all neighbors at once
        values = []
        for i in range(0,14):
            try:
                if frame.indication['address_{}'.format(i)][0] == 0:
                    break
            except KeyError:
                # Number of neighbors depends on profile and can be less than 14
                break

            values.append("(LAST_INSERT_ID(),{},{},{},{},{})".\
                          format(frame.indication['address_{}'.format(i)][0],
                                 frame.indication['cluster_channel_{}'.
                                                  format(i)][0],
                                 frame.indication['radio_power_{}'.
                                                  format(i)][0],
                                 frame.indication['node_info_{}'.format(i)][0],
                                 frame.indication['rssi_{}'.format(i)][0],
                             ))

        query = "INSERT INTO diagnostic_neighbor "\
                "(received_packet, node_address, cluster_channel, "\
                "radio_power, device_info, norm_rssi) "\
                "VALUES {};".\
                format(','.join(values))

        self.cursor.execute(query)
        self.database.commit()

    def put_boot_diagnostics(self, frame):
        # Put first to received packets to get the received packet id
        self.put_to_received_packets(frame)

        # Firmware version contains values of major.minor.maint.devel, all 8
        # bytes
        firmware_version = frame.indication['sw_major_version'][0]
        firmware_version = firmware_version * 256 + \
                           frame.indication['sw_minor_version'][0]
        firmware_version = firmware_version * 256 + \
                           frame.indication['sw_maint_version'][0]
        firmware_version = firmware_version * 256 + \
                           frame.indication['sw_dev_version'][0]

        # Parse stack trace
        stack_trace = struct.unpack('<III', frame.indication['stack_trace'][0])

        query = "INSERT INTO diagnostic_boot " \
                "(received_packet, boot_count, node_role, firmware_version, " \
                "scratchpad_seq, hw_magic, stack_profile, otap_enabled, " \
                "file_line_num, file_name_hash, stack_trace_0, stack_trace_1, "\
                "stack_trace_2) " \
                "VALUES (LAST_INSERT_ID(), {}, {}, {}, {}, {}, {}, {}, {}, "\
                "{}, {}, {}, {});". \
            format(frame.indication['boot_count'][0],
                   frame.indication['node_role'][0],
                   firmware_version,
                   frame.indication['scratchpad_sequence'][0],
                   frame.indication['hw_magic'][0],
                   frame.indication['stack_profile'][0],
                   frame.indication['otap_enabled'][0],
                   frame.indication['boot_line_number'][0],
                   frame.indication['file_hash'][0],
                   stack_trace[0],
                   stack_trace[1],
                   stack_trace[2],
                   )
        self.cursor.execute(query)
        self.database.commit()

    def put_node_diagnostics(self, frame):
        # Put first to received packets to get the received packet id
        self.put_to_received_packets(frame)

        # Remember the last received packet (that was received_packets)
        last_received_packet = self.cursor.lastrowid

        voltage = float (frame.indication['voltage'][0])/100.0 + 2.0
        query = "INSERT INTO diagnostic_node "\
            "(received_packet, access_cycle_ms, node_role, voltage, "\
            "buf_usage_max, buf_usage_avg, mem_alloc_fails, "\
            "tc0_delay, tc1_delay, network_scans, "\
            "downlink_delay_avg_0, downlink_delay_min_0, "\
            "downlink_delay_max_0, downlink_delay_samples_0, "\
            "downlink_delay_avg_1, downlink_delay_min_1, "\
            "downlink_delay_max_1, downlink_delay_samples_1, "\
            "dropped_packets_0, dropped_packets_1, route_address, "\
            "next_hop_address_0, cost_0, quality_0, "\
            "next_hop_address_1, cost_1, quality_1) "\
            "VALUES (LAST_INSERT_ID(),{},{},{},{},{},{},{},{},{},{},{},{},{},"\
            "{},{},{},{},{},{},{},{},{},{},{},{},{});".\
            format(frame.indication['access_cycle'][0],
                   frame.indication['role'][0],
                   voltage,
                   frame.indication['max_buffer_usage'][0],
                   frame.indication['average_buffer_usage'][0],
                   frame.indication['mem_alloc_fails'][0],
                   frame.indication['normal_priority_buf_delay'][0],
                   frame.indication['high_priority_buf_delay'][0],
                   frame.indication['scans'][0],
                   frame.indication['dl_delay_avg_0'][0],
                   frame.indication['dl_delay_min_0'][0],
                   frame.indication['dl_delay_max_0'][0],
                   frame.indication['dl_delay_samples_0'][0],
                   frame.indication['dl_delay_avg_1'][0],
                   frame.indication['dl_delay_min_1'][0],
                   frame.indication['dl_delay_max_1'][0],
                   frame.indication['dl_delay_samples_1'][0],
                   frame.indication['dropped_packets_0'][0],
                   frame.indication['dropped_packets_1'][0],
                   frame.indication['cost_info_sink'][0],
                   frame.indication['cost_info_next_hop_0'][0],
                   frame.indication['cost_info_cost_0'][0],
                   frame.indication['cost_info_link_quality_0'][0],
                   frame.indication['cost_info_next_hop_1'][0],
                   frame.indication['cost_info_cost_1'][0],
                   frame.indication['cost_info_link_quality_1'][0],
                   )

        self.cursor.execute(query)
        self.database.commit()

        # Create events
        events = []
        i = 0
        for event in frame.indication['events'][0]:
            events.append('({},{},{})'.format(last_received_packet, i, event))
            i += 1

        if len(events) > 0:
            query = 'INSERT INTO diagnostic_event '\
            '(received_packet, position, event) '\
            'VALUES {};'.format(','.join(events))
            self.cursor.execute(query)
            self.database.commit()

    def __str__(self):
        '''
        Return the string presentation of the backend plug-in.
        '''

        return "BackendMysql for device "+str(self.device)

    def create_mysql_tables(self):
        '''
        Create tables if they do not exist
        '''

        query = 'CREATE TABLE IF NOT EXISTS known_nodes (' \
                '  network_address BIGINT UNSIGNED NOT NULL,' \
                '  node_address INT UNSIGNED NOT NULL,' \
                '  last_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,' \
                '  voltage DOUBLE NULL,' \
                '  node_role SMALLINT UNSIGNED NULL,' \
                '  firmware_version INT UNSIGNED NULL,' \
                '  scratchpad_seq INT UNSIGNED NULL,' \
                '  hw_magic INT UNSIGNED NULL,' \
                '  stack_profile INT UNSIGNED NULL,' \
                '  boot_count INT UNSIGNED NULL,' \
                '  file_line_num INT UNSIGNED NULL,' \
                '  file_name_hash INT UNSIGNED NULL,' \
                '  UNIQUE INDEX node (network_address, node_address)' \
                ') ENGINE = MYISAM;'
        self.cursor.execute(query)
        self.database.commit()

        query = 'CREATE TABLE IF NOT EXISTS received_packets (' \
                '  id BIGINT NOT NULL AUTO_INCREMENT UNIQUE,' \
                '  logged_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,' \
                '  launch_time TIMESTAMP NULL,' \
                '  path_delay_ms BIGINT UNSIGNED NOT NULL,' \
                '  network_address BIGINT UNSIGNED NOT NULL,' \
                '  sink_address INT UNSIGNED NOT NULL,' \
                '  source_address INT UNSIGNED NOT NULL,' \
                '  dest_address INT UNSIGNED NOT NULL,' \
                '  source_endpoint SMALLINT UNSIGNED NOT NULL,' \
                '  dest_endpoint SMALLINT UNSIGNED NOT NULL,' \
                '  qos SMALLINT UNSIGNED NOT NULL,' \
                '  num_bytes SMALLINT UNSIGNED NOT NULL,' \
                '  PRIMARY KEY (id),' \
                '  INDEX (logged_time),' \
                '  INDEX (launch_time),' \
                '  INDEX (source_address),' \
                '  INDEX packets_from_node (network_address, source_address)' \
                ') ENGINE = MYISAM;'
        self.cursor.execute(query)
        self.database.commit()

        query = 'CREATE TABLE IF NOT EXISTS diagnostic_traffic (' \
                '  received_packet BIGINT NOT NULL,' \
                '  access_cycles INT UNSIGNED NOT NULL,' \
                '  cluster_channel SMALLINT UNSIGNED NOT NULL,' \
                '  channel_reliability SMALLINT UNSIGNED NOT NULL,' \
                '  rx_count INT UNSIGNED NOT NULL,' \
                '  tx_count INT UNSIGNED NOT NULL,' \
                '  aloha_rxs SMALLINT UNSIGNED NOT NULL,' \
                '  resv_rx_ok SMALLINT UNSIGNED NOT NULL,' \
                '  data_rxs SMALLINT UNSIGNED NOT NULL,' \
                '  dup_rxs SMALLINT UNSIGNED NOT NULL,' \
                '  cca_ratio SMALLINT UNSIGNED NOT NULL,' \
                '  bcast_ratio SMALLINT UNSIGNED NOT NULL,' \
                '  tx_unicast_fail SMALLINT UNSIGNED NOT NULL,' \
                '  resv_usage_max SMALLINT UNSIGNED NOT NULL,' \
                '  resv_usage_avg SMALLINT UNSIGNED NOT NULL,' \
                '  aloha_usage_max SMALLINT UNSIGNED NOT NULL,' \
                '  FOREIGN KEY (received_packet) REFERENCES received_packets(id)' \
                ') ENGINE = MYISAM;'
        self.cursor.execute(query)
        self.database.commit()

        query = 'CREATE TABLE IF NOT EXISTS diagnostic_neighbor (' \
                '  received_packet BIGINT NOT NULL,' \
                '  node_address INT UNSIGNED NOT NULL,' \
                '  cluster_channel SMALLINT UNSIGNED NOT NULL,' \
                '  radio_power SMALLINT UNSIGNED NOT NULL,' \
                '  device_info SMALLINT UNSIGNED NOT NULL,' \
                '  norm_rssi SMALLINT UNSIGNED NOT NULL,' \
                '  FOREIGN KEY (received_packet) REFERENCES received_packets(id)' \
                ') ENGINE = MYISAM;'
        self.cursor.execute(query)
        self.database.commit()

        query = 'CREATE TABLE IF NOT EXISTS diagnostic_node (' \
                '  received_packet BIGINT NOT NULL,' \
                '  access_cycle_ms INT UNSIGNED NOT NULL,' \
                '  node_role SMALLINT UNSIGNED NOT NULL,' \
                '  voltage DOUBLE NOT NULL,' \
                '  buf_usage_max SMALLINT UNSIGNED NOT NULL,' \
                '  buf_usage_avg SMALLINT UNSIGNED NOT NULL,' \
                '  mem_alloc_fails SMALLINT UNSIGNED NOT NULL,' \
                '  tc0_delay SMALLINT UNSIGNED NOT NULL,' \
                '  tc1_delay SMALLINT UNSIGNED NOT NULL,' \
                '  network_scans SMALLINT UNSIGNED NOT NULL,' \
                '  downlink_delay_avg_0 INT UNSIGNED NOT NULL,' \
                '  downlink_delay_min_0 INT UNSIGNED NOT NULL,' \
                '  downlink_delay_max_0 INT UNSIGNED NOT NULL,' \
                '  downlink_delay_samples_0 INT UNSIGNED NOT NULL,' \
                '  downlink_delay_avg_1 INT UNSIGNED NOT NULL,' \
                '  downlink_delay_min_1 INT UNSIGNED NOT NULL,' \
                '  downlink_delay_max_1 INT UNSIGNED NOT NULL,' \
                '  downlink_delay_samples_1 INT UNSIGNED NOT NULL,' \
                '  dropped_packets_0 SMALLINT UNSIGNED NOT NULL,' \
                '  dropped_packets_1 SMALLINT UNSIGNED NOT NULL,' \
                '  route_address INT UNSIGNED NOT NULL,' \
                '  next_hop_address_0 INT UNSIGNED NOT NULL,' \
                '  cost_0 SMALLINT UNSIGNED NOT NULL,' \
                '  quality_0 SMALLINT UNSIGNED NOT NULL,' \
                '  next_hop_address_1 INT UNSIGNED NOT NULL,' \
                '  cost_1 SMALLINT UNSIGNED NOT NULL,' \
                '  quality_1 SMALLINT UNSIGNED NOT NULL,' \
                '  FOREIGN KEY (received_packet) REFERENCES received_packets(id)' \
                ') ENGINE = MYISAM;'
        self.cursor.execute(query)
        self.database.commit()

        query = 'CREATE TABLE IF NOT EXISTS diagnostic_event (' \
                '  received_packet BIGINT NOT NULL,' \
                '  position SMALLINT NOT NULL,' \
                '  event SMALLINT NOT NULL,' \
                '  FOREIGN KEY (received_packet) REFERENCES received_packets(id),' \
                '  UNIQUE INDEX event_id (received_packet, position)' \
                ') ENGINE = MYISAM;'
        self.cursor.execute(query)
        self.database.commit()

        query = 'CREATE TABLE IF NOT EXISTS diagnostic_boot (' \
                '  received_packet BIGINT NOT NULL,' \
                '  boot_count INT UNSIGNED NOT NULL,' \
                '  node_role SMALLINT UNSIGNED NOT NULL,' \
                '  firmware_version INT UNSIGNED NOT NULL,' \
                '  scratchpad_seq INT UNSIGNED NOT NULL,' \
                '  hw_magic INT UNSIGNED NOT NULL,' \
                '  stack_profile INT UNSIGNED NOT NULL,' \
                '  otap_enabled BOOL NOT NULL,' \
                '  file_line_num INT UNSIGNED NOT NULL,' \
                '  file_name_hash INT UNSIGNED NOT NULL,' \
                '  stack_trace_0 INT UNSIGNED NOT NULL,' \
                '  stack_trace_1 INT UNSIGNED NOT NULL,' \
                '  stack_trace_2 INT UNSIGNED NOT NULL,' \
                '  FOREIGN KEY (received_packet) REFERENCES received_packets(id)' \
                ') ENGINE = MYISAM;'
        self.cursor.execute(query)
        self.database.commit()

        query = 'CREATE TABLE IF NOT EXISTS sink_command ( ' \
                'id BIGINT NOT NULL AUTO_INCREMENT UNIQUE, ' \
                'address INT UNSIGNED NOT NULL, ' \
                'command varchar(255), ' \
                'param LONGBLOB, ' \
                'launch_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, ' \
                'ready_time TIMESTAMP NULL, ' \
                'result INT UNSIGNED, ' \
                'PRIMARY KEY (id), ' \
                'INDEX(address) ' \
                ') ENGINE = MYISAM;'
        self.cursor.execute(query)
        self.database.commit()

        # Create table for received remote statuses
        createtable = 'CREATE TABLE IF NOT EXISTS remote_status ( ' \
                      'id BIGINT NOT NULL AUTO_INCREMENT UNIQUE, ' \
                      'address INT UNSIGNED NOT NULL, ' \
                      'sink_address INT UNSIGNED NOT NULL, ' \
                      'reception_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, ' \
                      'crc INT UNSIGNED, ' \
                      'otap_seq INT UNSIGNED NOT NULL, ' \
                      'scratchpad_type INT UNSIGNED, ' \
                      'scratchpad_status INT UNSIGNED, ' \
                      'processed_length INT UNSIGNED, ' \
                      'processed_crc INT UNSIGNED, ' \
                      'processed_seq INT UNSIGNED, ' \
                      'fw_mem_area_id INT UNSIGNED, ' \
                      'fw_major_version INT UNSIGNED, ' \
                      'fw_minor_version INT UNSIGNED, ' \
                      'fw_maintenance_version INT UNSIGNED, ' \
                      'fw_development_version INT UNSIGNED, ' \
                      'seconds_until_update INT UNSIGNED, ' \
                      'legacy_status INT UNSIGNED, ' \
                      'PRIMARY KEY (id), ' \
                      'INDEX(address), ' \
                      'INDEX(sink_address) ' \
                      ') ENGINE = MYISAM;'
        self.cursor.execute(createtable)
        self.database.commit()

        # Create measurement types
        createtable = 'CREATE TABLE IF NOT EXISTS measurement_types ( ' \
                      'id INT AUTO_INCREMENT UNIQUE NOT NULL, ' \
                      '  name TEXT, ' \
                      'unit TEXT, ' \
                      '  description TEXT, ' \
                      'unit_scale DOUBLE NULL DEFAULT 1.0, ' \
                      'PRIMARY KEY (id) ' \
                      ') ENGINE = MYISAM;'
        self.cursor.execute(createtable)
        self.database.commit()

        createtable = 'CREATE TABLE IF NOT EXISTS measurements ( ' \
                      'id BIGINT NOT NULL AUTO_INCREMENT UNIQUE, ' \
                      'logged_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, ' \
                      'measured_time TIMESTAMP NULL, ' \
                      'path_delay_ms BIGINT UNSIGNED NOT NULL, ' \
                      'network_address BIGINT UNSIGNED NOT NULL, ' \
                      'sink_address INT UNSIGNED NOT NULL, ' \
                      'node_address INT UNSIGNED NOT NULL, ' \
                      'sensor_id INT NULL, ' \
                      'measurement_type INT NOT NULL, ' \
                      'measurement_value DOUBLE NULL, ' \
                      'more_measurements BOOL NOT NULL DEFAULT FALSE, ' \
                      'PRIMARY KEY (id), ' \
                      'FOREIGN KEY (measurement_type) REFERENCES measurement_types(id), ' \
                      'INDEX (logged_time), ' \
                      'INDEX (measured_time), ' \
                      'INDEX (node_address), ' \
                      'INDEX measurements_from_node (network_address, node_address, measurement_type), ' \
                      'INDEX measurement_types_of_node (measurement_type, network_address, node_address) ' \
                      ') ENGINE = MYISAM;'
        self.cursor.execute(createtable)
        self.database.commit()

        # Populate measurement_types table
        createtable = "REPLACE INTO measurement_types (id, name, unit, description, unit_scale) VALUES (1, 'temperature', '\xb0C', 'Temperature', '1')," \
                      "(2, 'absolute_humidity', 'g/m\xb3', 'Absolute humidity', '1'), " \
                      "(3, 'relative_humidity', '% RH', 'Relative humidity', '1'), " \
                      "(4, 'luminous_intensity', 'cd', 'Luminous intensity', '1'), " \
                      "(5, 'luminous_flux', 'lm', 'Luminous flux', '1'), " \
                      "(6, 'illuminance', 'lx', 'Illuminance', '1'), " \
                      "(7, 'carbon_dioxide', 'ppm', 'Carbon dioxide concentration', '1'), " \
                      "(8, 'carbon_monoxide', 'ppm', 'Carbon monoxide concentration', '1'), " \
                      "(9, 'voc', 'ppm', 'Volatile organic compound concentration', '1'), " \
                      "(10, 'length', 'm', 'Length', '1'), " \
                      "(11, 'duration', 's', 'Duration (time)', '1'), " \
                      "(12, 'velocity', 'm/s', 'Velocity', '1'), " \
                      "(13, 'acceleration', 'm/s\xb2', 'Acceleration', '1'), " \
                      "(14, 'area', 'm\xb2', 'Area', '1'), " \
                      "(15, 'volume', 'm\xb3', 'Volume', '1'), " \
                      "(16, 'volumetric_flow', 'm\xb3/s', 'Volumetric flow', '1'), " \
                      "(17, 'angle', '\xb0', 'Angle in degrees', '1'), " \
                      "(18, 'latitude', '\xb0', 'Latitude (north-south position)', '1'), " \
                      "(19, 'longitude', '\xb0', 'Longitude (east-west position)', '1'), " \
                      "(20, 'altitude', 'm', 'Altitude (height above sea level)', '1'), " \
                      "(21, 'frequency', 'Hz', 'Frequency', '1'), " \
                      "(22, 'frequency_of_rotation', 'r/min', 'Frequency of rotation (rpm)', '1'), " \
                      "(23, 'mass', 'kg', 'Mass', '1'), " \
                      "(24, 'mass_flow', 'kg/s', 'Mass flow', '1'), " \
                      "(25, 'density', 'kg/m\xb3', 'Density', '1'), " \
                      "(26, 'force', 'N', 'Force', '1'), " \
                      "(27, 'absolute_pressure', 'Pa', 'Absolute pressure', '1'), " \
                      "(28, 'gauge_pressure', 'Pa', 'Gauge pressure', '1'), " \
                      "(29, 'differential_pressure', 'Pa', 'Differential pressure', '1'), " \
                      "(30, 'energy', 'J', 'Energy', '1'), " \
                      "(31, 'power', 'W', 'Power', '1'), " \
                      "(32, 'electric_potential', 'V', 'Electric potential difference (voltage)', '1'), " \
                      "(33, 'electric_potential_sum', 'Vs', 'Electric potential difference (voltage), integrated over time', '1'), " \
                      "(34, 'electric_current', 'A', 'Electric current', '1'), " \
                      "(35, 'electric_current_sum', 'As', 'Electric current, integrated over time', '1'), " \
                      "(36, 'electric_resistance', 'ohm', 'Electric resistance', '1'), " \
                      "(37, 'electric_conductance', 'S', 'Electric conductance', '1'), " \
                      "(38, 'electric_capacitance', 'F', 'Electric capacitance', '1'), " \
                      "(39, 'electric_inductance', 'H', 'Electric inductance', '1'), " \
                      "(40, 'electric_energy', 'Wh', 'Electric energy', '1'), " \
                      "(41, 'electric_charge', 'C', 'Electric charge', '1'), " \
                      "(42, 'magnetic_flux', 'Wb', 'Magnetic flux', '1'), " \
                      "(43, 'magnetic_field', 'T', 'Magnetic field strength', '1'), " \
                      "(44, 'radioactivity', 'Bq', 'Radioactivity (decays per unit time)', '1'), " \
                      "(45, 'absorbed_dose', 'Gy', 'Absorbed dose (of ionizing radiation)', '1'), " \
                      "(46, 'equivalent_dose', 'Sv', 'Equivalent dose (of ionizing radiation)', '1'), " \
                      "(47, 'percent', '%', 'Percent', '1'), " \
                      "(48, 'per_mille', '%.', 'Per mille', '1'), " \
                      "(49, 'parts_per_million', 'ppm', 'Parts per million', '1'), " \
                      "(50, 'count', '', 'Count of events', '1'), " \
                      "(51, 'count_sum', '', 'Cumulative count of events', '1'), " \
                      "(52, 'raw_value', '', 'Raw value', '1'), " \
                      "(53, 'occurrence', '', 'Discrete event', '1');"

        self.cursor.execute(createtable)
        self.database.commit()

        # Create raw payload packets
        createtable = 'CREATE TABLE IF NOT EXISTS raw_payload (   '\
                        'id BIGINT NOT NULL AUTO_INCREMENT UNIQUE,   '\
                        'logged_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,   '\
                        'measured_time TIMESTAMP NULL,   ' \
                        'measured_time_exact DOUBLE NULL, '\
                        'path_delay_ms BIGINT UNSIGNED NOT NULL,   '\
                        'network_address BIGINT UNSIGNED NOT NULL,   '\
                        'sink_address INT UNSIGNED NOT NULL,   '\
                        'node_address INT UNSIGNED NOT NULL,   '\
                        'src_endpoint INT NULL, '\
                        'dst_endpoint INT NULL, '\
                        'payload BLOB, '\
                        'PRIMARY KEY (id),   '\
                        'INDEX (logged_time),  '\
                        'INDEX (sink_address),  '\
                        'INDEX (measured_time),   '\
                        'INDEX (measured_time_exact), '\
                        'INDEX (network_address), '\
                        'INDEX (node_address),   '\
                        'INDEX (src_endpoint), '\
                        'INDEX (dst_endpoint) '\
                        ') ENGINE=InnoDB; '

        self.cursor.execute(createtable)
        self.database.commit()

        # Create event codes
        createtable = 'CREATE TABLE IF NOT EXISTS diagnostic_event_codes ( ' \
                      'code SMALLINT UNSIGNED UNIQUE NOT NULL, ' \
                      'name TEXT, ' \
                      'description TEXT, ' \
                      'PRIMARY KEY (code) ' \
                      ') ENGINE = MYISAM;'
        self.cursor.execute(createtable)
        self.database.commit()

        # Populate event codes
        createtable = 'REPLACE INTO diagnostic_event_codes '\
                '(code, name, description) VALUES ' \
                '(0x08, "role_change_to_subnode", '\
                '"Role change: change to subnode"),' \
                '(0x09, "role_change_to_headnode", '\
                '"Role change: change to headnode"),' \
                '(0x10, "route_change_unknown", '\
                '"Route change: unknown reason"),' \
                '(0x18, "scan_ftdma_adjust",'\
                '"Scan: changing channel or no cluster channel selected"),' \
                '(0x19, "scan_f_confl_near_nbor",'\
                '"Scan: FTDMA conflict with cluster"),' \
                '(0x1a, "scan_f_confl_far_nbor",'\
                '"Scan: FTDMA conflict with neighbor\'s neighbor"),' \
                '(0x1b, "scan_t_confl_nbor",'\
                '"Scan: timing conflict with cluster"),' \
                '(0x1c, "scan_t_confl_between_nbors",'\
                '"Scan: timing conflict between two or more clusters"),' \
                '(0x1d, "scan_need_nbors",'\
                '"Scan: need more clusters"),' \
                '(0x1e, "scan_periodic",'\
                '"Scan: periodic scan"),' \
                '(0x1f, "scan_role_change",'\
                '"Scan: role change"),' \
                '(0x20, "boot_por",'\
                '"Boot: power-on reset"),' \
                '(0x21, "boot_intentional",'\
                '"Boot: reboot requested"),' \
                '(0x22, "boot_assert",'\
                '"Boot: software assert"),' \
                '(0x23, "boot_fault",'\
                '"Boot: fault handler"),' \
                '(0x24, "boot_wdt",'\
                '"Boot: watchdog timer"),' \
                '(0x25, "boot_unknown",'\
                '"Boot: unknown reason"),' \
                '(0x28, "sync_lost_synced",'\
                '"Sync lost: lost sync to synced cluster"),' \
                '(0x29, "sync_lost_joined",'\
                '"Sync lost: lost sync to next hop cluster"),' \
                '(0x30, "tdma_adjust_minor_boundary",'\
                '"TDMA adjust: minor boundary adjust"),' \
                '(0x31, "tdma_adjust_major_boundary",'\
                '"TDMA adjust: not in slot boundary"),' \
                '(0x32, "tdma_adjust_next_hop",'\
                '"TDMA adjust: FTDMA conflict with next hop"),' \
                '(0x33, "tdma_adjust_cluster",'\
                '"TDMA adjust: FTDMA conflict with neighboring cluster"),' \
                '(0x34, "tdma_adjust_neighbor",'\
                '"TDMA adjust: FTDMA conflict with neighbor"),' \
                '(0x35, "tdma_adjust_no_channel",'\
                '"TDMA adjust: no channel"),' \
                '(0x36, "tdma_adjust_blacklist",'\
                '"TDMA adjust: channel change due to blacklisting"),' \
                '(0x37, "tdma_adjust_unknown",'\
                '"TDMA adjust: unknown reason"),' \
                '(0x38, "peripheral_fail_unknown",'\
                '"Peripheral failure: unknown reason"),' \
                '(56, "sink_changed",'\
                '"Changed routing to another sink"),' \
                '(57, "fhma_adjust",'\
                '"FHMA adjust event"),' \
                '(0x40, "routing_loop_unknown",'\
                '"Routing loop: unknown reason"), ' \
                '(72, "subnode_removed",'\
                '"Removed subnode member in favour of headnode"),' \
                '(73, "ll_dl_fail_chead",'\
                '"Cluster head: removed member due to failing LL downklink"), '\
                '(74, "ll_dl_fail_member", '\
                '"Member: removed from the cluster head due to failing'\
                ' LL downlink"), '\
                '(56, "sink_changed",'\
                '"Changed routing to another sink"),' \
                '(57, "fhma_adjust",'\
                '"FHMA adjust event"),' \
                '(72, "subnode_removed",'\
                '"Removed subnode member in favour of headnode"),' \
                '(73, "ll_dl_fail_chead",'\
                '"Cluster head: removed member due to failing LL downklink"), '\
                '(74, "ll_dl_fail_member",'\
                '"Member: removed from the cluster head due to'\
                ' failing LL downlink");'

        self.cursor.execute(createtable)
        self.database.commit()

        # Create file name hashes table
        # Note: population of this cannot be done here. Content is due to change

        createtable = 'CREATE TABLE IF NOT EXISTS file_name_hashes (' \
                      'id SMALLINT UNSIGNED NOT NULL UNIQUE,' \
                      'name TEXT,' \
                      'PRIMARY KEY (id)' \
                      ') ENGINE = MYISAM;'
        self.cursor.execute(createtable)
        self.database.commit()

        # Asset Tracking
        # Create measurement types
        createtable = 'CREATE TABLE IF NOT EXISTS wpat_neighbors ( ' \
                  'id BIGINT NOT NULL AUTO_INCREMENT UNIQUE, ' \
                  'logged_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, ' \
                  'launch_time DOUBLE, ' \
                  'path_delay_ms BIGINT UNSIGNED NOT NULL, ' \
                  'network_address BIGINT UNSIGNED NOT NULL, ' \
                  'sink_address INT UNSIGNED NOT NULL, ' \
                  'node_address INT UNSIGNED NOT NULL, ' \
                  'neighbor_address INT NULL, ' \
                  'norm_rssi INT UNSIGNED NOT NULL, ' \
                  'dbm_rss INT NULL, ' \
                  'tx_power DOUBLE NULL, ' \
                  'rx_power DOUBLE NULL, ' \
                  'PRIMARY KEY (id), ' \
                  'INDEX (logged_time), ' \
                  'INDEX (neighbor_address), ' \
                  'INDEX (node_address) ' \
                  ') ENGINE = MYISAM;'

        self.cursor.execute(createtable)
        self.database.commit()

        # Create trigger for updating known nodes when received packets is inserted
        trigger = 'DROP TRIGGER IF EXISTS after_received_packets_insert;'
        self.cursor.execute(trigger)
        self.database.commit()

        # Note, there is no DELIMITER here
        trigger = """CREATE
                       TRIGGER after_received_packets_insert AFTER INSERT
                       ON received_packets
                       FOR EACH ROW BEGIN
                           INSERT INTO known_nodes (network_address, node_address, last_time)
                           VALUES
                           (new.network_address,new.source_address, CURRENT_TIMESTAMP)
                           ON DUPLICATE KEY UPDATE last_time=CURRENT_TIMESTAMP;
                       END;"""
        self.cursor.execute(trigger)
        self.database.commit()

        # Create a trigger for updating diagnostics node information to known nodes
        trigger = 'DROP TRIGGER IF EXISTS after_diagnostics_node_insert;'
        self.cursor.execute(trigger)
        self.database.commit()

        trigger = """CREATE TRIGGER `after_diagnostics_node_insert` AFTER INSERT
                     ON `diagnostic_node`
                     FOR EACH ROW BEGIN
                        INSERT INTO known_nodes (network_address, node_address, voltage, node_role)
                        SELECT rp.network_address,
                            rp.source_address,
                            new.voltage,
                            new.node_role
                        FROM received_packets rp
                        WHERE rp.id = new.received_packet
                        ON DUPLICATE KEY UPDATE voltage=new.voltage,node_role=new.node_role;
                     END;"""
        self.cursor.execute(trigger)
        self.database.commit()

        # Create a trigger for updating boot info to known nodes
        trigger = 'DROP TRIGGER IF EXISTS after_diagnostic_boot_insert;'
        self.cursor.execute(trigger)
        self.database.commit()

        trigger = """CREATE TRIGGER `after_diagnostic_boot_insert` AFTER INSERT ON `diagnostic_boot` FOR EACH ROW BEGIN
        INSERT INTO known_nodes (
            network_address,
            node_address,
             node_role,
              firmware_version,
              scratchpad_seq,
              hw_magic,
              stack_profile,
              boot_count,
              file_line_num,
              file_name_hash)
        SELECT rp.network_address,
            rp.source_address,
            new.node_role,
            new.firmware_version,
            new.scratchpad_seq,
            new.hw_magic,
            new.stack_profile,
            new.boot_count,
            new.file_line_num,
            new.file_name_hash
        FROM received_packets rp
        WHERE rp.id=new.received_packet
        ON DUPLICATE KEY UPDATE
        node_role=new.node_role,
        firmware_version=new.firmware_version,
        scratchpad_seq=new.scratchpad_seq,
        hw_magic=new.hw_magic,
        stack_profile=new.stack_profile,
        boot_count=new.boot_count,
        file_line_num=new.file_line_num,
        file_name_hash=new.file_name_hash;
        END;"""
        self.cursor.execute(trigger)
        self.database.commit()

        # Create the debug log table
        createtable = 'CREATE TABLE IF NOT EXISTS log('\
                      '  recordtime text,'\
                      '  debuglog text'\
                      '  ) ENGINE = MYISAM;'
        self.cursor.execute(createtable)
        self.database.commit()

    def debug_print_callback(self, item):
        '''The callback function for debug prints.

        Args:
            item (tuple): A tuple containing a UNIX timestamp and the
                debug print.
        '''

        # The timestamp for the debug print.
        timestamp = item[0]

        # The actual debug print.
        text = item[1]

        retval = {}
        retval['recordtime'] = '"' + \
                               datetime.datetime.\
                               fromtimestamp(timestamp).\
                               strftime('%Y-%m-%d %H:%M:%S:%f')\
                               + '"'

        retval['debuglog'] = text
        arraylog = retval['debuglog'].split('\n')
        for i in arraylog:
            if i != '':
                retval['debuglog'] = '"'+i+'"'

                realvalue = ', '.join(retval.values())
                columns = ', '.join(retval.keys())
                insert_sql = "INSERT INTO log ( %s ) VALUES ( %s );" \
                             % (columns, realvalue)

                self.debug_insert_queue.put(insert_sql)

    def get_debug_print_callback(self):
        return self.debug_print_callback

    def put_commadapter_measurements(self, frame):
        self.put_to_received_packets(frame)

        measurements = frame.indication['measurements'][0]
        currtime = frame.indication['currtime'][0]
        launch_time = frame.indication['launch_time'][0]
        
        if len(measurements) > 0:
            values = []
            # Create measurements:
            # logged_time,
            # measured_time,
            # path_delay_ms,
            # network_address,
            # sink_address,
            # node_address,
            # sensor_id,
            # measurement_type,
            # measurement_value
            for measurement in measurements:
                values.append('(from_unixtime({}), '
                          'from_unixtime({}), '
                          '{},'
                          '{},'
                          '{},'
                          '{},'
                          '{},'
                          '{},'
                          '{})'.format(currtime,
                                       launch_time,
                                       frame.indication['travel_time_s'][0] * 1000,
                                       self.network_id,
                                       frame.indication['destination_address'][0],
                                       frame.indication['source_address'][0],
                                       measurement[0],
                                       measurement[1],
                                       measurement[2],
                                       ))

            query = 'INSERT INTO measurements (logged_time, measured_time, path_delay_ms, network_address, '\
                    'sink_address, node_address, sensor_id, measurement_type, measurement_value) '\
                    'VALUES {};'.format(','.join(values))
            self.cursor.execute(query)
            self.database.commit()

    def put_testnw_measurements(self, frame):
        self.put_to_received_packets(frame)

        for row in xrange(frame.indication['row_count'][0]):
            table_name = 'TestData_ID_'+str(frame.indication['testdata_id'][0][row])

            self._create_testnw_mysql_table(self.cursor, self.database,
                                            table_name)

            data_column_names = ','.join(map(lambda x: 'DataCol_'+str(x), \
                                             xrange(1, frame.indication['number_of_fields'][0][row]+1)))

            data_column_values = ','.join(map(str, frame.indication['datafields'][0][row]))

            query = 'INSERT INTO '+table_name+' '+\
                    '(received_packet,'+\
                    'logged_time,'+\
                    'launch_time,'+\
                    'field_count,'+\
                    'ID_ctrl,'+\
                    data_column_names+')'+\
                    ' VALUES ('+\
                    'LAST_INSERT_ID(),'+\
                    '{0:.32f}'.format(frame.indication['rx_unixtime'][0],'.32f')+','+\
                    '{0:.32f}'.format(frame.indication['tx_unixtime'][0],'.32f')+','+\
                    str(frame.indication['number_of_fields'][0][row])+','+\
                    str(frame.indication['id_ctrl'][0][row])+','+\
                    data_column_values+\
                    ')'

            self.cursor.execute(query)
            self.database.commit()

    def _create_testnw_mysql_table(self, cursor, database, table_name):
        default_column_count = 30

        query = '''
CREATE TABLE IF NOT EXISTS `{}` (
`received_packet` int(11) DEFAULT NULL,
`logged_time` double DEFAULT NULL,
`launch_time` double DEFAULT NULL,
`ID_ctrl` INT UNSIGNED DEFAULT NULL,
`field_count` int DEFAULT 0'''.format(table_name)

        for i in xrange(1, default_column_count+1):
            query += ",\n`DataCol_{}` INT UNSIGNED DEFAULT NULL".format(i)

        query += "\n) ENGINE=MyISAM DEFAULT CHARSET=utf8;"

        cursor.execute(query)
        database.commit()

    def put_haltian_measurements(self, frame):
        self.put_to_received_packets(frame)
        
        values = []
        # Create measurements:
        #  logged_time,
        # measured_time,
        # path_delay_ms,
        # network_address,
        # sink_address,
        # node_address,
        # sensor_id,
        # measurement_type,
        # measurement_value

        measurements = {}

        # temperature
        measurements[0] = [1, frame.indication['temperature'][0]]
        # humidity
        measurements[1] = [3, frame.indication['humidity'][0]]
        # Pressure
        measurements[2] = [27, frame.indication['pressure'][0]]
        # todo: als
        # accelerations
        measurements[4] = [52, frame.indication['x'][0]]
        measurements[5] = [52, frame.indication['y'][0]]
        measurements[6] = [52, frame.indication['z'][0]]
        # Battery
        measurements[7] = [47, frame.indication['battery'][0]]
        # Hall sensor
        measurements[8] = [53, frame.indication['hall'][0]]
        measurements[9] = [6, frame.indication['illuminance'][0]]

        currtime = frame.indication['rx_unixtime'][0]
        launch_time = currtime - frame.indication['travel_time_s'][0]

        for sensor, value in measurements.iteritems():
            values.append('(from_unixtime({}), ' \
                          'from_unixtime({}), ' \
                          '{},' \
                          '{},' \
                          '{},' \
                          '{},' \
                          '{},' \
                          '{},' \
                          '{})'.format(currtime,
                                       launch_time,
                                       frame.indication['travel_time_s'][0] * 1000,
                                       self.network_id,
                                       frame.indication['destination_address'][0],
                                       frame.indication['source_address'][0],
                                       sensor,
                                       value[0],
                                       value[1],
                                       ))

        query = 'INSERT INTO measurements (logged_time, measured_time, path_delay_ms, network_address, ' \
                'sink_address, node_address, sensor_id, measurement_type, measurement_value) ' \
                'VALUES {};'.format(','.join(values))
        self.cursor.execute(query)
        self.database.commit()

    def put_raw32_measurements(self, frame):
        if len(frame.measurements) > 0:
            currtime = frame.indication['rx_unixtime'][0]
            launch_time = currtime - frame.indication['travel_time_s'][0]

            sensor_id = 0

            values = []
            # Create frame.measurements:
            #  logged_time,
            # measured_time,
            # path_delay_ms,
            # network_address,
            # sink_address,
            # node_address,
            # sensor_id,
            # measurement_type (always raw)
            # measurement_value
            for measurement in frame.measurements:
                values.append('(from_unixtime({}), '\
                          'from_unixtime({}), ' \
                          '{},' \
                          '{},' \
                          '{},' \
                          '{},' \
                          '{},' \
                          '52,' \
                          '{})'.format(currtime,
                                       launch_time,
                                       frame.indication['travel_time_s'][0] * 1000,
                                       self.network_id,
                                       frame.indication['destination_address'][0],
                                       frame.indication['source_address'][0],
                                       sensor_id,
                                       measurement,
                                       ))
                sensor_id = sensor_id + 1

            query = 'INSERT INTO measurements (logged_time, measured_time, path_delay_ms, network_address, '\
                    'sink_address, node_address, sensor_id, measurement_type, measurement_value) '\
                    'VALUES {};'.format(','.join(values))
            self.cursor.execute(query)
            self.database.commit()

    def _put_rawbinary_measurements(self, frame):

        currtime = frame.indication['rx_unixtime'][0]
        launch_time = currtime - frame.indication['travel_time_s'][0]

        query = 'INSERT INTO raw_payload (logged_time, measured_time, measured_time_exact, path_delay_ms, network_address, sink_address, '\
                'node_address, src_endpoint, dst_endpoint, payload) '\
                'VALUES (from_unixtime({}), from_unixtime({}), {}, {}, {}, {}, {}, {}, {}, %s);'\
                .format(frame.indication['rx_unixtime'][0],
                        frame.indication['tx_unixtime'][0],
                        frame.indication['tx_unixtime'][0],
                        frame.indication['travel_time_s'][0] * 1000,
                        self.network_id,
                        frame.indication['destination_address'][0],
                        frame.indication['source_address'][0],
                        frame.indication['source_endpoint'][0],
                        frame.indication['destination_endpoint'][0],
                        )
        self.cursor.execute(query, (frame.indication['apdu'][0],))
        self.database.commit()

    def _check_command(self):
        query = 'SELECT sink_command.id,sink_command.command,sink_command.param '\
                'FROM sink_command '\
                'WHERE sink_command.address={} '\
                'AND sink_command.result IS NULL '\
                'ORDER BY sink_command.launch_time '\
                'LIMIT 1;'.format(self.address)

        self.cursor.execute(query)
        self.database.commit()
        value = self.cursor.fetchall()
        if len(value) > 0:
            value = value[0]
            result = self._parse_command(value[1], value[2])
            query = "UPDATE sink_command SET result={},param=NULL,ready_time=from_unixtime({}) WHERE id={} LIMIT 1;"\
                .format(result, time.time(), value[0])
            self.cursor.execute(query)
            self.database.commit()

    def _parse_command(self, command, param):
        print 'Received command:{}'.format(command)
        if command=='otap_remote_status':
            self.device.otap_remote_status()
            return 0
        if command=='stop_stack':
            self.device.stack_stop()
            return 0
        if command=='start_stack':
            self.device.stack_start(autostart=True)
            return 0
        if command=='load_otap_image':
            self._parse_load_otap_image(param)
            return 0
        if command=='otap_remote_update_request':
            self._parse_otap_remote_update_request(param)
            return 0
        if command=='image_bootable':
            self._parse_image_bootable()
            return 0

        return 1

    def _parse_image_bootable(self):
        try:
            self.device.set_otap_image_bootable()
        except Exception as e:
            print "Failed to set the image bootable reason: "+str(e)

    def _parse_otap_remote_update_request(self, param):
        values = pickle.loads(param)
        delay = values[0]
        new_scratchpad = values[1]
        self.device.otap_remote_update_request(address=ADDRESS_BROADCAST,
                                               otap_seq=new_scratchpad,
                                               reboot_delay=delay)

    def _parse_load_otap_image(self, param):
        values = pickle.loads(param)
        new_scratchpad = values[0]
        scratchpad = values[1]

        handle, path = tempfile.mkstemp()
        _tmpfile = os.fdopen(handle,'wb')
        _tmpfile.write(scratchpad)
        _tmpfile.close()

        _otapimage = OTAPImage()
        _otapimage.load_file(path)

        try:
            self.device.load_otap_image(_otapimage, otap_sequence=new_scratchpad)
        except Exception as e:
            print "Failed to load the otap image reason: "+str(e)

        os.remove(path)

    def _push_remote_status_to_database(self, packet):
        query = 'INSERT INTO remote_status '\
                '(address, '\
                'sink_address, '\
                'crc, '\
                'otap_seq, '\
                'scratchpad_type, '\
                'scratchpad_status, '\
                'processed_length, '\
                'processed_crc, '\
                'processed_seq, '\
                'fw_mem_area_id, '\
                'fw_major_version, '\
                'fw_minor_version, '\
                'fw_maintenance_version, '\
                'fw_development_version, '\
                'seconds_until_update) VALUES (' \
                '{},'\
                '{},'\
                '{},'\
                '{},'\
                '{},'\
                '{},'\
                '{},'\
                '{},'\
                '{},'\
                '{},'\
                '{},'\
                '{},'\
                '{},'\
                '{},'\
                '{});'.format(packet.indication['source_address'][0],
                              self.address,
                              packet.indication['crc'][0],
                              packet.indication['otap_seq'][0],
                              packet.indication['scratchpad_type'][0],
                              packet.indication['scratchpad_status'][0],
                              packet.indication['processed_length'][0],
                              packet.indication['processed_crc'][0],
                              packet.indication['processed_seq'][0],
                              packet.indication['fw_mem_area_id'][0],
                              packet.indication['fw_major_version'][0],
                              packet.indication['fw_minor_version'][0],
                              packet.indication['fw_maintenance_version'][0],
                              packet.indication['fw_development_version'][0],
                              packet.indication['seconds_until_update'][0])

        self.cursor.execute(query)
        self.database.commit()

def remote_status_callback_generator(handler):
    """
    Callback handler for remote statuses

    @param handler: Diagnostics handler instance
    @return: Function pointer to call
    """

    def f(packet):
        # Same queue shall be used but separation
        # from diagnostics messages is done later
        handler.rx_queue.put(packet)
    return f
