# Copyright 2018 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.

from gatewaybackend import GatewayBackend
from threading import Thread, Event
from Queue import Queue, Empty

from datapacket_haltian import DatapacketHaltian
from datapacket_neighborscan import DatapacketNeighborScanV1
from datapacket_neighborscan import DatapacketNeighborScanV2
from datapacket_nodediagnostics import DatapacketNodeDiagnostics
from datapacket_neighbordiagnostics import DatapacketNeighborDiagnostics

import debug

import websocket
import requests

import time
import json

import os
import imp

cur_dir = os.path.dirname(__file__)
# Some import magic
websocket_handler = imp.load_source('websocket_handler',
                                    os.path.join(cur_dir,
                                                 'backend_wpat_commons',
                                                 'websocket_handler.py'))
from websocket_handler import Actuactor


class BackendWPAT(GatewayBackend):
    """
    Backend Wirepas Asset Tracking

    Handles requests to and from the asset tracking backend.

    Application neighbor reports (datapacket_neighborscan) are
    forwarded to the API through the REST API

    Backend requests are handled by the websocket

    # TODO Read Open API doc from backend
    # TODO Setup proper identity for web socket

    Attributes:
        address (int) : device address
        network_id (int) : wirepas network id

        route (dict) : REST API route dictionary (#TODO see above)
        identity (int) : secret shared with the backend (dummy)

        wshost (str) : websocket address
        probes (dict) : demo specific attribute

        last_update (int) : discard rss scans based on this threshold
        travel_limit (int) : discard packets with travel time older than

        packed (bool) : send neighbor array (undocumented endpoint)
        verify_cert (bool) : enable or disable ssl check

        consumed_endpoints (list) : endpoints being handled
        running (bool) : True whiel backend is running

    """
    name = 'wpat-v1'

    def __init__(self, configuration, device, gw_thread=None):
        """
        Sets up backend instance

        Args:
            configuration (dict) : dictionary with definitions from init file
            device (obj) : MeshApi device instance
            gw_thread (obj) : Object to access gateway thread

        """
        super(BackendWPAT, self).__init__(configuration, device, gw_thread)

        # This is how the device can be commanded:
        self.address = self.device.get_address()
        self.network_id = self.device.get_network_address()

        debug.info("WPAT backend connection started \
                    for sink in address \
                    {0} for network {1}".format(self.address, self.network_id))

        # TODO: Read from yaml definition file
        self.route = {}
        self.route['update_node'] = self.configuration[
            'apipath'] + 'update/node'
        self.route['update_sensor'] = self.configuration[
            'apipath'] + 'update/sensor'
        self.route['post_neighbor'] = self.configuration[
            'apipath'] + 'insert/neighbor'
        self.route['post_neighborset'] = self.configuration[
            'apipath'] + 'insert/neighborset'

        # websocket details
        try:
            self.identity = self.configuration['identity']
        except KeyError:
            self.identity = "18128913x98x10iaosdjoiu8xu9182300u"

        try:
            self.wshost = self.configuration['websocket']
        except KeyError:
            self.wshost = None

        # push sensor data based on probe information
        try:
            self.probes = self.configuration['probes']
        except KeyError:
            self.probes = None

        # ignore scans which are older than
        try:
            self.last_update = self.configuration['last_update']
        except KeyError:
            self.last_update = 80

        # travel time filter
        try:
            self.travel_limit = self.configuration['time_filter']
        except:
            self.travel_limit = 10

        # neighbor endpoint
        try:
            self.packed = self.configuration['packed']
        except:
            self.packed = True

        # disable ssl check
        try:
            self.verify_cert = self.configuration['tlsenabled']
            if not self.verify_cert:
                from requests.packages.urllib3.exceptions import InsecureRequestWarning
                requests.packages.urllib3.disable_warnings(
                    InsecureRequestWarning)

        except KeyError:
            self.verify_cert = True

        # Get the endpoints that are specifically collected by datapacket
        # plugins.
        self.consumed_endpoints = set()
        datapacket_names = []

        for datapacket_name in configuration['datapackets']:
            self.consumed_endpoints.add(
                configuration['datapackets'][datapacket_name])
            datapacket_names.append(datapacket_name)

        debug.info("..Receiving data from plugins: " + str(datapacket_names))

        # Remove the None endpoint.
        try:
            self.consumed_endpoints.remove(None)
        except KeyError:
            pass

        debug.info('WPAT backend configured and starting...')
        self.running = True
        self.start()

    def run(self):
        """
        Main execution loop

        Checks for websocket state and
        decodes incoming packets from the receiving queue


        Note:
            For disabling https warnings
            from requests.packages.urllib3.exceptions import InsecureRequestWarning
            requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

        """
        # websocket handler
        if self.wshost:
            ws_process = self.handler_websocket()

        # HTTP session persistance
        self.session = requests.Session()

        while self.running:

            # restart websocket
            if self.wshost:
                if not ws_process.is_alive():
                    ws_process = self.handler_websocket()

            # Check the frame rx queue
            # Note: if connection fail, queue will start piling up
            try:
                frame = self.rx_queue.get(timeout=10, block=True)

                if isinstance(frame, (DatapacketNeighborScanV1, DatapacketNeighborScanV2)):
                    self.put_neighbor_scan(frame, self.verify_cert)
                    continue

                if isinstance(frame, DatapacketNodeDiagnostics):
                    self.put_node_diagnostics(frame, self.verify_cert)
                    continue

                if isinstance(frame, DatapacketNeighborDiagnostics):
                    self.put_neighbor_diagnostics(frame, self.verify_cert)
                    continue

                if isinstance(frame, DatapacketHaltian):
                    self.put_haltian(frame, self.verify_cert)
                    continue

            except Empty:
                pass

        # terminate process
        if self.wshost:
            if ws_process.is_alive():
                debug.info('Killing websocket')
                self.ws_e.set()
                self.ws_p.join()

        self.running = False
        debug.info('Killed WPAT...')

    def handler_websocket(self):
        """
        Setups websocket

        Setups up the websocket with the remote server

        """
        actor = Actuactor(self.wshost, self.device, self.identity)
        self.ws_e = Event()
        self.ws_p = Thread(target=actor.listen, args=(self.ws_e,))
        self.ws_p.daemon = True
        self.ws_p.start()
        return self.ws_p

    def put_neighbor_scan(self, frame, verify=True, timeout=2):
        """
        Posts neighbor scan to REST API

        Args:
            frame (obj) : datapacket_neighbourscan instance
            verify (bool) : when true, fails on ssl error

        Returns:
            status (bool) : true on success

        """
        status = True
        neighbors = frame.neighbors
        reports = list()
        url = None

        # preprare package
        try:

            for neighbor in neighbors:
                report = {'nid': neighbor['address'],
                          'rss': neighbor['norm_rssi'],
                          'source': neighbor['source'],
                          'origin': neighbor['sink'],
                          'travel_time': neighbor['travel_time'],
                          'last_update': neighbor['last_update'],
                          'launch': time.time() * 1000}

                if(self.filter(report)):
                    reports.append(report)

            # depending on the method put them to the server
            if reports:
                debug.info('Sending {0} reports'.format(len(reports)))
                if self.packed:
                    url = self.route['post_neighborset']
                    r = self.session.put(url,
                                         auth=(self.configuration['username'],
                                               self.configuration['password']),
                                         data={
                                             "neighborset": json.dumps(reports)},
                                         timeout=timeout,
                                         verify=verify)
                    debug.info('PUT /neighborset with: {0}'.format(r.content))

                else:
                    url = self.route['post_neighbor']
                    for report in reports:
                        r = self.session.put(url,
                                             auth=(self.configuration['username'],
                                                   self.configuration['password']),
                                             data=report,
                                             timeout=timeout,
                                             verify=verify)
                        debug.info('PUT /neighbor with: {0}'.format(r.content))

        except:
            debug.info('PUT /neighbor failed to: {0}'.format(url))
            status = False

        return status

    def put_node_diagnostics(self, frame, verify=True, timeout=2):
        """
        Posts node diagnostics to REST API

        This parse the diagnostics for voltage and serves as
        a way to check which anchors are online

        Args:
            frame (obj) : datapacket_neighbourscan instance
            verify (bool) : when true, fails on ssl error

        Returns:
            status (bool) : true on success
        """
        status = True
        url = self.route['update_node']
        voltage = float(frame.indication['voltage'][0]) / 100.0 + 2.0
        report = {'nid': frame.indication['source_address'][0],
                  'voltage': voltage}
        try:
            # puts requests into database
            r = self.session.post(url,
                                  auth=(self.configuration['username'],
                                        self.configuration['password']),
                                  data=report,
                                  timeout=timeout,
                                  verify=verify)

            debug.info('UPDATE /node in {0}ms '.format(
                r.elapsed.total_seconds() * 1000))

        except:
            debug.info('UPDATE /node failed to: {0}'.format(url))
            status = False

        return status

    def put_neighbor_diagnostics(self, frame, verify=True, timeout=2):
        """
        Posts node neighbor diagnostics to REST API

        This parse the stack neighbor diagnostic data for
        RSSi information and posts it to the API

        Args:
            frame (obj) : datapacket_neighbourdiagnostics instance
            verify (bool) : when true, fails on ssl error

        Returns:
            status (bool) : true on success
        """
        status = True
        url = self.route['post_neighbor']
        neighbors = frame.indication['neighbors'][0]
        try:
            # puts requests into database
            for neighbor in neighbors:
                report = {'nid': neighbor['address'],
                          'rss': neighbor['rssi'],
                          'source': frame.indication['source_address'][0],
                          'origin': frame.indication['destination_address'][0],
                          'travel_time': frame.indication['travel_time_s'][0],
                          'last_update': 0,
                          'launch': time.time() * 1000}

                if(self.filter(report)):
                    r = self.session.put(url,
                                         auth=(self.configuration['username'],
                                               self.configuration['password']),
                                         data=report,
                                         timeout=timeout,
                                         verify=verify)
                    debug.info('PUT /diagnostic_neighbor in {0}ms'.format(
                               r.elapsed.total_seconds() * 1000))
        except:
            debug.info('PUT /diagnostic_neighbor failed to: {0}'.format(url))
            status = False

        return status

    def put_haltian(self, frame, verify=True, timeout=2):
        """
        Posts node neighbor diagnostics to REST API

        This parse the stack neighbor diagnostic data for
        RSSi information and posts it to the API

        Args:
            frame (obj) : datapacket_neighbourdiagnostics instance
            verify (bool) : when true, fails on ssl error

        Returns:
            status (bool) : true on success
        """
        status = True
        url = self.route['update_node']
        nid = frame.indication['source_address'][0]

        measurement = {
            'temperature': frame.indication['temperature'][0],
            'humidity': frame.indication['humidity'][0],
            'pressure': frame.indication['pressure'][0],
            'accel_x': frame.indication['x'][0],
            'accel_y': frame.indication['y'][0],
            'accel_z': frame.indication['z'][0],
            'battery': frame.indication['battery'][0],
            'hall': frame.indication['hall'][0],
            'illuminance': frame.indication['illuminance'][0],
            'nid': nid,
            'travel_time': frame.indication['travel_time_s'][0],
            'launch': time.time() * 1000
        }

        # puts requests into database
        r = self.session.post(self.route['update_node'],
                              auth=(self.configuration['username'],
                                    self.configuration['password']),
                              data=measurement,
                              timeout=timeout,
                              verify=verify)

        debug.info('POST /update_node in {0}ms '.format(
            r.elapsed.total_seconds() * 1000))

        if self.probes:
            aid = None
            for probe in self.probes:
                if probe['nid'] == nid:
                    aid = probe['aid']
                    break
            if aid is not None:
                area_update = {
                    'temperature': frame.indication['temperature'][0],
                    'humidity': frame.indication['humidity'][0],
                    'pressure': frame.indication['pressure'][0],
                    'accel_x': frame.indication['x'][0],
                    'accel_y': frame.indication['y'][0],
                    'accel_z': frame.indication['z'][0],
                    'battery': frame.indication['battery'][0],
                    'hall': frame.indication['hall'][0],
                    'illuminance': frame.indication['illuminance'][0],
                    'aid': aid,
                    'travel_time': frame.indication['travel_time_s'][0],
                    'launch': time.time() * 1000
                }
                debug.info('AREA UPDATE {0}'.format(area_update))
                # puts requests into database
                r = self.session.post(self.route['update_sensor'],
                                      auth=(self.configuration['username'],
                                            self.configuration['password']),
                                      data=area_update,
                                      timeout=timeout,
                                      verify=verify)

                debug.info('POST /update_sensor in {0}ms '.format(
                    r.elapsed.total_seconds() * 1000))

        return status

    def filter(self, neighbor):
        """
        Filter tests if neighbor packet should be sent.

        This is meant to be refined in the future. At the
        moment, the only thing this method does is to
        check if the travel time is unrealistic for small
        networks

        Args:
            neighbor (dict) : neighbor dictionary

        Returns:
            bool : true if it fulfils the filter conditions
                   is neighbor['travel_time'] < limit ?

        """
        if neighbor['last_update']:
            scan = neighbor['last_update'] < self.last_update
        else:
            scan = True  # for packet V1

        travel = neighbor['travel_time'] < self.travel_limit

        return travel and scan

    def kill(self):
        """
        Kills itself by setting running flag to False
        """
        self.running = False

    def __str__(self):
        """ Prints itself as a string """
        return "WPAT backend for device " + str(self.device)
