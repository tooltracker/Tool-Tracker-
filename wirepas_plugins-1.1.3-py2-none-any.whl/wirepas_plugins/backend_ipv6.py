# Copyright 2018 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.
#
"""This module implements the IPv6 border router.

NOTE: Needs to be used together with the Wirepas WPCAdapter.

Example configuration:
    [backend:ipv6]:
    type: 'backend-ipv6-v1'
    datapackets: {'ipv6-v1': 250}
    app_config_data: "024e482a008780000a00009000000000000000900000000000200080\
                      2a008780000a00009000000000000001000000000000000000000000\
                      000000000000000000000000000000000000000000000000"
    vna_server: "/tmp/wcfbrs"
    vna_client: "/tmp/wcfbrc"

"""

import binascii
import os
import socket
import select
import threading
from wirepas.gatewaybackend import GatewayBackend
from Queue import Queue, Empty
from datapacket_nodediagnostics import DatapacketNodeDiagnostics
from datapacket_ipv6 import DatapacketIpv6

class TunAdapter(threading.Thread):
    """TunAdapter thread for communicating through socket with the WPCAdapter.

    Args:
        own (str): VNA Client path
        vna_server (str): VNA Server path
        backend6 (BackendIpv6): The parent BackendIpv6 instance.
    """
    def __init__(self, own, vna_server, backend6):
        threading.Thread.__init__(self)

        self.sock_path_cl = own
        self.sock_path_sv = vna_server
        try:
            os.remove(self.sock_path_cl)
        except OSError:
            pass

        self.backend6 = backend6
        self.unixsock = 0
        self.unixsock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        self.unixsock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.unixsock.setblocking(0)
        self.unixsock.bind(self.sock_path_cl)

        print 'VNA Client:' + self.sock_path_cl
        print 'VNA Server:' + self.sock_path_sv

        return

    def send(self, data):
        '''Send a datapacket to WPCAdapter.

        Args:
            data (str): The APDU contents from the DataRX packet.
        '''
        sent = self.unixsock.sendto(data, self.sock_path_sv)
        return sent

    def receive(self):
        '''Receive a datapacket from WPCAdapater.

        Return (str): The IPv6 packet from WPCAdapter.
        '''

        data = None
        try:
            data = self.unixsock.recv(4096)
        except socket.error as e:
            ecode=e[0]
            estr=e[1]
            print "recv() failed: ", estr
            pass

        if data is not None:
            if len(data) > 102:
                data = None
                print 'oversize packet dropped'

        return data

    def close(self):
        '''Close the socket.
        '''

        self.unixsock.close()

    def run(self):
        '''The thread run function. Runs when the thread is started.
        '''

        self.running = True
        while self.running:
            r, w, e = select.select([self.unixsock], [], [], 1)
            for sock in r:
                if sock is self.unixsock:
                    data = self.receive()
                    if data is not None:
                        print "PACKET FROM TUN"
                        self.backend6.ipv6_to_dsap(bytearray(data))

    def kill(self):
        '''Kills the thread.
        '''

        self.running = False

class BackendIpv6(GatewayBackend):
    '''The IPv6 border router backend thread.

    Args:
        device (MeshApiDevice): The MeshApiDevice this plug-in instance is
            connected to.
        configuration (dict): A dictionary containing the plug-in configuration
            based on the gateway configuration .ini file.
        gw_thread (Thread): Gateway thread created by the get_gateway_thread.

    Attributes:
        name (str): The name for this plug-in used by the gateway.
        ipv6_ep (int): The Wirepas stack endpoint (source and destination) used
            for IPv6 packets.
        mtu_size (int): The maximum transmission unit for IPv6 ethernet packets.
    '''

    name = 'backend-ipv6-v1'
    mtu_size = 1500
    ipv6_ep = 250

    def __init__(self, configuration, device, gw_thread=None):
        super(BackendIpv6, self).__init__(configuration, device, gw_thread)

        self.vna_server = configuration['vna_server']
        self.vna_client = configuration['vna_client']

        address = self.device.get_address()

        #Note only one instance works...
        self.tun = TunAdapter(self.vna_client, self.vna_server, self)

        self.configureSink(configuration)

        # This is how the device can be commanded:
        address = self.device.get_address()
        print "IPv6 backend started for sink in address " + str(address)

        self.running = True
        self.start()

    def configureSink(self, config):
        '''Configure the sink based on the gateway plug-in configuration.

        Args:
            configuration (dict): A dictionary containing the plug-in
                configuration based on the gateway configuration .ini file.
        '''

        if config['app_config_data'] != None:
            try:
                appcfgdata = self.device.get_app_config_data()
            except:
                appcfgdata = {'sequence_number': 0,
                              'diagnostic_interval': 60,
                              'app_config_data': None}

            new_app_config = str(binascii.unhexlify(config['app_config_data']))

            # We only need to set app config data if it has changed
            # from the previous configuration.
            if appcfgdata['app_config_data'] != new_app_config:
                # Increase the sequence number.
                if appcfgdata['sequence_number'] > 0:
                    appcfgdata['sequence_number'] = \
                        (appcfgdata['sequence_number']) % 254 + 1
                else:
                    appcfgdata['sequence_number'] = 1

                print "IPv6 backend plug-in: Setting a new app config: " + \
                    "Sequence number: " + \
                    str(appcfgdata['sequence_number']) + \
                    ", Diagnostic interval: " + \
                    str(appcfgdata['diagnostic_data_interval']) + \
                    ", App config data: " + \
                    binascii.hexlify(new_app_config)

                # This is needed for IPv6 configuration
                if config['app_config_data'] != None:
                    self.device.set_app_config_data(
                        appcfgdata['sequence_number'],
                        appcfgdata['diagnostic_data_interval'],
                        new_app_config)

    def ipv6_to_dsap(self, data):
        '''Send an IPv6 to the Wirepas network.

        Args:
            data (str): The IPv6 packet coming from WPCAdapter.
        '''
        if len(data) <= self.mtu_size and data[0] == 0x60:
            dst = data[39] | data[38] << 8 | data[37] << 16
            print 'IPv6 send to node  ' + str(hex(dst))
            retval = self.device.data_tx(str(data), dest_address=dst,
                                                    src_endpoint=self.ipv6_ep,
                                                    dst_endpoint=self.ipv6_ep)
            print retval

    def put_ipv6(self, frame):
        '''Send an IPv6 coming from the Wirepas network to the WPCAdapter.

        Args:
            frame (DatapacketIpv6): The datapacket instance.
        '''
        self.tun.send(frame.indication['apdu'][0])

    def put_node_diagnostics(self, frame):
        '''Prints the packet source address if it's node diagnostics.

        Args:
            frame (DatapacketNodeDiagnostics): The datapacket instance.
        '''
        print str(frame.indication['source_address'][0])

    def run(self):
        '''The run method for the backend thread instance.
        '''

        try:
            self.tun.start()
        except:
            print "Error: Cannot start thread for Tun interface!"

        while self.running:
            try:
                frame = self.rx_queue.get(timeout=1)

                # Check if traffic diagnostics
                if isinstance(frame, DatapacketIpv6):
                    self.put_ipv6(frame)
                    continue

                # For debugging
                # Check if boot DatapacketNodeDiagnostics
                if isinstance(frame, DatapacketNodeDiagnostics):
                    self.put_node_diagnostics(frame)
                    continue

            except Empty:
                pass

    def kill(self):
        '''Kill both the backend thread and the TunAdapter thread.
        '''

        self.tun.kill()
        self.running = False

    def __str__(self):
        '''Return the string representation of this instance.
        '''

        return self.name + " for " + str(self.device)
