# Copyright 2018 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.
#

import struct
import binascii

from meshapidsap import DsapDataRx

class DatapacketCommAdapter(DsapDataRx):
    '''
    This class handles old commadapter-style measurements
    '''

    def __init__(self, dest_endpoint):
        super(DatapacketCommAdapter, self).__init__(dest_endpoint=int(dest_endpoint))

    @classmethod
    def get_name(cls):
        return 'commadapter-v1'

    def parse_indication(self,
                         primitive_id,
                         frame_id,
                         payload_length,
                         payload,
                         compare = False):

        [a, b] = super(DatapacketCommAdapter, self).parse_indication(primitive_id,
                         frame_id,
                         payload_length,
                         payload,
                         compare)
        if a:
            # Successful parsing, parse the actual payload
            
            # Parse by measurements. id, type, value tables
            measurements = []

            # First byte is sensor id, 3 concecutive bytes are measurement types and 3 measurements
            measurement_format = '<BBBBfff'
            measurement_length = struct.calcsize(measurement_format)

            payload = self.indication['apdu'][0]

            # Measure as long as it takes
            while len(payload) >= measurement_length:
                one_measurement = payload[0:measurement_length]
                payload = payload[measurement_length:]

                values = struct.unpack(measurement_format, one_measurement)
                # Parse three values (until 0 found)
                end_found = False
                for i in range(0, 3):
                    # Terminator found?
                    if values[1+i] == 0:
                        end_found = True
                        break
                    else:
                        measurements.append([values[0]+i, values[1+i], values[4+i]])
                    if end_found:
                        break

            currtime = self.indication['rx_unixtime'][0]
            launch_time = currtime - self.indication['travel_time_s'][0]
            self.indication['currtime'] = (self.indication['rx_unixtime'][0], 'timestamp')
            self.indication['launch_time'] = (self.indication['currtime'][0] -\
                                             self.indication['travel_time_s'][0], 'timestamp')

            if len(measurements) > 0:
                values = []
                # Create measurements:
                #  logged_time,
                # measured_time,
                # path_delay_ms,
                # network_address,
                # sink_address,
                # node_address,
                # sensor_id,
                # measurement_type,
                # measurement_value                
                self.indication['measurements'] = (measurements, 'list')
                
        return a, b    
