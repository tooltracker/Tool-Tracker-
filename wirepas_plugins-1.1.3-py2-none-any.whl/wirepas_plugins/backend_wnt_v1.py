# Copyright 2018 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.
#

"""This module implements the backend connection to Wirepas Network Tool backend
for wirepas.gateway.

To configure the wirepas.gateway to use this module the gateway configuration
needs add a backend of type "wnt-v1".

Example configuration accepting all diagnostics and Remote API responses:
    # An example WNT backend configuration
    [backend:default_wnt]
    type: 'wnt-v1'
    host: '192.168.100.162'
    mqttusername: 'admin'
    mqttpassword: 'admin'
    tlsenabled: True
    certfile: 'extwirepas.pem'
    heartbeatinterval: 10
    port: 8883
    datapackets: {'trafficdiagnostics-v1': 255, 'neighbordiagnostics-v1': 255, \
                  'nodediagnostics-v1': 255, 'bootdiagnostics-v1': 255, \
                  'nondiagnostic-v1': None, 'remoteapi-v1': 255}

"""

# Import the datapacket types the plug-in can handle
from datapacket_trafficdiagnostics import DatapacketTrafficDiagnostics
from datapacket_neighbordiagnostics import DatapacketNeighborDiagnostics
from datapacket_bootdiagnostics import DatapacketBootDiagnostics
from datapacket_nodediagnostics import DatapacketNodeDiagnostics
from datapacket_remoteapiresponse import DatapacketRemoteApiResponse

# Device role definitions
from meshapicsap import CsapNodeRole

# Channel to frequency conversion function
from meshapidsap import convert_channel_to_frequency

# MeshApiDevice generated exception
from meshapi_common import MeshApiDeviceException

import time
import paho.mqtt.client as mqtt
import struct

import os
import imp
import ssl

cur_dir = os.path.dirname(__file__)

# Some import magic to load all the necessary modules from inside
# the plug-ins directory.
commons_pb2 = imp.load_source('commons_pb2',
                              os.path.join(cur_dir, 'backend_wnt_proto',
                                           'commons_pb2.py'))

remote_api_pb2 = imp.load_source('remote_api_pb2',
                                 os.path.join(cur_dir, 'backend_wnt_proto',
                                              'remote_api_pb2.py'))

internal_pb2 = imp.load_source('internal_pb2',
                                 os.path.join(cur_dir, 'backend_wnt_proto',
                                              'internal_pb2.py'))

message_pb2 = imp.load_source('message_pb2',
                              os.path.join(cur_dir,
                                           'backend_wnt_proto',
                                           'message_pb2.py'))

diagnostics_map = imp.load_source('diagnostics_map',
                                  os.path.join(cur_dir,
                                               'backend_wnt_proto',
                                               'diagnostics_map.py'))

wnt_remoteapi = imp.load_source('wnt_remoteapi',
                                os.path.join(cur_dir, 'wnt_remoteapi.py'))

from diagnostics_map import event_to_pbevent_map, hwmagic_to_pbhwmagic_map, \
    stackprofile_to_pbstackprofile_map

from gateway_identity import GatewayIdentity
from wnt_remoteapi import BackendWntRemoteApi

from Queue import Queue, Empty
from threading import Thread

# GatewayBackend abstract class
from gatewaybackend import GatewayBackend

class ConnectionResult:
    '''Connection result values for MQTT on connect callback.
    '''

    Success = 0
    IncorrectProtocolVersion = 1
    InvalidClientIdentifier = 2
    ServerUnavailable = 3
    BadCredentials = 4
    NotAuthorised = 5

# Duty cycle max value that is considered as 100%
DUTY_CYCLE_MAX_VALUE = 10000.0

class BackendWNT(GatewayBackend):
    """ The backend plug-in class for WNT connection.

    Args:
        device (MeshApiDevice): The MeshApiDevice this plug-in instance is
            connected to.
        configuration (dict): A dictionary containing the plug-in configuration
            based on the gateway configuration .ini file.
        gw_thread (Thread): Gateway thread created by the get_gateway_thread.

    NOTE: All arguments provided automatically by the wirepas.gateway.

    Attributes:
        start_time (float): Starting time in seconds from the epoch.
        device (MeshApiDevice): The MeshApiDevice this plug-in instance is
            connected to.
        configuration (dict): A dictionary containing the plug-in configuration
            based on the gateway configuration .ini file.
        gw_thread (Thread): Gateway thread created by the get_gateway_thread.
        gw_command_queue (Queue): A queue for commands to the wirepas.gateway.
        remoteapi_input_topic (str): MQTT topic for remote to gateway messages.
        address (int): The node address of the sink that the plug-in instance
            is connected to.
        network_id (int): The network ID of the sink that the plug-in instance
            is connected to.
        stack_profile (int): The stack profile number of the sink that the
            plug-in instance is connected to.
        sink_to_wnt_topic (str): A sink to WNT MQTT topic.
        consumed_endpoints (set): A set of consumed destination
            endpoint numbers.
        mqtt (Object): The MQTT client object.
        remoteapi_handler (BackendWntRemoteApi): WNT Remote API class instance.
        running (bool): True if the backend should be running. False if not.
    """

    # The plug-in name.
    name = 'wnt-v1'

    # MQTT topic prefixes.
    DATA_TOPIC_PREFIX = "diagnostics/raw/"
    SINK_TO_WNT_TOPIC_PREFIX = 'sinktownt/'
    WNT_TO_SINK_TOPIC_PREFIX = 'wnttosink/'
    SINK_TO_SINK_TOPIC_PREFIX = 'sinktosink/'
    SINK_TO_WNT_SINK_CONFIG_TOPIC_PREFIX = SINK_TO_WNT_TOPIC_PREFIX + \
                                           'sinkconfig/'
    WILL_TOPIC_SUFFIX = '/will'
    WNT_TO_NODE_TOPIC_PREFIX = 'wnttonode/'

    # Prefixes for remote api and otap operations between gateway and backend
    REMOTEAPI_INPUT_TOPIC_PREFIX = 'remotetogateway/'
    REMOTEAPI_OUTPUT_TOPIC_PREFIX = 'remotetownt/'

    # Interval to check for remote api operations. This must be >maximum
    # access cycle to avoid downlink starvation
    REMOTEAPI_POLLTIME = 8.1

    # Wait time for MQTT commands back to self in seconds
    STATE_CHANGE_WAIT_TIME_S = 2

    def __init__(self, configuration, device, gw_thread = None):
        self.start_time = time.time()

        super(BackendWNT, self).__init__(configuration, device, gw_thread)

        self.remoteapi_input_topic = None

        self.address = self.device.get_address()
        self.network_id = self.device.get_network_address()
        self.stack_profile = self.device.get_stack_profile()

        # We suppose the plug-in has not restarted until we get information
        # from MQTT that says otherwise.
        self.restarted = False

        # The gw_command_queue is initially None.
        # Set later by the set_gw_command_queue method.
        self.gw_command_queue = None

        self.sink_to_wnt_topic = '{}{}/{}'.format(self.SINK_TO_WNT_TOPIC_PREFIX,
                                                  self.network_id,
                                                  self.address)

        if self.configuration['tlsenabled']:
            self.wnt_cert_file = os.path.join(cur_dir, 'wnt_certs',
                                              self.configuration['certfile'])

        print 'WNT backend connection started for sink in address {} for '\
            'network {}'.format(self.address,
                                self.network_id)

        # Get the endpoints that are specifically collected by
        # datapacket plugins.
        self.consumed_endpoints = set()
        datapacket_names = []

        for datapacket_name in configuration['datapackets']:
            self.consumed_endpoints.add(configuration['datapackets']
                                        [datapacket_name])
            datapacket_names.append(datapacket_name)

        print "..Receiving data from plugins: "+str(datapacket_names)

        # Remove the None endpoint.
        try:
            self.consumed_endpoints.remove(None)
        except KeyError:
            pass

        # Set necessary configuration for MQTT client
        self.mqtt = mqtt.Client()
        self.mqtt.username_pw_set(self.configuration['mqttusername'],
                                  self.configuration['mqttpassword'])
        self.mqtt.on_message = on_message_cb_generator(self)
        self.mqtt.on_connect = on_connect_cb_generator(self)
        self.mqtt.on_disconnect = on_disconnect_cb_generator(self)
        self.mqtt.will_set(topic =self.SINK_TO_WNT_TOPIC_PREFIX +
                           str(self.network_id) + '/' +
                           str(self.address)+self.WILL_TOPIC_SUFFIX,
                           qos=1, retain=True)

        if self.configuration['tlsenabled']:
            self.mqtt.tls_set(self.wnt_cert_file, certfile=None, keyfile=None,
                              cert_reqs=ssl.CERT_REQUIRED,
                              tls_version=ssl.PROTOCOL_TLSv1_2, ciphers=None)

        # Instantiate remote api handler prior starting mqtt
        self.remoteapi_handler = BackendWntRemoteApi(
            plugin=self,
            device=device,
            mqtt=self.mqtt,
            remotetownttopic=
            '{}{}/{}'.format(self.REMOTEAPI_OUTPUT_TOPIC_PREFIX,
                             self.network_id,
                             self.address),
            sink_address=self.address,
            network_id=self.network_id)

        self.mqtt.connect(self.configuration['host'], self.configuration['port'])
        self.mqtt.loop_start()
        print "..Waiting for a connection.."
        self.running = True
        self.start()

    def set_gw_command_queue(self, queue):
        """A method to set the GW command queue for sending
        commands to the main gateway thread.

        Args:
            queue (Queue): A Queue.Queue where commands can be put.
        """

        self.gw_command_queue = queue

    def gw_command(self, command):
        """Send a command to the gateway main thread using
        the queue.

        Args:
            command (str): A string containing the command to the gateway.
        """

        self.gw_command_queue.put({'backend':self, 'command':command})

    def run(self):
        """Thread.run method that runs until self.running is False.

        Collects all incoming datapackets from the self.rx_queue and
        sends them to MQTT.

        Also polls for incoming Remote API commands from the WNT backend.
        """

        last_remoteapi_polltime = time.time()
        while self.running:
            try:
                frame = self.rx_queue.get(timeout=1)

                # Check if traffic diagnostics
                if isinstance(frame, DatapacketTrafficDiagnostics):
                    self.publish_packet(self.encode_traffic_diagnostics(frame))

                # Check if neighbor diagnostics
                elif isinstance(frame, DatapacketNeighborDiagnostics):
                    self.publish_packet(self.encode_neighbor_diagnostics(frame))

                # Check if node diagnostics
                elif isinstance(frame, DatapacketNodeDiagnostics):
                    self.publish_packet(self.encode_node_diagnostics(frame))

                # Check if boot diagnostics
                elif isinstance(frame, DatapacketBootDiagnostics):
                    self.publish_packet(self.encode_boot_diagnostics(frame))

                # Check if remote api response
                elif isinstance(frame, DatapacketRemoteApiResponse):
                    self.publish_packet(self._encode_remoteapi_response(frame))

                else:
                    self.publish_packet(self.encode_datapacket(frame,
                                                               add_payload =
                                                               True))

            except Empty:
                pass

            if (time.time() - last_remoteapi_polltime) > self.REMOTEAPI_POLLTIME:
                self.remoteapi_handler.send_loop()
                last_remoteapi_polltime = time.time()

        self.mqtt.loop_stop()

    def publish_packet(self, encoded):
        """Publish an encoded packet to MQTT.

        Args:
            encoded (dict): A dictionary containing the node ID of sender and
                the encoded packet.
        """

        encoded['message'].network_id = self.network_id
        topic = '{}{}/{}'.format(self.DATA_TOPIC_PREFIX,
                                 self.network_id, encoded['nodeid'])
        self.mqtt.publish(topic, bytearray(encoded['message'].SerializeToString()))

    def encode_datapacket(self, frame, add_payload = False):
        """Encode arbitary datapacket for sending to MQTT.

        Args:
            frame (DsapDataRx): The decoded datapacket frame.
            add_payload (bool): True if payload will be included.

        Return: A dictionary containing the sender node ID and encoded frame.
        """

        packet = message_pb2.Message()
        packet.source_address = frame.indication['source_address'][0]
        packet.destination_address = frame.indication['destination_address'][0]
        packet.travel_time_ms = frame.indication['travel_time_s'][0] * 1000
        packet.tx_time = int(frame.indication['tx_unixtime'][0])
        packet.rx_time = int(frame.indication['rx_unixtime'][0])

        packet.rx_data.source_endpoint = frame.indication['source_endpoint'][0]
        packet.rx_data.destination_endpoint = \
                frame.indication['destination_endpoint'][0]
        packet.rx_data.qos = frame.indication['qos'][0]
        # Do not add payload if not presend and asked for
        if 'apdu' in frame.indication and add_payload:
            packet.rx_data.payload = frame.indication['apdu'][0]
        return {'nodeid' : frame.indication['source_address'][0],
                'message': packet}

    def encode_traffic_diagnostics(self, frame):
        """Encode traffic diagnostics for sending to MQTT.

        Args:
            frame (DsapTrafficDiagnostics): A decoded traffic diagnostics frame.

        Return: A dictionary containing the sender node ID and encoded frame.
        """

        packet = self.encode_datapacket(frame)

        packet['message'].diagnostics.access_cycles = frame.indication['access_cycles'][0]
        packet['message'].diagnostics.cluster_channel_MHz = \
            convert_channel_to_frequency(frame.indication['cluster_channel'][0],
                                         self.stack_profile)
        packet['message'].diagnostics.channel_reliability = \
            frame._convert_ratio_to_percentages(frame.
                                                indication
                                                ['channel_reliability'][0])
        packet['message'].diagnostics.rx_amount = \
            frame.indication['rx_amount'][0]
        packet['message'].diagnostics.tx_amount = \
            frame.indication['tx_amount'][0]
        packet['message'].diagnostics.aloha_rx_ratio = \
            frame._convert_ratio_to_percentages(frame.indication
                                                ['aloha_rx_ratio'][0])
        packet['message'].diagnostics.reserved_rx_success_ratio = \
            frame._convert_ratio_to_percentages(frame.indication
                                            ['reserved_rx_success_ratio'][0])
        packet['message'].diagnostics.data_rx_ratio = \
            frame._convert_ratio_to_percentages(frame.indication
                                            ['data_rx_ratio'][0])
        packet['message'].diagnostics.rx_duplicate_ratio = \
            frame._convert_ratio_to_percentages(frame.indication
                                            ['rx_duplicate_ratio'][0])
        packet['message'].diagnostics.cca_success_ratio = \
            frame._convert_ratio_to_percentages(frame.indication
                                            ['cca_success_ratio'][0])
        packet['message'].diagnostics.broadcast_ratio = \
            frame._convert_ratio_to_percentages(frame.indication
                                                ['broadcast_ratio'][0])
        packet['message'].diagnostics.failed_unicast_ratio = \
            frame._convert_ratio_to_percentages(frame.indication
                                                ['failed_unicast_ratio'][0])
        packet['message'].diagnostics.max_reserved_slot_usage = \
            frame._convert_ratio_to_percentages(frame.indication
                                                ['max_reserved_slot_usage'][0],
                                                12)
        packet['message'].diagnostics.avg_reserved_slot_usage = \
            frame._convert_ratio_to_percentages(frame.indication
                                                ['average_reserved_slot_usage']\
                                                [0], 12)
        packet['message'].diagnostics.max_aloha_slot_usage = \
            frame._convert_ratio_to_percentages(frame.indication
                                                ['max_aloha_slot_usage'][0], 4)
        return packet

    def encode_neighbor_diagnostics(self, frame):
        """Encode neighbor diagnostics for sending to MQTT.

        Args:
            frame (DsapNeighborDiagnostics): A decoded neighbors diagnostics
                frame.

        Return: A dictionary containing the sender node ID and encoded frame.
        """

        packet = self.encode_datapacket(frame)

        if len(frame.indication['neighbors'][0]) > 0:
            for neighbor in frame.indication['neighbors'][0]:
                _neighbor = packet['message'].diagnostics.neighbors.add()
                _neighbor.address = neighbor['address']
                _neighbor.cluster_channel_MHz = \
                    convert_channel_to_frequency(neighbor['cluster_channel'],
                                                 self.stack_profile)
                _neighbor.radio_power_dB = \
                    frame._convert_power_to_db(neighbor['radio_power'],
                                               self.stack_profile)
                _neighbor.rssi_dBm = \
                    frame._convert_rssi_to_dbm(neighbor['rssi'],
                                               self.stack_profile)
                # Switch by node info
                if neighbor['node_info'] == \
                   DatapacketNeighborDiagnostics.NODEINFO_MEMBER:
                    _neighbor.neighbor_type = message_pb2.Neighbor.MEMBER
                elif neighbor['node_info'] == \
                DatapacketNeighborDiagnostics.NODEINFO_SYNCHRONIZED_CLUSTER:
                    _neighbor.neighbor_type = message_pb2.Neighbor.SYNC_CLUSTER
                elif neighbor['node_info'] == \
                    DatapacketNeighborDiagnostics.NODEINFO_ASSOCIATED_CLUSTER:
                    _neighbor.neighbor_type = \
                        message_pb2.Neighbor.ASSOCIATED_CLUSTER
                else:
                    _neighbor.neighbor_type = \
                        message_pb2.Neighbor.NEIGHBOR_TYPE_UNKNOWN
        else:
            # Create 1-sized list
            _neighbor = packet['message'].diagnostics.neighbors.add()
            _neighbor.no_neighbors = True

        return packet

    def encode_node_diagnostics(self, frame):
        """Encode node diagnostics for sending to MQTT.

        Args:
            frame (DsapNodeDiagnostics): A decoded node diagnostics frame.

        Return: A dictionary containing the sender node ID and encoded frame.
        """

        packet = self.encode_datapacket(frame)

        packet['message'].diagnostics.access_cycle_ms = \
            frame.indication['access_cycle'][0]
        # Map by role
        self._put_diagnostics_role_to_packet(packet['message'],
                                             frame.indication['role'][0])

        packet['message'].diagnostics.voltage = (2.0 +
            frame.indication['voltage'][0]/100.0)
        packet['message'].diagnostics.max_buffer_usage = \
            frame._convert_ratio_to_percentages(frame.indication
                                                ['max_buffer_usage'][0])
        packet['message'].diagnostics.average_buffer_usage = \
            frame._convert_ratio_to_percentages(frame.indication
                                                ['average_buffer_usage'][0])
        packet['message'].diagnostics.mem_alloc_fails = \
            frame.indication['mem_alloc_fails'][0]
        packet['message'].diagnostics.buf_delay_ms.\
            append(frame.indication['normal_priority_buf_delay'][0] * 1000)
        packet['message'].diagnostics.buf_delay_ms.\
            append(frame.indication['high_priority_buf_delay'][0] * 1000)
        packet['message'].diagnostics.scans = frame.indication['scans'][0]
        # DL values by qos
        for i in range(0,2):
            packet['message'].diagnostics.dl_average_ms.\
                append(frame.indication['dl_delay_avg_{}'.format(i)][0] *
                       128.0 / 1000)
            packet['message'].diagnostics.dl_minimum_ms.\
                append(frame.indication['dl_delay_min_{}'.format(i)][0] *
                       128.0 / 1000)
            packet['message'].diagnostics.dl_maximum_ms.\
                append(frame.indication['dl_delay_max_{}'.format(i)][0] *
                       128.0 / 1000)
            packet['message'].diagnostics.dl_samples.\
                append(frame.indication['dl_delay_samples_{}'.format(i)][0])
            packet['message'].diagnostics.dropped.\
                append(frame.indication['dropped_packets_{}'.format(i)][0])
            # Cost infos
            cost = packet['message'].diagnostics.cost.add()
            cost.next_hop_address = frame.indication['cost_info_next_hop_{}'.
                                                     format(i)][0]
            cost.cost = frame.indication['cost_info_cost_{}'.format(i)][0]
            cost.quality = frame._convert_ratio_to_percentages(frame.indication
                ['cost_info_link_quality_{}'.format(i)][0])

        packet['message'].diagnostics.sink_address = \
                frame.indication['cost_info_sink'][0]

        # Events
        if len(frame.indication['events'][0]) > 0:
            for event in frame.indication['events'][0]:
                if event in event_to_pbevent_map:
                    packet['message'].diagnostics.events.\
                        append(event_to_pbevent_map[event])
                else:
                    packet['message'].diagnostics.events.\
                        append(message_pb2.DiagnosticsData.EVENT_UNKNOWN)
        else:
            # Create 1-sized list
            packet['message'].diagnostics.events.\
                append(message_pb2.DiagnosticsData.ROLE_NO_EVENTS)

        packet['message'].diagnostics.duty_cycle = \
            frame._convert_ratio_to_percentages(frame.indication['duty_cycle']
                                                [0],
                                                DUTY_CYCLE_MAX_VALUE)

        packet['message'].diagnostics.antenna = \
                            frame.indication['current_antenna'][0]

        return packet

    def encode_boot_diagnostics(self, frame):
        """Encode boot diagnostics for sending to MQTT.

        Args:
            frame (DsapBootDiagnostics): A decoded boot diagnostics frame.

        Return: A dictionary containing the sender node ID and encoded frame.
        """

        packet = self.encode_datapacket(frame)

        packet['message'].diagnostics.boot_count = \
            frame.indication['boot_count'][0]
        # Map by role
        self._put_diagnostics_role_to_packet(packet['message'],
                                             frame.indication['node_role'][0])
        packet['message'].diagnostics.sw_version_devel = \
            frame.indication['sw_dev_version'][0]
        packet['message'].diagnostics.sw_version_maintenance = \
            frame.indication['sw_maint_version'][0]
        packet['message'].diagnostics.sw_version_minor = \
            frame.indication['sw_minor_version'][0]
        packet['message'].diagnostics.sw_version_major = \
            frame.indication['sw_major_version'][0]
        packet['message'].diagnostics.scratchpad_sequence = \
            frame.indication['scratchpad_sequence'][0]
        if frame.indication['hw_magic'][0] in hwmagic_to_pbhwmagic_map:
            packet['message'].diagnostics.hw_magic = \
                hwmagic_to_pbhwmagic_map[frame.indication['hw_magic'][0]]
        else:
            packet['message'].diagnostics.hw_magic = \
                message_pb2.DiagnosticsData.HWMAGIC_UNKNOWN
        if frame.indication['stack_profile'][0] in \
           stackprofile_to_pbstackprofile_map:
            packet['message'].diagnostics.stack_profile = \
                stackprofile_to_pbstackprofile_map[frame.indication
                                                   ['stack_profile'][0]]
        else:
            packet['message'].diagnostics.stack_profile = \
                message_pb2.DiagnosticsData.PROFILE_UNKNOWN
        packet['message'].diagnostics.otap_enabled = \
                frame.indication['otap_enabled'][0]
        packet['message'].diagnostics.boot_line_number = \
                frame.indication['boot_line_number'][0]
        packet['message'].diagnostics.file_hash = \
                frame.indication['file_hash'][0]

        # Convert stack traces to uint32s
        try:
            values = struct.unpack('<III', frame.indication['stack_trace'][0])
            for value in values:
                packet['message'].diagnostics.stack_trace.append(value)
        except Exception as e:
            print "WNT plugin error. Stack trace unpack failed. Reason: "+str(e)

        return packet

    def _encode_remoteapi_response(self, frame):
        """Encode Remote API response for sending to MQTT.

        Args:
            frame (DsapRemoteApiConfirmation): A decoded Remote API confirmation

        Returns (object): A MQTT packet containing the Remote API confirmation.
        """

        packet = self.encode_datapacket(frame)
        self.remoteapi_handler.encode_confirmation(frame, packet)
        return packet

    def kill(self):
        """Kill the plug-in thread.

        Kills the plug-in thread by setting self.running to False.
        """

        self.running = False

    def _on_connect_callback(self, client, userdata, flags, rc):
        """Callback that is called when connection to MQTT has succeeded.
        Here, we're subscribing to the incoming topics.

        Args:
           client (object): The client instance for this callback.
           userdata (object): The private user data.
           flags (list): A list of flags.
           rc (int): The connection result.
        """

        # Check the connection result.
        if rc == ConnectionResult.Success:
            print "..Connected to MQTT"
        elif rc == ConnectionResult.IncorrectProtocolVersion:
            print "WNT MQTT Error: Incorrect protocol version!"
            self.kill()
            return
        elif rc == ConnectionResult.InvalidClientIdentifier:
            print "WNT MQTT Error: Invalid client identifier!"
            self.kill()
            return
        elif rc == ConnectionResult.ServerUnavailable:
            print "WNT MQTT Error: Server unavailable!"
            self.kill()
            return
        elif rc == ConnectionResult.BadCredentials:
            print "WNT MQTT Error: Bad username or password!"
            self.kill()
            return
        elif rc == ConnectionResult.NotAuthorised:
            print "WNT MQTT Error: Not authorised!"
            self.kill()
            return
        else:
            print "WNT MQTT Error: Unknown error: "+str(rc)
            self.kill()
            return

        # Sink to Sink communication, sink specific
        topic = self.SINK_TO_SINK_TOPIC_PREFIX + str(self.network_id) + '/' + \
                str(self.address)
        client.subscribe(topic)
        print "..Subscribed to " + topic

        # Sink to Sink communication, network wide
        topic = self.SINK_TO_SINK_TOPIC_PREFIX + str(self.network_id)
        client.subscribe(topic)
        print "..Subscribed to " + topic

        # WNT to Sink communication, sink specific
        topic = self.WNT_TO_SINK_TOPIC_PREFIX + str(self.network_id) + '/' + \
                str(self.address)
        client.subscribe(topic)
        print "..Subscribed to " + topic

        # WNT to Sink communication, network wide
        topic = self.WNT_TO_SINK_TOPIC_PREFIX + str(self.network_id)
        client.subscribe(topic)
        print "..Subscribed to " + topic

        topic = self.remoteapi_input_topic = \
                '{}{}'.format(self.REMOTEAPI_INPUT_TOPIC_PREFIX,
                              self.network_id)

        client.subscribe(topic)
        print "..Subscribed to " + topic

        # WNT to Node communication, node specific
        topic = self.WNT_TO_NODE_TOPIC_PREFIX + str(self.network_id) + '/' + \
                str(self.address)
        client.subscribe(topic)
        print "..Subscribed to " + topic

        # Send sink configuration to the backend.
        self._send_sink_config()

    def _on_message_callback(self, client, userdata, msg):
        """Got data from the input topic.

        Args:
            client (object): MQTT client object.
            userdata (object): the private user data
            msg (object): Incoming message
        """

        # Check if topic is app config
        if msg.topic.startswith(self.WNT_TO_SINK_TOPIC_PREFIX):
            self._on_wnt_to_sink_callback(msg)
        elif msg.topic.startswith(self.remoteapi_input_topic):
            # Put a little delay before handling remote API messages right
            # after start because this might be an old one before restart.
            if (time.time() - self.start_time) < self.STATE_CHANGE_WAIT_TIME_S:
                time.sleep(self.STATE_CHANGE_WAIT_TIME_S)
            self.remoteapi_handler.on_remoteapi_request_callback(msg)
        elif msg.topic.startswith(self.SINK_TO_SINK_TOPIC_PREFIX):
            self._on_sink_to_sink_callback(msg)
        elif msg.topic.startswith(self.WNT_TO_NODE_TOPIC_PREFIX):
            self._on_wnt_to_node_callback(msg)

    def _on_sink_to_sink_callback(self, msg):
        """Called when a plug-in to itself or another plug-in message
        is received.

        Args:
            msg (object): The MQTT message object.
        """

        message = message_pb2.Message()
        message.ParseFromString(msg.payload)

        if message.sink_to_sink.HasField('sink_state_change') and \
           message.sink_to_sink.sink_state_change == message_pb2.RESTART:

            print "Sink state has changed: " + \
                str(message.sink_to_sink.sink_state_change)

            self.restarted = True

            # Send an empty message back to remove the old one.
            message = message_pb2.Message()
            path = '{}{}/{}'.format(self.SINK_TO_SINK_TOPIC_PREFIX,
                                    self.network_id,
                                    self.address)

            self.mqtt.publish(path,
                              bytearray(message.SerializeToString()),
                              qos=1,
                              retain = True)

    def _on_wnt_to_sink_callback(self, msg):
        """Called when a backend to sink message is received.

        Args:
            msg (object): The MQTT message object.
        """

        message = message_pb2.Message()
        message.ParseFromString(msg.payload)
        id = message.id

        print "wnt plugin: Received an WNT to SINK config message. Topic:{},"\
            "content:{}".format(msg.topic, message)

        response = message_pb2.Message()

        if message.HasField('app_config'):
            # Only change values that have been written
            is_modified = False

            try:
                app_config = self.device.get_app_config_data()
            except Exception as e:
                print "WNT plug-in failed to get app config: " + str(e)
                # App config get failed, create an empty config.
                app_config = {}
                app_config['diagnostic_data_interval'] = None
                app_config['app_config_data'] = None
                app_config['sequence_number'] = 0

            if message.app_config.HasField('interval') and \
               (app_config['diagnostic_data_interval'] !=
                message.app_config.interval):
                app_config['diagnostic_data_interval'] = \
                                    message.app_config.interval
                is_modified = True
            if message.app_config.HasField('app_config') and \
               (app_config['app_config_data'] != message.app_config.app_config):
                app_config['app_config_data'] = message.app_config.app_config
                is_modified = True
            if is_modified:
                # Modify sequence locally
                app_config['sequence_number'] = app_config['sequence_number'] \
                                                + 1
                if app_config['sequence_number'] >= 255:
                    app_config['sequence_number'] = 0

                try:
                    self.device.set_app_config_data(sequence_number =
                                        app_config['sequence_number'],
                                        diagnostic_data_interval =
                                        app_config['diagnostic_data_interval'],
                                        app_config =
                                        app_config['app_config_data'])
                    response.app_config_response.result = \
                        message_pb2.AppConfigResponse.OK
                except Exception as e:
                    print "WNT plug-in failed to set app config: "+str(e)
                    if hasattr(e, 'confirmation_result'):
                        response.app_config_response.result = \
                                                e.confirmation_result
                    else:
                        response.app_config_response.result = \
                                    message_pb2.AppConfigResponse.ERROR_UNKNOWN
            else:
                response.app_config_response.result = \
                                    message_pb2.AppConfigResponse.OK

        response.network_id = self.network_id
        response.source_address = self.address
        response.tx_time = int(time.time())

        self.mqtt.publish(self.sink_to_wnt_topic,
                          bytearray(response.SerializeToString()),
                          qos=1)

        # Send sink configuration back to backend
        self._send_sink_config()

    def _on_wnt_to_node_callback(self, msg):

        message = message_pb2.Message()
        message.ParseFromString(msg.payload)
        id = message.id

        print "WNT plug-in received an WNT to Node message. Topic:{},content:{}".format(msg.topic, message)

        response = message_pb2.Message()

        for node_message in message.node_messages:
            try:
                self.device.data_tx(dest_address = node_message.address,
                                    dst_endpoint = node_message.endpoint,
                                    data = node_message.payload)
            except Exception as e:
                print "WNT plug-in failed to send node data: "+str(e)

    def send_restart_to_self(self, network_id=None, address=None):
        """
        Send a restart state change message to the reloaded plug-in
        through MQTT.

        Args:
            network_id (int): Network ID if it changes during the restart.
            address (int): Sink address if it changes during the restart.

        """

        if network_id is None:
            network_id = self.network_id

        if address is None:
            address = self.address

        message = message_pb2.Message()
        message.network_id = self.network_id
        message.source_address = self.address
        message.tx_time = int(time.time())

        message.sink_to_sink.sink_state_change = message_pb2.RESTART

        path = '{}{}/{}'.format(self.SINK_TO_SINK_TOPIC_PREFIX,
                                network_id,
                                address)

        print "Sending restart message: "+str(path)
        self.mqtt.publish(path,
                          bytearray(message.SerializeToString()),
                          qos=1,
                          retain = True)

    def _send_sink_config(self):
        """Send sink specific configuration to the backend.
        """
        message = message_pb2.Message()
        message.network_id = self.network_id
        message.source_address = self.address
        message.tx_time = int(time.time())

        try:
            app_config = self.device.get_app_config_data()
            message.app_config.interval = app_config['diagnostic_data_interval']
            message.app_config.app_config = app_config['app_config_data']
        except Exception as e:
            print "WNT plugin: app config get failed! Reason: "+str(e)

        try:
            message.app_config.max_length = \
                        self.device.get_app_config_data_size()
        except Exception as e:
            print "WNT plugin: cannot determine app config size: {}".format(e)

        try:
            message.stack_profile = self.device.get_stack_profile()
        except Exception as e:
            print "WNT plugin: could not get stack profile! Reason: "+str(e)

        # Get channel map
        try:
            message.channel_map = self.device.get_channel_map()
        except Exception as e:
            print "WNT plugin: could not get channel map! Reason: "+str(e)

        # Get network channel
        try:
            message.network_channel = self.device.get_network_channel()
        except Exception as e:
            print "WNT plugin: could not get network channel! Reason: "+str(e)

        # Get encryption status
        try:
            message.security_enabled = (self.device.has_authentication_key()
                                        and self.device.has_cipher_key())
        except Exception as e:
            print "WNT plugin: could not get security status! Reason: "+str(e)

        # Get role
        try:
            self._convert_csap_role_to_role(message, self.device.get_role())
        except Exception as e:
            print "WNT plugin: could not get device role! Reason: "+str(e)

        # Get access cycle limits
        try:
            access_cycle_limits = self.device.get_access_cycle_limits()
            message.access_cycle_limits.min_ms = access_cycle_limits['min']
            message.access_cycle_limits.max_ms = access_cycle_limits['max']
        except Exception as e:
            print "WNT plugin: could not get max access cycle limits! Reason: "\
                +str(e)

        # Calculate channel map to frequency
        try:
            # Acquire maximum channel id
            limits = self.device.get_network_channel_limits()
            for id in range(limits[0], limits[1] + 1):
                mapping = message.channel_info.add()
                mapping.id = id
                mapping.freq_MHz = convert_channel_to_frequency(id,
                                            message.stack_profile)
        except Exception as e:
            print "WNT plugin: could not create channel mapping info! Reason: "\
                + str(e)

        # Tell version number of the sink
        try:
            version_numbers = self.device.get_version_numbers()
            message.diagnostics.sw_version_major = version_numbers['major']
            message.diagnostics.sw_version_minor = version_numbers['minor']
            message.diagnostics.sw_version_maintenance = \
                                            version_numbers['maintenance']
            message.diagnostics.sw_version_devel = \
                                            version_numbers['development']
        except Exception as e:
            print "WNT plugin: unable to read version number from sink: {}".\
                format(e)

        print "..Publish the sink configuration"
        for subpath in ['persistent', 'nonpersistent']:
            # Create paths for:
            #  sinktownt/sinkconfig/nonpersistent/<network_id>/<sink_id>
            #  sinktownt/sinkconfig/persistent/<network_id>/<sink_id>
            path = '{}{}/{}/{}'.format(self.SINK_TO_WNT_SINK_CONFIG_TOPIC_PREFIX,
                                       subpath,
                                       self.network_id,
                                       self.address)

            if subpath == 'persistent':
                retain = True
            else:
                retain = False

            self.mqtt.publish(path,
                              bytearray(message.SerializeToString()),
                              qos=1,
                              retain = retain)

    @classmethod
    def get_gateway_thread(cls, configuration):
        """Class method for getting the common gateway thread for
           all the plug-ins of this type running in this gateway.

           Return (Thread): The gateway thread.
        """
        class gateway_thread(Thread):
            """Gateway thread class.

            Sends the heartbeat with the gateway MAC address to the WNT
            backend.

            Args:
                configuration (dict): A dictionary containing the plug-in
                    configuration based on the gateway configuration .ini file.

            Attributes:
                configuration (dict): A dictionary containing the plug-in
                    configuration based on the gateway configuration .ini file.
                mac_address (str): The MAC address for the hardware where the
                    wirepas.gateway is running.
                heartbeat_packet (object): A MQTT message containing a single
                    heartbeat.
                heartbeatinterval (float): Interval in seconds how often the
                    heartbeat is sent.
                mqtt (object): The MQTT client object for the connection.
                kill_queue (Queue): Queue containing the kill message when
                    the heartbeat thread is killed.
            """

            # Set the topics.
            heartbeat_topic_prefix = 'heartbeat/'
            gateway_to_wnt_topic_prefix = 'gatewaytownt/'
            wnt_to_gateway_topic_prefix = 'wnttogateway/'
            will_topic_postfix = '/will'

            def __init__(self, configuration):
                super(gateway_thread, self).__init__(name='WNTGatewayThread')
                print "Creating the gateway thread for WNT"

                self.configuration = configuration
                # Generate the heartbeat packet
                # Topic is heartbeat/+MAC address
                self.mac_address = GatewayIdentity.get_mac_addr()
                self.heartbeat_topic = self.heartbeat_topic_prefix + self.mac_address
                self.heartbeat_packet = message_pb2.Message()
                self.heartbeat_packet.gateway_id = \
                    self.heartbeat_packet.gw_heartbeat.mac_address = \
                    GatewayIdentity.get_mac_addr()
                self.heartbeat_packet.gw_heartbeat.hostname = \
                    GatewayIdentity.get_hostname()
                self.heartbeat_packet = \
                    bytearray(self.heartbeat_packet.SerializeToString())

                if self.configuration['tlsenabled']:
                    self.wnt_cert_file = \
                        os.path.join(cur_dir, 'wnt_certs',
                                     self.configuration['certfile'])

                # Set heartbeat interval
                self.heartbeatinterval = self.configuration['heartbeatinterval']

                # Set necessary configuration for MQTT client
                self.mqtt = mqtt.Client()
                self.mqtt.username_pw_set(self.configuration['mqttusername'],
                                          self.configuration['mqttpassword'])
                self.mqtt.on_connect = on_connect_cb_generator(self)
                self.mqtt.on_message = on_message_cb_generator(self)
                self.mqtt.on_disconnect = on_disconnect_cb_generator(self)

                self.mqtt.will_set(topic = self.wnt_to_gateway_topic_prefix +
                                   self.mac_address +
                                   self.will_topic_postfix, qos=1, retain=True)

                if self.configuration['tlsenabled']:
                    self.mqtt.tls_set(self.wnt_cert_file, certfile=None,
                                      keyfile=None, cert_reqs=ssl.CERT_REQUIRED,
                                      tls_version=ssl.PROTOCOL_TLSv1_2,
                                      ciphers=None)

                self.mqtt.connect(self.configuration['host'],
                                  self.configuration['port'])
                self.mqtt.loop_start()

                self.kill_queue = Queue()

                self.start()

            def run(self):
                """Thread.run method that runs until self.kill_queue has an item

                Just publishes a heartbeat message every heartbeat interval.
                """

                while True:
                    self.mqtt.publish(self.heartbeat_topic, self.heartbeat_packet)
                    try:
                        self.kill_queue.get(timeout=self.heartbeatinterval)
                        break
                    except Empty:
                        pass

                self.mqtt.loop_stop()
                print 'WNT gateway thread killed.'

            def kill(self):
                """Kills the gateway thread.

                Kills the gateway thread by putting an item
                to the self.kill_queue.
                """

                self.kill_queue.put("die")

            def _on_connect_callback(self, client, userdata, flags, rc):
                """Callback that is called when connection to MQTT has succeeded
                Here, we're subscribing to the incoming topics.

                Args:
                client (object): The client instance for this callback.
                userdata (object): The private user data.
                flags (list): List of flags.
                rc (int): The connection result.
                """

                print "..WNT gateway thread connected"

                # WNT to gateway communication
                topic = self.wnt_to_gateway_topic_prefix + self.mac_address
                client.subscribe(topic)
                print "..Subscribed to " + topic

            def _on_message_callback(self, client, userdata, msg):
                """Got data from the input topic.

                Args:
                client (object): MQTT client object.
                userdata (object): the private user data
                msg (object): Incoming message
                """

                print "WNT: Gateway got a message.."
                # Nothing implemented yet..

        return gateway_thread(configuration)

    def _put_diagnostics_role_to_packet(self, packet, role):
        """
        Parse diagnostics node to WNT role

        Args:
            packet: Out: Protobuf message that shall contain node role
            role: Node role to be converted
        """

        # Map by role
        baserole = role & DatapacketNodeDiagnostics.ROLEMASK_BASE
        if baserole == DatapacketNodeDiagnostics.BASEROLE_HEADNODE:
            packet.diagnostics.role = commons_pb2.HEADNODE
        elif baserole == DatapacketNodeDiagnostics.BASEROLE_SINK:
            packet.diagnostics.role = commons_pb2.SINK
        elif baserole == DatapacketNodeDiagnostics.BASEROLE_SUBNODE:
            packet.diagnostics.role = commons_pb2.SUBNODE
        packet.diagnostics.cb_mac = role & DatapacketNodeDiagnostics.ROLEMASK_CBMAC
        packet.diagnostics.is_relay = role & DatapacketNodeDiagnostics.ROLEMASK_RELAY
        packet.diagnostics.is_autorole = role & DatapacketNodeDiagnostics.ROLEMASK_AUTOROLE

    def _convert_csap_role_to_role(self, packet, csap_role):
        """
        Convert csap role to 'fullrole' definition

        Args:
            packet: out: Protobuf packet
            csap_role: CSAP role

        Returns:
            FullRole definition of the role
        """
        if (csap_role & CsapNodeRole.AutoRole):
            packet.diagnostics.is_autorole = True
        else:
            packet.diagnostics.is_autorole = False

        if (csap_role & CsapNodeRole.LowLatency):
            packet.diagnostics.cb_mac = True
        else:
            packet.diagnostics.cb_mac = False

        if (csap_role & CsapNodeRole.RelayMode):
            packet.diagnostics.is_relay = True
        else:
            packet.diagnostics.is_relay = False

        # Base role
        baserole = csap_role & CsapNodeRole.BASEROLEMASK
        if baserole == CsapNodeRole.Headnode:
            packet.diagnostics.role = commons_pb2.HEADNODE
        elif baserole == CsapNodeRole.Sink:
            packet.diagnostics.role = commons_pb2.SINK
        elif baserole == CsapNodeRole.Subnode:
            packet.diagnostics.role = commons_pb2.SUBNODE
        else:
            packet.diagnostics.role = commons_pb2.ROLE_UNKNOWN

def on_connect_cb_generator(thread):
    """Callback generator for on_connect MQTT callbacks.

    Args:
        thread (Thread): That has the callback function.

    Return (func): A callback function.
    """

    def on_connect(client, userdata, flags, rc):
        """A function to call the thread callback method.
        Args:
           client (object): The client instance for this callback.
           flags (list): List of flags.
           userdata (object): The private user data.
           rc (int): The connection result.
        """

        thread._on_connect_callback(client, userdata, flags, rc)

    return on_connect

def on_message_cb_generator(thread):
    """Callback generator for on_message MQTT callbacks.

    Args:
        thread (Thread): That has the callback function.

    Return (func): A callback function.
    """

    def on_message(client, userdata, msg):
        """A function to call the thread callback method.

        Args:
           client (object): The client instance for this callback.
           userdata (object): The private user data.
           rc (int): The connection result.
        """

        thread._on_message_callback(client, userdata, msg)

    return on_message

def on_disconnect_cb_generator(thread):
    """Callback generator for on_disconnect MQTT callbacks.

    Args:
        thread (Thread): That has the callback function.

    Return (func): A callback function.
    """

    def on_disconnect(client, userdata, rc):
        """A function to call the thread callback method.
        Args:
           client (object): The client instance for this callback.
           userdata (object): The private user data.
           rc (int): The connection result.
        """

        print "..WNT disconnected! Retrying to connect.."

    return on_disconnect
