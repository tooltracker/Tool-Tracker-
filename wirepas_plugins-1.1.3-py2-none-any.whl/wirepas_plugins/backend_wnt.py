# Copyright 2018 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.
#

"""This module implements the backend connection to Wirepas Network Tool backend
for wirepas.gateway.

To configure the wirepas.gateway to use this module the gateway configuration
needs add a backend of type "wnt-v2".

Example configuration accepting all diagnostics and Remote API responses:
    # An example WNT backend configuration
    [backend:default_wnt]
    type: 'wnt-v2'
    host: '192.168.100.162'
    mqttusername: 'username'
    mqttpassword: 'password'
    tlsenabled: True
    certfile: 'extwirepas.pem'
    port: 8883
    datapackets: {'trafficdiagnostics-v1': 255, 'neighbordiagnostics-v1': 255, \
                  'nodediagnostics-v1': 255, 'bootdiagnostics-v1': 255, \
                  'nondiagnostic-v1': None, 'remoteapi-v1': 255}

"""

from __future__ import print_function

import os
import ssl
import sys
import time
import uuid
import struct
import paho.mqtt.client as mqtt

from threading import Thread
from Queue import Queue, Empty
from gatewaybackend import GatewayBackend
from gateway_identity import GatewayIdentity

# Logging
PRINT_TIME_FORMAT = "%H:%M:%S"
PRINT_DATA_RX_PACKET_INFORMATION = False

# Topics
TOPIC_DATA_TO_WNT_PREFIX = "data_to_wnt"
TOPIC_COMMUNICATION_TO_WNT_PREFIX = "communication_to_wnt"
TOPIC_COMMUNICATION_FROM_WNT_PREFIX = "communication_from_wnt"
TOPIC_GLOBAL_COMMUNICATION_FROM_WNT = "global_communication_from_wnt"
TOPIC_LAST_WILL_TO_WNT = "last_will_to_wnt"

# Versions
DATA_TO_WNT_PACKET_VERSION = 1
COMMUNICATION_FROM_WNT_PACKET_VERSION = 1

# Sizes
WNT_COMMUNICATION_DATA_PACKET_VERSION_SIZE = 2
WNT_COMMUNICATION_DATA_PACKET_SERIAL_FRAME_LENGTH_SIZE = 2
WNT_DATA_PACKET_SIZE_WITHOUT_APDU = 30

# Endpoints
ENDPOINT_DIAGNOSTICS_BOOT_SOURCE = 254
ENDPOINT_DIAGNOSTICS_DESTINATION = 255
ENDPOINT_WIREPAS_LOW_LIMIT = 240

# QoS
MQTT_DATA_PACKET_SENDING_QOS = 0

# Time related
MS_IN_S = 1000

current_dir = os.path.dirname(__file__)

def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)

class ConnectionResult:
    '''Connection result values for MQTT on connect callback.
    '''

    Success = 0
    IncorrectProtocolVersion = 1
    InvalidClientIdentifier = 2
    ServerUnavailable = 3
    BadCredentials = 4
    NotAuthorised = 5

class BackendWNT(GatewayBackend):
    """ The backend plug-in class for WNT connection.

    Args:
        device (MeshApiDevice): The MeshApiDevice this plug-in instance is
            connected to.
        configuration (dict): A dictionary containing the plug-in configuration
            based on the gateway configuration .ini file.
        gw_thread (Thread): Gateway thread created by the get_gateway_thread.

    NOTE: All arguments provided automatically by the wirepas.gateway.

    Attributes:
        device (MeshApiDevice): The MeshApiDevice this plug-in instance is
            connected to.
        configuration (dict): A dictionary containing the plug-in configuration
            based on the gateway configuration .ini file.
        gw_thread (Thread): Gateway thread created by the get_gateway_thread.
        gw_command_queue (Queue): A queue for commands to the wirepas.gateway.
        consumed_endpoints (set): A set of consumed destination
            endpoint numbers.
        mqtt_client (Object): The MQTT client object.
        running (bool): True if the backend should be running. False if not.
    """

    # The plug-in name.
    name = 'wnt-v2'

    def __init__(self, configuration, device, gw_thread = None):

        super(BackendWNT, self).__init__(configuration, device, gw_thread)

        # Print all the configuration parameters
        print("Parameters: " + str(self.configuration))

        # Generate sink pseudo id
        self.pseudo_id = uuid.uuid1()

        # The gw_command_queue is initially None.
        # Set later by the set_gw_command_queue method.
        self.gw_command_queue = None

        if self.configuration['tlsenabled']:
            self.wnt_cert_file = os.path.join(current_dir, 'wnt_certs',
                                              self.configuration['certfile'])

        # Get the endpoints that are specifically collected by
        # datapacket plugins.
        self.consumed_endpoints = set()
        datapacket_names = []

        # Store whitelist information
        if 'whitelist' in configuration:
            self.whitelist = configuration['whitelist']
        else:
            self.whitelist = None

        for datapacket_name in configuration['datapackets']:
            self.consumed_endpoints.add(configuration['datapackets']
                                        [datapacket_name])
            datapacket_names.append(datapacket_name)

        print("Receiving data from plugins: " + str(datapacket_names))

        # Remove the None endpoint.
        try:
            self.consumed_endpoints.remove(None)
        except KeyError:
            pass

        # Set necessary configuration for MQTT client
        self.mqtt_client = mqtt.Client()
        self.mqtt_client.username_pw_set(self.configuration['mqttusername'],
                                         self.configuration['mqttpassword'])
        self.mqtt_client.on_message = on_message_cb_generator(self)
        self.mqtt_client.on_connect = on_connect_cb_generator(self)
        self.mqtt_client.on_disconnect = on_disconnect_cb_generator(self)
        self.mqtt_client.will_set(TOPIC_LAST_WILL_TO_WNT +
                                  "/" + str(self.pseudo_id), qos=1)

        if self.configuration['tlsenabled']:
            self.mqtt_client.tls_set(self.wnt_cert_file, certfile=None, keyfile=None,
                                     cert_reqs=ssl.CERT_REQUIRED,
                                     tls_version=ssl.PROTOCOL_TLSv1_2, ciphers=None)

        self.mqtt_client.connect(self.configuration['host'], self.configuration['port'])
        self.mqtt_client.loop_start()
        print("Waiting for a connection")
        self.running = True
        self.start()

    def set_gw_command_queue(self, queue):
        """A method to set the GW command queue for sending
        commands to the main gateway thread.

        Args:
            queue (Queue): A Queue.Queue where commands can be put.
        """

        self.gw_command_queue = queue

    def gw_command(self, command):
        """Send a command to the gateway main thread using
        the queue.

        Args:
            command (str): A string containing the command to the gateway.
        """

        self.gw_command_queue.put({'backend':self, 'command':command})

    def run(self):
        """Thread.run method that runs until self.running is False.

        Collects all incoming datapackets from the self.rx_queue and
        publishes packets to MQTT.
        """

        while self.running:
            try:
                frame = self.rx_queue.get(timeout=1)

                # Get packet transmission and received times ( epoch )
                rx_time = frame.indication['rx_unixtime'][0]
                source_endpoint = int(frame.indication['source_endpoint'][0])
                destination_endpoint = int(frame.indication['destination_endpoint'][0])

                # Print data rx packet information
                if PRINT_DATA_RX_PACKET_INFORMATION:
                    source_address = int(frame.indication['source_address'][0])

                    print("Data Rx - Rx time: {} Source address: {} Source endpoint: {}".format(
                        time.strftime(PRINT_TIME_FORMAT, time.gmtime(rx_time)),
                        source_address,
                        source_endpoint))

                # Create binary packet
                # 2 bytes : WNT data packet version ( unsigned short )
                # 8   "   : received time Unix Epoch in ms ( unsigned long long )
                # n   "   : serial frame from Dual MCU API ( bytearray )
                packet = bytearray()
                packet.extend(struct.pack("H", DATA_TO_WNT_PACKET_VERSION))
                packet.extend(struct.pack("Q", rx_time * MS_IN_S))
                packet.extend(frame.binary_data)

                # Check should APDU be cleared
                if self.is_clear_apdu(source_endpoint, destination_endpoint):
                    # Overwrite APDU with zeros
                    packet = packet[:WNT_DATA_PACKET_SIZE_WITHOUT_APDU] + \
                             bytearray(len(packet) - WNT_DATA_PACKET_SIZE_WITHOUT_APDU)

                qos = MQTT_DATA_PACKET_SENDING_QOS

                # Sink's boot diagnostics messages needs to be send with qos > 0
                # With this implementation all boot messages are sent with qos 1
                if source_endpoint == ENDPOINT_DIAGNOSTICS_BOOT_SOURCE and \
                    destination_endpoint == ENDPOINT_DIAGNOSTICS_DESTINATION:
                    qos = 1

                self.mqtt_client.publish(TOPIC_DATA_TO_WNT_PREFIX + '/' +
                                         str(self.pseudo_id), packet, qos=qos)

            except Empty:
                pass

        self.mqtt_client.loop_stop()

    def kill(self):
        """Kill the plug-in thread.

        Kills the plug-in thread by setting self.running to False.
        """

        self.running = False

    def is_clear_apdu(self, source_endpoint, destination_endpoint):
        """Check should APDU be cleared.

        Args:
           source_endpoint (int): Data packet source endpoint.
           destination_endpoint (int): Data packet destination endpoint.
        """

        if source_endpoint >= ENDPOINT_WIREPAS_LOW_LIMIT or \
            destination_endpoint >= ENDPOINT_WIREPAS_LOW_LIMIT:
            return False

        if self.whitelist is not None:
            for key, value in self.whitelist.iteritems():
                if source_endpoint in value['source'] and \
                    destination_endpoint in value['destination']:
                    return False

        return True

    def _on_connect_callback(self, mqtt_client, userdata, flags, rc):
        """Callback that is called when connection to MQTT has succeeded.
        Here, we're subscribing to the incoming topics.

        Args:
           mqtt_client (object): The MQTT client instance for this callback.
           userdata (object): The private user data.
           flags (list): A list of flags.
           rc (int): The connection result.
        """

        # Check the connection result.
        if rc == ConnectionResult.Success:
            print("Connected to MQTT")

            # Subscribe to global communication topic
            mqtt_client.subscribe(TOPIC_GLOBAL_COMMUNICATION_FROM_WNT)
            print("Subscribed to topic: " + TOPIC_GLOBAL_COMMUNICATION_FROM_WNT)

            # Subscribe to communication topic
            communication_topic = TOPIC_COMMUNICATION_FROM_WNT_PREFIX + \
                                  "/" + str(self.pseudo_id)
            mqtt_client.subscribe(communication_topic)
            print("Subscribed to topic: " + communication_topic)

        elif rc == ConnectionResult.IncorrectProtocolVersion:
            eprint("WNT MQTT Error: Incorrect protocol version")
            self.kill()
            return
        elif rc == ConnectionResult.InvalidClientIdentifier:
            eprint("WNT MQTT Error: Invalid client identifier")
            self.kill()
            return
        elif rc == ConnectionResult.ServerUnavailable:
            eprint("WNT MQTT Error: Server unavailable")
            self.kill()
            return
        elif rc == ConnectionResult.BadCredentials:
            eprint("WNT MQTT Error: Bad username or password")
            self.kill()
            return
        elif rc == ConnectionResult.NotAuthorised:
            eprint("WNT MQTT Error: Not authorised")
            self.kill()
            return
        else:
            eprint("WNT MQTT Error: Unknown error: " + str(rc))
            self.kill()
            return

    def _on_message_callback(self, client, userdata, msg):
        """Got data from the input topic.

        Args:
            client (object): MQTT client object.
            userdata (object): the private user data
            msg (object): Incoming message
        """

        if msg.topic.startswith(TOPIC_GLOBAL_COMMUNICATION_FROM_WNT) or \
           msg.topic.startswith(TOPIC_COMMUNICATION_FROM_WNT_PREFIX):
            self._on_communication_from_wnt(msg)

    def _on_communication_from_wnt(self, msg):
        """Got data from the (global) communication from WNT topic.

        Args:
            msg (object): Incoming message
        """

        # Message payload
        # 2 bytes : WNT communication data packet version ( unsigned short )
        # Serial frame length and data is repeated n times
        # 2 bytes : serial frame length ( unsigned short )
        # n   "   : serial frame to Dual MCU API ( bytearray )

        version_size = WNT_COMMUNICATION_DATA_PACKET_VERSION_SIZE

        packet_version = struct.unpack("H", msg.payload[:version_size])[0]
        if packet_version != COMMUNICATION_FROM_WNT_PACKET_VERSION:
            eprint("Invalid COMMUNICATION_FROM_WNT_PACKET_VERSION")
            eprint("Received: " + str(packet_version))
            eprint("Supported: " + str(COMMUNICATION_FROM_WNT_PACKET_VERSION))

            return

        serial_frame_length_size = \
            WNT_COMMUNICATION_DATA_PACKET_SERIAL_FRAME_LENGTH_SIZE

        position = WNT_COMMUNICATION_DATA_PACKET_VERSION_SIZE
        payload_length = len(msg.payload)

        while payload_length - position > 0:
            end_position = position + serial_frame_length_size
            serial_frame_length = \
                struct.unpack("H",
                              msg.payload[position:end_position])[0]
            position += serial_frame_length_size

            end_position = position + serial_frame_length
            serial_frame = \
                self.device.send_serial_frame(msg.payload[position:end_position])
            position += serial_frame_length

            self.mqtt_client.publish(TOPIC_COMMUNICATION_TO_WNT_PREFIX + '/' +
                                     str(self.pseudo_id), serial_frame, qos=1)

            if payload_length - position < 0:
                eprint("Data length mismatch while parsing communication message from WNT")

def on_connect_cb_generator(thread):
    """Callback generator for on_connect MQTT callbacks.

    Args:
        thread (Thread): That has the callback function.

    Return (func): A callback function.
    """

    def on_connect(client, userdata, flags, rc):
        """A function to call the thread callback method.
        Args:
           client (object): The client instance for this callback.
           flags (list): List of flags.
           userdata (object): The private user data.
           rc (int): The connection result.
        """

        thread._on_connect_callback(client, userdata, flags, rc)

    return on_connect

def on_message_cb_generator(thread):
    """Callback generator for on_message MQTT callbacks.

    Args:
        thread (Thread): That has the callback function.

    Return (func): A callback function.
    """

    def on_message(client, userdata, msg):
        """A function to call the thread callback method.

        Args:
           client (object): The client instance for this callback.
           userdata (object): The private user data.
           rc (int): The connection result.
        """

        thread._on_message_callback(client, userdata, msg)

    return on_message

def on_disconnect_cb_generator(thread):
    """Callback generator for on_disconnect MQTT callbacks.

    Args:
        thread (Thread): That has the callback function.

    Return (func): A callback function.
    """

    def on_disconnect(client, userdata, rc):
        """A function to call the thread callback method.
        Args:
           client (object): The client instance for this callback.
           userdata (object): The private user data.
           rc (int): The connection result.
        """

        eprint("WNT disconnected! Retrying to connect")

    return on_disconnect
