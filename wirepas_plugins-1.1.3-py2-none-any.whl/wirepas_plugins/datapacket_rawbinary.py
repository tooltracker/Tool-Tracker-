# Copyright 2018 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.
#

import struct

from meshapidsap import DsapDataRx

class DatapacketRawBinary(DsapDataRx):
    '''
    This class handles Raw data packets

    It is used to store the payload as such without any additional modifications
    '''

    def __init__(self, dest_endpoint):
        super(DatapacketRawBinary, self).__init__(dest_endpoint=dest_endpoint)

    @classmethod
    def get_name(self):
        return 'rawbinary-v1'
    

