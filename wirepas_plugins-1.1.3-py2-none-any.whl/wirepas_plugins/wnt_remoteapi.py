# Copyright 2018 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.

"""The classes for Remote API operations for backend_wnt.py

Attributes:
    OperationType (class): Operation type enums.
    RemoteApiOperation (class): Class for defining single remote api operation.
    BackendWntRemoteApi (class): Class for handling remote api operations in
        the WNT backend.
"""

import imp
import time

from wirepas.remote_api.remote_api import *
from meshapicsap import CsapNodeRole, CsapAttribId
from meshapidsap import ADDRESS_BROADCAST

import commons_pb2
import message_pb2
import remote_api_pb2

class OperationType(object):
    """Operation type enums for Remote API operations.

    Attributes:
       CONFIGURE (int): A new configuration.
       ACTIVATE (int): Activate the configuration.
       CANCEL (int): Cancel the Remote API operation.
    """

    CONFIGURE = 1
    ACTIVATE = 2
    CANCEL = 3

class RemoteApiOperation(object):
    """A single remote API operation.

    Class for defining single remote api operation.

    Args:
        device (MeshApiDevice): The sink where the operation is done on.
        definition (object): MQTT object containing the operation definitions.
        retry_interval (float): Time in seconds how often the operation can be
            retried.
        activation_time (float): Time since epoch when the configuration should
            be activated.
        is_cancel (bool): True if the operation is a cancel for previous Remote
            API operation.

    Attributes:
        definition (object): MQTT object containing the operation definitions.
        last_time (float): Time since epoch since last retry.
        retry_interval (float): Time in seconds how often the operation can be
            retried.
        activation_time (float): Time since epoch when the configuration should
            be activated.
        start_time (float): Time since epoch when remote operation has started.
        is_cancel (bool): True if the operation is a cancel for previous Remote
            API operation.
        address (int): Node address of the operation target device.
    """

    # A dictionary of mappings of MQTT roles to Dual-MCU API roles.
    PBBaseRoleToCsapRole = {
        commons_pb2.SUBNODE : CsapNodeRole.Subnode,
        commons_pb2.HEADNODE : CsapNodeRole.Headnode,
        commons_pb2.SINK : CsapNodeRole.Sink
    }

    # Minimum time to take the image into use. This is for the single packet.
    MINIMUM_TAKE_INTO_USE = 11

    def __init__(self, device, definition, retry_interval,
                 activation_time, is_cancel=False):
        self.device = device

        # Protobuf definition
        self.definition = definition
        self.last_time = None
        self.retry_interval = retry_interval
        self.activation_time = activation_time
        # Time when remote operation has started
        self.start_time = None
        self.is_cancel = is_cancel

        # Generate target address, either unicast or broadcast
        if self.is_cancel:
            self.address = ADDRESS_BROADCAST
        elif self.definition.HasField('address'):
            self.address = self.definition.address
        else:
            self.address = ADDRESS_BROADCAST

    def check(self):
        """Check if packet should be sent again and send it.

        Returns (bool): True if should be sent again.
        """

        resend = False
        # If not sent at all or retry period has expired
        if self.last_time is None:
            resend = True
        elif time.time() >= (self.last_time + self.retry_interval):
            resend = True

        if resend:
            packet = self._generate_command()

            self.device.data_tx(data=packet,
                                qos=1,
                                dest_address=self.address,
                                src_endpoint=ENDPOINT_REQUEST_SRC,
                                dst_endpoint=ENDPOINT_REQUEST_DST
                                )
            print 'Sending remote api packet'
            self.last_time = time.time()

        return resend

    def affect_sink(self):
        """Tell if command requires operation on sink.

        Returns (bool): True if requires operation on sink.
        """
        if self.is_cancel:
            return False

        if self.address != ADDRESS_BROADCAST:
            return False

        # Role definition may affect cb_mac
        return True

    def get_operation_type(self):
        """Return operation type enum.

        Returns (int): See OperationType for return values.
        """
        if self.is_cancel:
            return OperationType.CANCEL

        if self.activation_time is not None:
            return OperationType.ACTIVATE

        return OperationType.CONFIGURE

    def _generate_command(self):
        """Generate Remote API command for downlink packet.

        Returns (str): A string containing the payload for the
             command datapacket.
        """
        instance = RemoteAPICommandMessage()
        retval = ''

        if not self.is_cancel:
            if (self.definition.HasField('role') and
                self.definition.HasField('cb_mac') and
                self.definition.HasField('is_autorole')):
                retval = retval + instance.csap_write(CsapAttribId.NodeRole,
                                                self._convert_pbrole_to_csap())
            if self.definition.HasField('network_address'):
                retval = retval + instance.csap_write(CsapAttribId.
                                                NetworkAddress,
                                                self.definition.network_address)
            if self.definition.HasField('network_channel'):
                retval = retval + instance.csap_write(CsapAttribId.
                                                NetworkChannel,
                                                self.definition.network_channel)
            if self.definition.HasField('cipher_key'):
                retval = retval + instance.csap_write(CsapAttribId.CipherKey,
                                                self.definition.cipher_key)
            if self.definition.HasField('authentication_key'):
                retval = retval + instance.csap_write(CsapAttribId.
                                        AuthenticationKey,
                                        self.definition.authentication_key)
            if self.definition.HasField('channel_map'):
                retval = retval + instance.csap_write(CsapAttribId.ChannelMap,
                                        self.definition.channel_map)
            # If there are actually any modifications, add begin and end values
            if len(retval) > 0:
                retval = instance.begin_withoutkey_command() + retval + \
                         instance.end()

        # Add cancel prior anything. This would allow sending same command
        # again with update command only.
        retval = instance.cancel() + retval

        # Image take into use is slightly different. Time must be calculated.
        if not self.activation_time is None:
            delay = self.activation_time - time.time()
            delay = max(delay, self.MINIMUM_TAKE_INTO_USE)
            retval = retval + instance.update(delay)

        return retval

    def reparameterize_sink(self):
        """Reparameterize sink according to request.

        Sink is stopped when this is done.
        """
        if not self.affect_sink():
            return

        if (self.definition.HasField('role') and
                self.definition.HasField('cb_mac') and
                self.definition.HasField('is_autorole')):
            # Could make turning on cb_mac:
            attrib_val = self._convert_pbrole_to_csap(commons_pb2.SINK)
            self.device.set_role(attrib_val)
        if self.definition.HasField('network_address'):
            self.device.set_network_address(self.definition.network_address)
        if self.definition.HasField('network_channel'):
            self.device.set_network_channel(self.definition.network_channel)
        if self.definition.HasField('cipher_key'):
            self.device.set_cipher_key(self.definition.cipher_key)
        if self.definition.HasField('authentication_key'):
            self.device.set_authentication_key(self.definition.
                                               authentication_key)
        if self.definition.HasField('channel_map'):
            self.device.set_channel_map(self.definition.channel_map)

    def _convert_pbrole_to_csap(self, baserole=None):
            """Convert PBRole to CSAP.

            Converts the operation role to Dual-MCU API CSAP role.
            If baserole is set then will use that instead of the operation
            definition role.

            Args:
                baserole (int): Optional parameter to convert.

            Returns (int): CSAP role in an integer.
            """
            if baserole is None:
                baserole = self.definition.role

            retval = self.PBBaseRoleToCsapRole[baserole]

            if self.definition.cb_mac:
                retval = retval | CsapNodeRole.LowLatency
            # Check autorole but only in case of != sink
            if self.definition.is_autorole and (baserole != commons_pb2.SINK):
                retval = retval | CsapNodeRole.AutoRole

            return retval

class BackendWntRemoteApi(object):
    """WNT Remote API helper class.

    Class for handling Remote API operations in the WNT backend.

    Args:
        plugin (BackendWNT): WNT backend plug-in instance that is sending the
            commands.
        device (MeshApiDevice): The MeshApiDevice this plug-in instance is
            connected to.
        mqtt (object): The MQTT client object of the backend connection.
        remotetownttopic (str): String containing the MQTT topic for remote
            operations responses to WNT backend.
        sink_address (int): The sink address the plug-in is commanding.
        network_id (int): The network ID.

    Attributes:
        plugin (BackendWNT): WNT backend plug-in instance that is sending the
            commands.
        device (MeshApiDevice): The MeshApiDevice this plug-in instance is
            connected to.
        commands (list): The list of Remote API commands.
        mqtt (object): The MQTT client object of the backend connection.
        remotetownttopic (str): String containing the MQTT topic for remote
            operations responses to WNT backend.
        sink_address (int): The sink address the plug-in is commanding.
        network_id (int): The network ID.
        new_address (int): New sink address after the operation.
        new_network_id (int): New network ID after the operation.
    """

    # For example, if gateway just started and got an old request, use this
    # value as delay value.
    MINIMUM_TAKE_INTO_USE = 60

    def __init__(self, plugin, device, mqtt, remotetownttopic, sink_address,
                 network_id):
        self.plugin = plugin
        self.device = device
        self.commands = []
        self.activation_time = None
        self.mqtt = mqtt
        self.remotetownttopic = remotetownttopic
        self.sink_address = sink_address
        self.request_starttime = None
        self.network_id = network_id
        self.new_address = None
        self.new_network_id = None

    def on_remoteapi_request_callback(self, msg):
        """Callback for Remote API requests.

        Args:
            msg (object): MQTT message.
        """
        message = message_pb2.Message()
        message.ParseFromString(msg.payload)
        self.commands = []
        self.activation_time = None
        self.request_starttime = None

        print "wnt plugin: Received an remote api message from the WNT "\
            "backend. Topic:{},msg:{}".format(msg.topic, message)

        # Mark down the activation time
        if message.remoteapi_requests.HasField('activation_time'):
            if time.time() > (message.remoteapi_requests.activation_time) or \
               self.plugin.restarted:

                # The plug-in was restarted just now. Ignore the command.
                print 'Ignoring the remote API command because plug-in ' \
                    'just restarted or activation time in the past'

                # We can forget that the plug-in was restarted once we get
                # the old activation. This allows the next activation message
                # to come through
                self.plugin.restarted = False

                return

            # If we are already late, do nothing. Only send error frame
            elif time.time() > (message.remoteapi_requests.activation_time +
                BackendWntRemoteApi.MINIMUM_TAKE_INTO_USE):
                print 'Too late to receive remote API command!'
                self._send_remote_to_wnt_msg(remote_api_pb2.TOO_LATE,
                                             self._get_operation_type(message))
                return

            else:
                self.activation_time = max(message.remoteapi_requests.
                                           activation_time,
                                           time.time() + BackendWntRemoteApi.
                                           MINIMUM_TAKE_INTO_USE)
                print 'Activation time in {} seconds'.\
                    format(self.activation_time - time.time())

        # Store request starttime
        if message.remoteapi_requests.HasField('start_time'):
            self.request_starttime = message.remoteapi_requests.start_time

        # See if cancelled. If so, other requests are not there
        if message.remoteapi_requests.HasField('cancel') and \
           message.remoteapi_requests.cancel:
            instance = RemoteApiOperation(self.device,
                                          None,
                                          message.remoteapi_requests.
                                          retry_interval,
                                          activation_time=self.activation_time,
                                          is_cancel=True)
            self.commands.append(instance)
        else:
            empty_message_found = False
            for request in message.remoteapi_requests.messages:
                if request.is_empty:
                    # If is_empty, it is not a valid message. Usually as a
                    # sole item in the array but just to make sure handled
                    # this way.
                    empty_message_found = True
                    continue

                instance = RemoteApiOperation(self.device,
                                              request,
                                              message.remoteapi_requests.
                                              retry_interval,
                                              activation_time=
                                              self.activation_time)

                if request.HasField('address'):
                    self.new_address = request.address

                if request.HasField('network_address'):
                    self.new_network_id = request.network_address

                self.commands.append(instance)

            # There was an empty message. Clear the remotetownt topic.
            if empty_message_found:
                message = message_pb2.Message()
                self.mqtt.publish(self.remotetownttopic,
                                  bytearray(message.SerializeToString()),
                                  qos=1, retain=True)

    def send_loop(self):
        """Iterate one Remote API command at a time and send if necessary.

        Called in the BackendWNT.run() inner-loop. If a command
        was processed or the whole list has been gone through
        then returns.
        """

        # Check if activation time is there
        if not self.activation_time is None:
            if time.time() >= self.activation_time:
                self._sink_activation()
                self.commands = []
                self.activation_time = None

        operation_type = None

        try:
            for command in self.commands:
                operation_type = command.get_operation_type()

                # Only send one command at the time for not to over-exhaust the
                # system
                if command.check():
                    return

        except Exception as e:
            print 'Unable to send Remote API command to network: {}'.format(e)
            self._send_remote_to_wnt_msg(remote_api_pb2.INVALID_VALUE,
                                         operation_type)
            self.commands = []
            self.activation_time = None

    def _get_operation_type(self, message):
        """Return operation type based on the MQTT message.

        Return (int): See OperationType class for values.
        """

        if message.remoteapi_requests.HasField('cancel') \
           and message.remoteapi_requests.cancel:
            return OperationType.CANCEL

        if message.remoteapi_requests.HasField('activation_time'):
            return OperationType.ACTIVATE

        return OperationType.CONFIGURE

    def _sink_activation(self):
        """Activate sink on modifications.

        Activate any configurations that affect the sink also and restart
        the gateway if needed.
        """
        # See if activation is actually needed -> broadcast
        # requests != node role present
        activation_needed = False
        for command in self.commands:
            if command.affect_sink():
                activation_needed = True
                break

        # If activation needed, reparameterize the sink accordingly
        result = remote_api_pb2.OK
        if activation_needed:
            self.device.stack_stop()
            try:
                for command in self.commands:
                    command.reparameterize_sink()
            except Exception as e:
                result = remote_api_pb2.SINK_CONFIG_ERROR

            # Restart sink.
            self.device.stack_start()

            # Restart the gateway
            restart_gateway = True
        else:
            restart_gateway = False

        # And send the response
        self._send_remote_to_wnt_msg(result, OperationType.ACTIVATE,
                                     activation_needed)

        if restart_gateway:
            # Send a command to future plug-in that it has
            # restarted, possibly with new parameters.
            self.plugin.send_restart_to_self(network_id=self.new_network_id,
                                             address=self.new_address)

            # Restart the gateway.
            self.plugin.gw_command('restart')

    def encode_confirmation(self, frame, packet):
        """Encode confirmation to Protobuf format.

        Generic data packet operations are parsed in parent class. Appends
        the Remote API confirmation information to an MQTT packet.

        Args:
            frame (DsapDataRx): Received Remote API confirmation
            packet (object): MQTT packet containing datapacket where the Remote
                API response information is appended to.
        """
        RemoteApiConfigMapToBp = {
            MessageType.AccessDenied : remote_api_pb2.ACCESS_DENIED,
            MessageType.WriteOnly : remote_api_pb2.WRITE_ONLY_ATTRIBUTE,
            MessageType.InvalidBroadcast : remote_api_pb2.INVALID_BC_REQUEST,
            MessageType.InvalidBegin : remote_api_pb2.INVALID_BEGIN,
            MessageType.NoSpace : remote_api_pb2.NO_SPACE_FOR_RESPONSE,
            MessageType.InvalidValue : remote_api_pb2.INVALID_VALUE,
            MessageType.InvalidLength : remote_api_pb2.INVALID_LENGTH,
            MessageType.UnknownRequest : remote_api_pb2.UNKNOWN_REQUEST,
        }

        status = remote_api_pb2.OK

        # Evaluate response. Only use single error value
        for response in frame.indication['responses'][0]:
            if not response['success']:
                if not response['response_id'] in RemoteApiConfigMapToBp:
                    status = remote_api_pb2.UNKNOWN_CONFIRMATION
                else:
                    status = RemoteApiConfigMapToBp[response['response_id']]
                break

        if not self.request_starttime is None:
            packet['message'].remoteapi_response.request_start_time = \
                self.request_starttime

        if not self.activation_time is None:
            packet['message'].remoteapi_response.request_activation_time = \
                int(self.activation_time)

        if 'cancel' in frame.indication:
            packet['message'].remoteapi_response.cancel_result = status
        elif 'update' in frame.indication:
            packet['message'].remoteapi_response.activate_result = status
        else:
            packet['message'].remoteapi_response.configure_result = status

    def _send_remote_to_wnt_msg(self, result, operation_type,
                                is_rebooted=False):
        """Send Remote API response to WNT backend.

        Args:
            result (int): Result of the operation (See remote_api_pb2 for
                enums)
            operation_type (int): Operation type (See OperationType class)
            is_rebooted (bool): True if the gateway has restarted.
        """
        # And send the response
        packet = message_pb2.Message()
        packet.source_address = self.sink_address
        packet.network_id = self.network_id
        packet.travel_time_ms = 0
        packet.tx_time = packet.rx_time = int(time.time())

        if operation_type == OperationType.CANCEL:
            packet.remoteapi_response.cancel_result = result
        elif operation_type == OperationType.ACTIVATE:
            packet.remoteapi_response.activate_result = result
        else:
            packet.remoteapi_response.configure_result = result

        packet.remoteapi_response.is_rebooted = is_rebooted
        if not self.request_starttime is None:
            packet.remoteapi_response.request_start_time = \
                self.request_starttime
        self.mqtt.publish(self.remotetownttopic,
                          bytearray(packet.SerializeToString()),
                          qos=1, retain=True)
