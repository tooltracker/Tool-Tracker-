# Copyright 2018 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.
#
'''IPv6 datapacket plug-in.
'''

from meshapidsap import DsapDataRx

class DatapacketIpv6(DsapDataRx):
    '''The IPv6 datapacket plug-in.

    Just collects all packets coming to destination endpoint 250.

    Args:
        dest_endpoint (int): The destination endpoint.
    '''

    def __init__(self, dest_endpoint=250):
        super(DatapacketIpv6, self).__init__(source_endpoint=dest_endpoint,
                                             dest_endpoint=dest_endpoint)

    @classmethod
    def get_name(cls):
        '''Returns the name for this datapacket class.
        '''
        return "ipv6-v1"
