# Copyright 2018 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.
#

from meshapidsap import DsapDataRx

class DatapacketRuuvi(DsapDataRx):
    '''
    This class handles Ruuvi measurements
    '''
    def __init__(self, dest_endpoint):
        super(DatapacketRuuvi, self).__init__(source_endpoint=11,
                                              dest_endpoint=dest_endpoint)

        # Payload content
        # 4 bytes: ID
        # 4 bytes: Temperature in 0.01C
        # 4 bytes: Pressure (Pa) in Q24.8
        # 4 bytes: Humidity (%RH) in Q24.10
        # 4 bytes: Acceleremoter X axis in mG
        # 4 bytes: Acceleremoter Y axis in mG
        # 4 bytes: Acceleremoter Z axis in mG

        self.payload['id'] = (None, 'uint32')
        self.payload['temp'] = (None, 'int32')
        self.payload['pres'] = (None, 'uint32')
        self.payload['humi'] = (None, 'uint32')
        self.payload['acc_x'] = (None, 'int32')
        self.payload['acc_y'] = (None, 'int32')
        self.payload['acc_z'] = (None, 'int32')

    @classmethod
    def get_name(cls):
        return 'ruuvi-v1'

    def parse_indication(self,
                         primitive_id,
                         frame_id,
                         payload_length,
                         payload,
                         compare = False):

        [a, b] = super(DatapacketRuuvi, self).parse_indication(primitive_id,
                         frame_id,
                         payload_length,
                         payload,
                         compare)
        if a:
            # Successful parsing, parse actual payload

            # Temperature
            self.indication['temp'] \
                = (float(self.indication['temp'][0])/100.0, 'float')

            # Pressure
            self.indication['pres'] \
                = (float(self.indication['pres'][0])/256.0, 'float')

            # Humidity
            self.indication['humi'] \
                = (float(self.indication['humi'][0])/1024.0, 'float')

            # Accelerometer
            self.indication['acc_x'] \
                = (float(self.indication['acc_x'][0])/1000.0, 'float')
            self.indication['acc_y'] \
                = (float(self.indication['acc_y'][0])/1000.0, 'float')
            self.indication['acc_z'] \
                = (float(self.indication['acc_z'][0])/1000.0, 'float')

        return a, b
