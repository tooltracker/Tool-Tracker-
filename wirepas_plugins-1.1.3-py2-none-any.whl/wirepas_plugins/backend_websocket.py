# Copyright 2018 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.

from gatewaybackend import GatewayBackend
from threading import Thread, Event
from Queue import Empty

from datapacket_neighbordiagnostics import DatapacketNeighborDiagnostics
from datapacket_nodediagnostics import DatapacketNodeDiagnostics
from datapacket_neighborscan import DatapacketNeighborScanV1
from datapacket_neighborscan import DatapacketNeighborScanV2

from wirepas.meshapidsap import DsapNodeDiagnostics

import debug
import datetime
import time
import json
import os
import imp

cur_dir = os.path.dirname(__file__)
# Some import magic
websocket_handler = imp.load_source('websocket_handler',
                                    os.path.join(cur_dir,
                                                 'backend_wpat_commons',
                                                 'websocket_handler.py'))
from websocket_handler import Actuactor


class BackendWebSocket(GatewayBackend):
    """
    Backend Wirepas Web Socket

    Sends data to the given target through a web socket connection.

    Attributes:
        address (int) : device address
        network_id (int) : wirepas network id
        travel_limit (int) : do not post messages whose travel time
                             exceeds this value
        identity (int) : secret shared with the backend (dummy)
        wshost (str) : websocket address

        consumed_endpoints (list) : endpoints being handled
        running (bool) : True whiel backend is running

    """
    name = 'websocket-v1'

    def __init__(self, configuration, device, gw_thread=None):
        """
        Sets up backend instance

        Args:
            configuration (dict) : dictionary with definitions from init file
            device (obj) : MeshApi device instance
            gw_thread (obj) : Object to access gateway thread

        """
        super(BackendWebSocket, self).__init__(
            configuration, device, gw_thread)

        # This is how the device can be commanded:
        self.address = self.device.get_address()
        self.network_id = self.device.get_network_address()

        debug.info("Websocket backend connection started \
                    for sink in address \
                    {0} for network {1}".format(self.address, self.network_id))

        # move to oapi
        self.identity = self.configuration['identity']
        self.wshost = self.configuration['websocket']

        # Get the endpoints that are specifically collected by datapacket
        # plugins.
        self.consumed_endpoints = set()
        datapacket_names = []

        for datapacket_name in configuration['datapackets']:
            self.consumed_endpoints.add(
                configuration['datapackets'][datapacket_name])
            datapacket_names.append(datapacket_name)

        debug.info("..Receiving data from plugins: " + str(datapacket_names))

        # Remove the None endpoint.
        try:
            self.consumed_endpoints.remove(None)
        except KeyError:
            pass

        # build role information
        self.roles()

        debug.info('Websocket backend configured and starting...')
        self.running = True
        self.start()

    def run(self):
        """
        Main execution loop

        Checks for websocket state and decodes incoming
        packets from the receiving queue
        """

        actor = self.handler_websocket()
        devices = {}
        while self.running:

            # cleans up message
            message = list()

            # restart websocket
            if not self.ws_p.is_alive():
                actor = self.handler_websocket()

            # Check the frame rx queue
            try:
                frame = self.rx_queue.get(timeout=10, block=True)

                # Check if neighbor diagnostics
                if isinstance(frame, (DatapacketNeighborScanV1,
                                      DatapacketNeighborScanV2)):
                    message.append(self.pack_neighbor_scan(frame))

                # Check if node diagnostics
                elif isinstance(frame, DatapacketNodeDiagnostics):
                    message.append(self.pack_node_diagnostics(frame, devices))
                    message.append(self.count_by_role(devices))

                # Check if neighbor diagnostic
                elif isinstance(frame, DatapacketNeighborDiagnostics):
                    message.append(self.pack_neighbor_diagnostics(frame))

            except Empty:
                pass

            # dumps message to websocket
            if message:
                try:
                    message[0]['epoch'] = time.time()
                    message[0]['datetime'] = datetime.datetime.utcnow().isoformat()
                except:
                    pass

                print('wss: {0}'.format(message))
                try:
                    actor.ws.send(json.dumps(message, encoding="ISO-8859-1"))
                except:
                    pass

        # terminate process
        if self.ws_p.is_alive():
            debug.info('Killing websocket')
            self.ws_e.set()
            self.ws_p.join()

        self.running = False
        debug.info('Killed websocket backend...')

    def handler_websocket(self):
        """
        Setups websocket

        Setups up the websocket with the remote server

        """
        actor = Actuactor(self.wshost, self.device, self.identity)
        self.ws_e = Event()
        self.ws_p = Thread(target=actor.listen, args=(self.ws_e,))
        self.ws_p.daemon = True
        self.ws_p.start()
        return actor

    def roles(self):
        """Constructs diagnostic roles"""

        self.headnode = DsapNodeDiagnostics.BASEROLE_HEADNODE
        self.subnode = DsapNodeDiagnostics.BASEROLE_SUBNODE
        self.sink = DsapNodeDiagnostics.BASEROLE_SINK

        self.mask_cbmac = DsapNodeDiagnostics.ROLEMASK_CBMAC
        self.mask_autorole = DsapNodeDiagnostics.ROLEMASK_AUTOROLE
        self.mask_base = DsapNodeDiagnostics.ROLEMASK_BASE

        self.autorole_headnode = self.mask_autorole | self.headnode
        self.autorole_subnode = self.mask_autorole | self.subnode
        self.autorole_sink = self.mask_autorole | self.sink

        self.cbmac_headnode = self.mask_cbmac | self.headnode
        self.cbmac_subnode = self.mask_cbmac | self.subnode
        self.cbmac_sink = self.mask_cbmac | self.sink

    def pack_neighbor_scan(self, frame):
        """
        Packs data for topic:neighbor_scan

        Args:
            frame (obj) : datapacket_neighbor_scan instance

        Returns:
            message (dict) : topic dictionary with data
        """
        messages = []
        neighbors = frame.neighbors
        # puts requests into database
        for neighbor in neighbors:
            message = {'nid': str(neighbor['address']),
                       'rss': str(neighbor['norm_rssi']),
                       'source': str(neighbor['source']),
                       'origin': str(neighbor['sink']),
                       'travel_time': str(neighbor['travel_time']),
                       'rss_scan_time': str(neighbor['last_update']),
                       'launch': str(time.time()*1000)}
            messages.append(message)

        return {'topic': 'neighbor_scan', 'data': messages}

    def pack_node_diagnostics(self, frame, devices):
        """
        Packs data for topic:node_diagnostics

        Args:
            frame (obj) : datapacket_node_diagnostics instance
            devices (dict): dictionary with known devices

        Returns:
            message (dict) : topic dictionary with data
        """

        voltage = float(frame.indication['voltage'][0])/100.0 + 2.0
        source = str(frame.indication['source_address'][0])
        message = {'nid': source,
                   'voltage': str(voltage),
                   'role': str(frame.indication['role'][0])}

        # update devices
        if source not in devices:
            devices[source] = frame.indication

        return {'topic': 'node_diagnostics', 'data': message}

    def count_by_role(self, devices):
        """
        Counts nodes by role based on diagnostic information (meshapidsap)

        Appends to the message stream information regarding how many nodes
        of each role are now under the network

        Args:
            devices (dict): dictionary with known devices

        Returns:
            message (dict) : topic dictionary with data
        """

        def do_count(on_role, nodes, name, mask=None):
            """
            Counts if on_role matcher device role

            Args:
                on_role (int) : role
                nodes (list) : list of known nodes
                name (list) : nodes name format
                on_and (int) : additional condition
            """
            target = []
            counter = 0
            for nid in nodes:
                role = int(nodes[nid]['role'][0])
                if mask is None:
                    met = role == on_role
                else:
                    met = role & mask == on_role

                if(met):
                    counter = counter + 1
                    target.append({'name': name.format(counter), 'nid': nid})

            return target

        # do the count for each relevant role
        headnodes = do_count(self.headnode, devices, 'H{0:0>3}')
        subnodes = do_count(self.subnode, devices, 'M{0:0>3}')
        autoroles = do_count(self.mask_autorole, devices,
                             'R{0:0>3}', mask=~self.mask_base)

        data = {
                'headnodes': {'members': headnodes, 'totals': len(headnodes)},
                'subnodes': {'members': subnodes, 'totals': len(subnodes)},
                'autoroles': {'members': autoroles, 'totals': len(autoroles)},
                'totals': len(devices)
               }

        return {'topic': 'node_roles', 'data': data}

    def pack_neighbor_diagnostics(self, frame):
        """
        Packs data for topic:neighbor_diagnostics

        Args:
            frame (obj) : datapacket_neighbor_diagnostics instance

        Returns:
            message (dict) : topic message
        """
        messages = []
        neighbors = frame.indication['neighbors'][0]
        for neighbor in neighbors:
            message = {'nid': str(neighbor['address']),
                       'rss': str(neighbor['rssi']),
                       'source': str(frame.indication['source_address'][0]),
                       'origin': str(frame.indication['destination_address'][0]),
                       'travel_time': str(frame.indication['travel_time_s'][0]),
                       'launch': str(time.time()*1000)}
            messages.append(message)

        return {'topic': 'neighbor_diagnostics', 'data': messages}

    def kill(self):
        """
        Kills itself by setting running flag to False
        """
        self.running = False

    def __str__(self):
        return 'WebSocket {0} talking to {1}'.format(self.identity,
                                                     self.wshost)
