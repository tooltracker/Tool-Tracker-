# Copyright 2018 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.
#

from gatewaybackend import GatewayBackend
from datapacket_haltian import DatapacketHaltian

from Queue import Queue, Empty
from threading import Thread
import time

from ISStreamer.Streamer import Streamer

class BackendIstate(GatewayBackend):
    name = 'istate-v1'

    def __init__(self, configuration, device, gw_thread = None):
        super(BackendIstate, self).__init__(configuration, device, gw_thread)

        # This is how the device can be commanded:
        self.address = self.device.get_address()
        self.network_id = self.device.get_network_address()
        
        print "Istate backend connection started for sink in address "+str(self.address)+\
            " for network "+str(self.network_id)

        self.running = True
        self.start()

    def kill(self):
        self.running = False

    def run(self):
        while self.running:
            try:
                frame = self.rx_queue.get(timeout=1)

                # Check if haltian measurement
                if isinstance(frame, DatapacketHaltian):
                    self.put_haltian_measurements(frame)
                    continue
            except Empty:
                pass

    def put_haltian_measurements(self, frame):
        data = {}
        data['node_{}_temp'.format(frame.indication['source_address'][0])] = frame.indication['temperature'][0]
        data['node_{}_humidity'.format(frame.indication['source_address'][0])] = frame.indication['humidity'][0]
        data['node_{}_pressure'.format(frame.indication['source_address'][0])] = frame.indication['pressure'][0]
        data['node_{}_x'.format(frame.indication['source_address'][0])] = frame.indication['x'][0]
        data['node_{}_y'.format(frame.indication['source_address'][0])] = frame.indication['y'][0]
        data['node_{}_z'.format(frame.indication['source_address'][0])] = frame.indication['z'][0]
        data['node_{}_battery'.format(frame.indication['source_address'][0])] = frame.indication['battery'][0]
        data['node_{}_hall'.format(frame.indication['source_address'][0])] = frame.indication['hall'][0]
        data['node_{}_illuminance'.format(frame.indication['source_address'][0])] = frame.indication['illuminance'][0]
        self.gw_thread.rx_queue.put(data)

    @classmethod
    def get_gateway_thread(cls, configuration):
        print "Creating the gateway thread for initialstate"
        class gateway_thread(Thread):
            
            def __init__(self, configuration):
                super(gateway_thread, self).__init__(name='IstateGatewayThread')
                print "..istate gateway thread started"
                self.configuration = configuration

                self.rx_queue = Queue()
                self.running = True
                self.streamer = Streamer(bucket_name=self.configuration['ibucket'],
                                         bucket_key=self.configuration['ibucketkey'],
                                         access_key=self.configuration['iaccesskey'],
                                         buffer_size=1000)

                self.start()
                
            def run(self):
                while self.running:
                    time.sleep(self.configuration['updateinterval'])
                    while True:
                        try:
                            data = self.rx_queue.get(timeout = 0)
                            self.streamer.log_object(data)
                            self.streamer.flush()
                        except Empty:
                            break

            def kill(self):
                self.running = False

        return gateway_thread(configuration)
