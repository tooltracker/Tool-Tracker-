# Copyright 2018 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.
#

from meshapidsap import DsapDataRx

class DatapacketHaltian(DsapDataRx):
    '''
    This class handles Haltian measurements
    '''
    def __init__(self, dest_endpoint):
        super(DatapacketHaltian, self).__init__(source_endpoint=20, dest_endpoint=dest_endpoint)

        # 1 byte: temperature header
        # 2 bytes: Temperatute (1/100 celsius)
        # 1 byte: Humidity header
        # 2 bytes: Humidity (1/100th of %)
        # 1 byte: pressure header
        # 4 bytes: Pressure (pascal)
        # 1 byte als header
        # 1 byte: als mantissa
        # 1 byte: als exponent
        # 1 byte: tilt header
        # 3*2 bytes: xyz, mG
        # 1 byte: Battery header
        # 1 byte: Battery value (percents)
        # 1 byte: Hall sensor header
        # 1 byte: Hall sensor value

        self.payload['temperature_header'] = (None, 'uint8')
        self.payload['temperature_raw'] = (None, 'int16')
        self.payload['humidity_header'] = (None, 'uint8')
        self.payload['humidity_raw'] = (None, 'uint16')
        self.payload['pressure_header'] = (None, 'uint8')
        self.payload['pressure_raw'] = (None, 'uint32')
        self.payload['als_header'] = (None, 'uint8')
        self.payload['als_mantissa'] = (None, 'uint8')
        self.payload['als_exponent'] = (None, 'uint8')
        self.payload['tilt_header'] = (None, 'uint8')
        self.payload['x_raw'] = (None, 'int16')
        self.payload['y_raw'] = (None, 'int16')
        self.payload['z_raw'] = (None, 'int16')
        self.payload['battery_header'] = (None, 'uint8')
        self.payload['battery_value_raw'] = (None, 'uint8')
        self.payload['hall_header'] = (None, 'uint8')
        self.payload['hall'] =  (None, 'uint8')

    @classmethod
    def get_name(cls):
        return 'haltian-v1'
        
    def parse_indication(self,
                         primitive_id,
                         frame_id,
                         payload_length,
                         payload,
                         compare = False):

        [a, b] = super(DatapacketHaltian, self).parse_indication(primitive_id,
                         frame_id,
                         payload_length,
                         payload,
                         compare)
        if a:
            # Successful parsing, parse actual payload
            self.indication['temperature'] = (float(self.indication['temperature_raw'][0]) / 100.0, 'metadata')
            self.indication['humidity'] = (float(self.indication['humidity_raw'][0]) / 10.0, 'metadata')
            self.indication['pressure'] = (float(self.indication['pressure_raw'][0]) / 100000, 'metadata')
            self.indication['illuminance'] = \
                (((2 ** self.indication['als_exponent'][0]) * self.indication['als_mantissa'][0]) * 0.045, 'metadata')
            self.indication['x'] = (float(self.indication['x_raw'][0]) / 1000.0, 'metadata')
            self.indication['y'] = (float(self.indication['y_raw'][0]) / 1000.0, 'metadata')
            self.indication['z'] = (float(self.indication['z_raw'][0]) / 1000.0, 'metadata')
            self.indication['battery'] = (float(self.indication['battery_value_raw'][0]), 'metadata')
            # Hall sensor is already parsed
            
        return a, b

