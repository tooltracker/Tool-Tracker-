# Copyright 2018 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.
#

import struct

from meshapidsap import DsapDataRx

class DatapacketRaw32(DsapDataRx):
    '''
    This class handles Raw 32-style measurements

    It  puts data as 32-bit chunks to the database
    '''

    def __init__(self, dest_endpoint):
        super(DatapacketRaw32, self).__init__(dest_endpoint=dest_endpoint)
        self.measurements = None
        
    def parse_indication(self,
                         primitive_id,
                         frame_id,
                         payload_length,
                         payload,
                         compare = False):

        [a, b] = super(DatapacketRaw32, self).parse_indication(primitive_id,
                         frame_id,
                         payload_length,
                         payload,
                         compare)
        if a:
            # Measure total length
            _payload = self.indication['apdu'][0]

            # Ensure that only whole 32 bits are used
            _payload = _payload[0:len(_payload) / 4 * 4]

            # Create parsing
            measurement_format = '<' + 'I' * (len(_payload) / 4)
            self.measurements = struct.unpack(measurement_format, _payload)
            
        return a, b

    @classmethod
    def get_name(self):
        return 'raw32-v1'
    

