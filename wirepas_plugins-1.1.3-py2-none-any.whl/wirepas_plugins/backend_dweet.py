# Copyright 2018 Wirepas Ltd. All Rights Reserved.
#
# See file LICENSE.txt for full license details.
#

from Queue import Queue, Empty
from threading import Thread
import time
import dweepy

from gatewaybackend import GatewayBackend

excluded_datapackets = []

try:
    from datapacket_haltian import DatapacketHaltian
except:
    excluded_datapackets.append('haltian')

try:
    from datapacket_raw32 import DatapacketRaw32
except:
    excluded_datapackets.append('raw32')

try:
    from datapacket_neighborscan import DatapacketNeighborScanV1
except:
    excluded_datapackets.append('neighborscanv1')

try:
    from datapacket_neighborscan import DatapacketNeighborScanV2
except:
    excluded_datapackets.append('neighborscanv2')

try:
    from datapacket_ruuvi import DatapacketRuuvi
except:
    excluded_datapackets.append('ruuvi')

class BackendDweet(GatewayBackend):
    name = 'dweet-v1'

    def __init__(self, configuration, device, gw_thread = None):
        super(BackendDweet, self).__init__(configuration, device, gw_thread)

        # This is how the device can be commanded:
        self.address = self.device.get_address()
        self.network_id = self.device.get_network_address()

        print "Dweetio backend connection started for sink in address " + \
            str(self.address)+\
            " for network "+str(self.network_id)

        self.running = True
        self.start()

    def kill(self):
        self.running = False

    def run(self):
        while self.running:
            try:
                frame = self.rx_queue.get(timeout=1)

                # Check if haltian measurement
                if 'haltian' not in excluded_datapackets and \
                isinstance(frame, DatapacketHaltian):
                    self.put_haltian_measurements(frame)

                # Check if raw32 measurement
                if 'raw32' not in excluded_datapackets and \
                isinstance(frame, DatapacketRaw32):
                    self.put_raw32_measurements(frame)

                # Check if wpat v1 measurement
                if 'neighborscanv1' not in excluded_datapackets and \
                isinstance(frame, (DatapacketNeighborScanV1)):
                    self.put_neighbor_scan(frame)

                # Check if wpat v2 measurement
                if 'neighborscanv2' not in excluded_datapackets and \
                isinstance(frame, (DatapacketNeighborScanV2)):
                    self.put_neighbor_scan(frame)

                # Check if ruuvi measurement
                if 'ruuvi' not in excluded_datapackets and \
                isinstance(frame, (DatapacketRuuvi)):
                    self.put_ruuvi_measurements(frame)

            except Empty:
                pass

    def put_haltian_measurements(self, frame):
        data = {}
        data['node_{}_temp'.format(frame.indication['source_address'][0])] = \
            frame.indication['temperature'][0]
        data['node_{}_humidity'.
             format(frame.indication['source_address'][0])] = \
                    frame.indication['humidity'][0]
        data['node_{}_pressure'.format(frame.
                                       indication['source_address'][0])] = \
                                        frame.indication['pressure'][0]
        data['node_{}_x'.format(frame.indication['source_address'][0])] = \
                                frame.indication['x'][0]
        data['node_{}_y'.format(frame.indication['source_address'][0])] = \
                                frame.indication['y'][0]
        data['node_{}_z'.format(frame.indication['source_address'][0])] = \
                                frame.indication['z'][0]
        data['node_{}_battery'.format(frame.
                                      indication['source_address'][0])] = \
                                            frame.indication['battery'][0]
        data['node_{}_hall'.format(frame.indication['source_address'][0])] = \
                                            frame.indication['hall'][0]
        data['node_{}_illuminance'.format(frame.
                                          indication['source_address'][0])] = \
                                            frame.indication['illuminance'][0]
        self.gw_thread.msgs.update(data)

    def put_ruuvi_measurements(self, frame):
        '''
        Put Ruuvi tag sensor measurements to Dweet.io

        Args:
            frame (DatapacketRuuvi): Ruuvi sensor data frame.
        '''

        data = {}
        data['node_{}_temp'.format(frame.indication['source_address'][0])] = \
            frame.indication['temp'][0]
        data['node_{}_humidity'.
             format(frame.indication['source_address'][0])] = \
                    frame.indication['humi'][0]
        data['node_{}_pressure'.format(frame.
                                       indication['source_address'][0])] = \
                                        frame.indication['pres'][0]
        data['node_{}_x'.format(frame.indication['source_address'][0])] = \
                                frame.indication['acc_x'][0]
        data['node_{}_y'.format(frame.indication['source_address'][0])] = \
                                frame.indication['acc_y'][0]
        data['node_{}_z'.format(frame.indication['source_address'][0])] = \
                                frame.indication['acc_z'][0]

        self.gw_thread.msgs.update(data)

    def put_raw32_measurements(self, frame):
        data = {}

        id = 0
        for measurement in frame.measurements:
            data['node_{}_value_{}'.\
                 format(frame.indication['source_address'][0], id)] = \
                    measurement
            id = id + 1
        self.gw_thread.msgs.update(data)

    def put_neighbor_scan(self, frame):
        data = {}
        # puts requests into database
        for measurement in frame.neighbors:
            data['node_{0}_neighbor_{1}_rss'.format(measurement['source'],
                                                    measurement['address'])] = \
                                                    measurement['norm_rssi']
            data['node_{0}_neighbor_{1}_travel_time'.
                 format(measurement['source'],
                        measurement['address'])] = measurement['travel_time']
            data['node_{0}_neighbor_{1}_sink'.
                 format(measurement['source'],
                        measurement['address'])] = measurement['sink']

        self.gw_thread.msgs.update(data)

    @classmethod
    def get_gateway_thread(cls, configuration):
        print "Creating the gateway thread for dweet.io"
        class gateway_thread(Thread):
            msgs = {}

            def __init__(self, configuration):
                super(gateway_thread, self).\
                    __init__(name = 'DweetioGatewayThread')
                self.configuration = configuration
                self.running = True
                self.start()

                print "..dweet.io gateway thread started"
                print "..follow me at: https://dweet.io/follow/" + \
                    self.configuration['thing']

            def run(self):
                while self.running:
                    time.sleep(self.configuration['updateinterval'])
                    if len(self.msgs) == 0:
                        continue
                    else:
                        while True:
                            try:
                                dweepy.dweet_for(self.configuration['thing'],
                                                 self.msgs)
                                break
                            except UnicodeDecodeError:
                                # Dweepy does not allow binary data
                                break
                            except dweepy.DweepyError:
                                # This is the throttling mechanism
                                time.sleep(1)

            def kill(self):
                self.running = False

        return gateway_thread(configuration)
