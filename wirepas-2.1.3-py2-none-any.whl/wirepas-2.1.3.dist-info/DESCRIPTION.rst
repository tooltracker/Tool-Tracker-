Wirepas Connectivity API Host Library (Python)
==============================================

A Python library to connect to and control Wirepas Connectivity enabled
devices.

Abstracts the Wirepas Connectivity Dual-MCU API as a Python library.
See the document 'WP-RM-100 - Wirepas Connectivity Dual-MCU API Reference Manual' for further information.

Copyright 2016 Wirepas Ltd. All rights reserved.

<http://www.wirepas.com> `Wirepas Ltd`


